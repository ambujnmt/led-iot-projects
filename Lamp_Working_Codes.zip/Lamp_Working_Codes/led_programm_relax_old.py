import machine
import neopixel
import time
# import uasyncio
import _thread
import random
import gc
from micropython import const
import uasyncio as asyncio
from led_programmliste import manager
from machine import TouchPad


class Relax:
    def __init__(self, touchenabled):
        self.NUM_LEDS_TOP = const(10)
        self.NUM_LEDS_MID = const(98)
        self.NUM_LEDS_BOTTOM = const(12)
        
        
        
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23
        
        
        #Belegung ESP32 Platine
        '''
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''
        

        # Erstelle das Neopixel-Objekt
        self.np_top = neopixel.NeoPixel(machine.Pin(self.PIN), self.NUM_LEDS_TOP, bpp=4)
        self.np_mid = neopixel.NeoPixel(machine.Pin(self.PIN_MID), self.NUM_LEDS_MID, bpp=4)  # Use bpp=4 to indicate RGBW LEDs
        self.np_bottom_first = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_FIRST), self.NUM_LEDS_BOTTOM, bpp=4)
        self.np_bottom_second = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_SECOND), self.NUM_LEDS_BOTTOM, bpp=4)
        self.np_bottom_third = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_THIRD), self.NUM_LEDS_BOTTOM, bpp=4)

        # Define the colors
        
        self.ORANGE = [(255, 51, 0, 0)]
        
        self.ORANGE_TO_ZERO = [(10, 2, 0, 0), (15, 3, 0, 0),
                               (20, 4, 0, 0), (25, 5, 0, 0),
                               (30, 6, 0, 0), (35, 7, 0, 0),
                               (40, 8, 0, 0), (45, 9, 0, 0),
                               (50, 10, 0, 0), (55, 11, 0, 0),
                               (60, 12, 0, 0), (65, 13, 0, 0),
                               (70, 14, 0, 0), (75, 15, 0, 0),
                               (80, 16, 0, 0), (85, 17, 0, 0),
                               (90, 18, 0, 0), (95, 19, 0, 0),
                               (100, 20, 0, 0), (105, 21, 0, 0),
                               (110, 22, 0, 0), (115, 23, 0, 0),
                               (120, 24, 0, 0), (125, 25, 0, 0),
                               (130, 26, 0, 0), (135, 27, 0, 0),
                               (140, 28, 0, 0), (145, 29, 0, 0),
                               (150, 30, 0, 0), (155, 31, 0, 0),
                               (160, 32, 0, 0), (165, 33, 0, 0),
                               (170, 34, 0, 0), (175, 35, 0, 0),
                               (180, 36, 0, 0), (185, 37, 0, 0),
                               (190, 38, 0, 0), (195, 39, 0, 0),
                               (200, 40, 0, 0), (205, 41, 0, 0),
                               (210, 42, 0, 0), (215, 43, 0, 0),
                               (220, 44, 0, 0), (225, 45, 0, 0),
                               (230, 46, 0, 0), (235, 47, 0, 0),
                               (240, 48, 0, 0), (245, 49, 0, 0),
                               (250, 50, 0, 0), (255, 51, 0, 0),
                               (255, 51, 0, 0), (250, 50, 0, 0),
                               (245, 49, 0, 0), (240, 48, 0, 0),
                               (235, 47, 0, 0), (230, 46, 0, 0),
                               (225, 45, 0, 0), (220, 44, 0, 0),
                               (215, 43, 0, 0), (210, 42, 0, 0),
                               (205, 41, 0, 0), (200, 40, 0, 0),
                               (195, 39, 0, 0), (190, 38, 0, 0),
                               (185, 37, 0, 0), (180, 36, 0, 0),
                               (175, 35, 0, 0), (170, 34, 0, 0),
                               (165, 33, 0, 0), (160, 32, 0, 0),
                               (155, 31, 0, 0), (150, 30, 0, 0),
                               (145, 29, 0, 0), (140, 28, 0, 0),
                               (135, 27, 0, 0), (130, 26, 0, 0),
                               (125, 25, 0, 0), (120, 24, 0, 0),
                               (115, 23, 0, 0), (110, 22, 0, 0),
                               (105, 21, 0, 0), (100, 20, 0, 0),
                               (95, 19, 0, 0), (90, 18, 0, 0),
                               (85, 17, 0, 0), (80, 16, 0, 0),
                               (75, 15, 0, 0), (70, 14, 0, 0),
                               (65, 13, 0, 0), (60, 12, 0, 0),
                               (55, 11, 0, 0), (50, 10, 0, 0),
                               (45, 9, 0, 0), (40, 8, 0, 0),
                               (35, 7, 0, 0), (30, 6, 0, 0),
                               (25, 5, 0, 0), (20, 4, 0, 0),
                               (15, 3, 0, 0), (10, 2, 0, 0)]
    

        self.paused = False
        self.relax_running = False
        self.thread_running = None
        
#mit touch initialisieren?
        self.touchenabled = touchenabled
        
                #manager mit led programm füttern, muss gemacht werden um zirkuläre importe zu vermeiden
        if self.touchenabled:
            
            manager.add_programm(self)
            
            self.touch_pin = TouchPad(machine.Pin(33)) #metalhaube
            self.touch_threshold = self.touch_pin.read()
            
        else:
            print(self, " ohne touch initialisiert")
        

    def relax_on(self):

        gc.enable()
        self.relax_running = True
    
   
        r2 = 0  # wird verwendet um den Farbindex der oberen Schleife zu tracken (soll um 1 erhöht werden jedes mal wenn in TOP LED geschrieben wurde)
        r = 0  # wird verwendet um die oberen LEDs langsamer zu triggern als der Mittlere LED Streifen da sonst (zu schnell)
        j = 0  # wird verwendet um die Anzahl der durchläufe der True Schleife zu zählen
        r3 = 0
        r4 = 0
        
        brightness = 100.0
        
        swtich_brightness = 0
        
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        

        while self.relax_running:
            
            if self.relax_running == False:
                return
            
            
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            
            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue
            

           
           
            r4 = r4 + 1
            if(r4 == 1):
                
                if brightness <= 10.0:
                    switch_brightness = 1
            
                if brightness == 100.0:
                    switch_brightness = 0
                
                if switch_brightness == 1:
                    brightness += 1.0
                else:
                    brightness -= 1.0
                
                if self.relax_running == False:
                    return
                
                # TOP - LEDS
                self.np_top[(0)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(1)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(2)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(3)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(4)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(5)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(6)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(7)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(8)] = self.scale_color(self.ORANGE[0], brightness)
                self.np_top[(9)] = self.scale_color(self.ORANGE[0], brightness)
                
                if self.relax_running == False:
                    return
                
                # MID - LEDS
                self.np_mid[0] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[1] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[2] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[3] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[4] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[5] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[6] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[7] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[8] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[9] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[10] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[11] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[12] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[13] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[14] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[15] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return                
                self.np_mid[16] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[17] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[18] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[19] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[20] = self.scale_color(self.ORANGE[0], brightness)
                
                if self.relax_running == False:
                    return
                
                self.np_mid[21] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[22] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[23] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[24] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[25] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[26] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[27] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[28] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[29] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[30] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[31] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[32] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[33] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[34] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[35] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[36] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[37] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[38] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[39] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[40] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[41] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[42] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[43] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[44] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[45] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[46] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[47] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[48] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[49] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[50] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[51] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[52] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[53] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[54] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[55] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[56] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[57] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[58] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[59] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[60] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[61] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[62] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[63] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[64] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[65] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[66] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[67] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[68] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[69] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[70] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[71] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[72] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[73] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[74] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[75] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[76] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[77] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[78] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[79] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[80] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[81] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[82] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[83] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[84] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[85] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return
                self.np_mid[86] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[87] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[88] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[89] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[90] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[91] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[92] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[93] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[94] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[95] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[96] = self.scale_color(self.ORANGE[0], brightness)
                self.np_mid[97] = self.scale_color(self.ORANGE[0], brightness)
                if self.relax_running == False:
                    return                
                
                
                
                
                # BOTTOM - LEDS   
                self.np_bottom_first[(0)] = self.ORANGE[0]
                self.np_bottom_first[(1)] = self.ORANGE[0]
                self.np_bottom_first[(2)] = self.ORANGE[0]
                self.np_bottom_first[(3)] = self.ORANGE[0]
                self.np_bottom_first[(4)] = self.ORANGE[0]
                self.np_bottom_first[(5)] = self.ORANGE[0]
                self.np_bottom_first[(6)] = self.ORANGE[0]
                self.np_bottom_first[(7)] = self.ORANGE[0]
                self.np_bottom_first[(8)] = self.ORANGE[0]
                self.np_bottom_first[(9)] = self.ORANGE[0]
                self.np_bottom_first[(10)] = self.ORANGE[0]
                self.np_bottom_first[(11)] = self.ORANGE[0]
                if self.relax_running == False:
                    return
                self.np_bottom_second[(0)] = self.ORANGE[0]
                self.np_bottom_second[(1)] = self.ORANGE[0]
                self.np_bottom_second[(2)] = self.ORANGE[0]
                self.np_bottom_second[(3)] = self.ORANGE[0]
                self.np_bottom_second[(4)] = self.ORANGE[0]
                self.np_bottom_second[(5)] = self.ORANGE[0]
                self.np_bottom_second[(6)] = self.ORANGE[0]
                self.np_bottom_second[(7)] = self.ORANGE[0]
                self.np_bottom_second[(8)] = self.ORANGE[0]
                self.np_bottom_second[(9)] = self.ORANGE[0]
                self.np_bottom_second[(10)] = self.ORANGE[0]
                self.np_bottom_second[(11)] = self.ORANGE[0]
                if self.relax_running == False:
                    return                
                self.np_bottom_third[(0)] = self.ORANGE[0]
                self.np_bottom_third[(1)] = self.ORANGE[0]
                self.np_bottom_third[(2)] = self.ORANGE[0]
                self.np_bottom_third[(3)] = self.ORANGE[0]
                self.np_bottom_third[(4)] = self.ORANGE[0]
                self.np_bottom_third[(5)] = self.ORANGE[0]
                self.np_bottom_third[(6)] = self.ORANGE[0]
                self.np_bottom_third[(7)] = self.ORANGE[0]
                self.np_bottom_third[(8)] = self.ORANGE[0]
                self.np_bottom_third[(9)] = self.ORANGE[0]
                self.np_bottom_third[(10)] = self.ORANGE[0]
                self.np_bottom_third[(11)] = self.ORANGE[0]
                if self.relax_running == False:
                    return
                
                r4 = 0
                
            #self.checktouchinput()
   
            if self.relax_running == False:
                break
            # schreibe in jeden durchlauf obere & mittleren led streifen
            self.np_top.write()
            self.np_mid.write()
            
            # untere leds schreiben
            self.np_bottom_first.write()
            self.np_bottom_second.write()
            self.np_bottom_third.write()


    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    def scale_color(self, color_tupel, brightness):
        
        floatbrightness = float(brightness)
        
        r, g, b, w = color_tupel
        
        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)
        
        floatbrightness = floatbrightness / 100.0
        
        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)
        
        return (r, g, b, w)

    def start(self):
        # time.sleep()
        self.relax_running = True
        self.thread_running = None

        try:
            self.thread_running = _thread.start_new_thread(self.relax_on, ())

        except:

            time.sleep_ms(70)
            self.start()

         
        return True

    def stop(self):

        self.relax_running = False

        # self.thread_mid.exit()

        if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            self.thread_running.exit()

        self.relax_off()

    def relax_off(self):

        self.np_mid.fill((0, 0, 0, 0))
        self.np_top.fill((0, 0, 0, 0))

        self.np_mid.write()
        self.np_bottom_first.fill((0, 0, 0, 0))
        self.np_bottom_second.fill((0, 0, 0, 0))
        self.np_bottom_third.fill((0, 0, 0, 0))

        self.np_top.write()
        self.np_bottom_first.write()
        self.np_bottom_second.write()
        self.np_bottom_third.write()

    def get_Status(self):
        return self.relax_running
    
    #________________Tochinputfunktion__________________________________
        
        
    def checktouchinput(self):
        
        

            
        if self.confirmtouch() == True:
            print("touch erkannt")
                
            print("checktouchinput gestartet")
            print("prüfe ob gehalten wird")

            if self.checkhold(self.touch_threshold) == False:
                print("checkhold ist false")
                #sprich hier haben wir bereits den ersten kurzen touch erkannt, nun müssen wir prüfen ob ein 2. kurzer touch erkannt wird
                #um zwischen 1 kurzen tap und 2 kruze taps und ggf 1 kurzer tap und hold zu differenzieren
                
                print("prüfe ob 2 kurzer touch ankommt")
                
                if self.checksecondtouch(self.touch_threshold) == True:
                    print("doppelter kurzer Tap erkannt")
                    self.previousprogramm()
                    
                    
                    
                    #hier funktion für vorheriges programm einfügen
                    
                    
                    time.sleep(3)
                
                else:
                    print("nur einfacher kurzer tap erkannt")
                    self.nextprogramm()
                    
                    time.sleep(3)
                    
                    #hier funktion für nächstes programm einfügen
                 
            else:
                print("nur 1 langes halten erkannt")
                
            time.sleep(3)
            #touchwert ohne berührung neu kalibrieren
            self.touch_threshold = self.touch_pin.read()
            
        
        else:
            return
            
            
            
            
    def confirmtouch(self):
        counter = 0
        checkvalue = 0
        while True:
            touchvalue = self.touch_pin.read()
            if touchvalue < self.touch_threshold -20 or touchvalue > self.touch_threshold +20:
                checkvalue = checkvalue +1
            
            counter = counter +1
            if counter == 3:
                break
        
        if checkvalue > 2:
            return True
        
        else:
            return False
            
                
            
        
                
    def checkhold(self, holdvalue):
        print("checkhold gestartet")
        counter = 0
        holdcounter = 0

        while True:
            x = self.touch_pin.read()
            if x > holdvalue + 20 or x < holdvalue-20:
                holdcounter = holdcounter + 1
                
            if counter == 20:
                break

            if holdcounter > 15:
                print("Hold Detected")
                if self.paused == False:
                    self.pause()
                else:
                    self.unpause()
                break
            counter = counter + 1
            
            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep_ms(3)

        if holdcounter > 15:
            return True
        else:
            return False       
            
    def checksecondtouch(self, touchvalue):
        
        print("checksecondtouch gestartet")
        counter = 0
        holdcounter = 0
        while True:
            x = self.touch_pin.read()
            if x > touchvalue + 20 or x < touchvalue-20:
                holdcounter = holdcounter + 1
                
            if counter == 40:
                break

            if holdcounter > 25:
                print("Hold after short touch Detected")
                break
            counter = counter + 1
            
            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep_ms(3)

        if holdcounter > 25:
            print("2. Hold erkannt, wird nur für Benutzerdefiniert anderst interpretiert")
            return True
        elif holdcounter > 4:   
            print("kurzer 2. Tap erkannt")
            return True
        else:
            print("kein 2. Touch erkannt")
            return False
        
    def pause(self):
        self.paused = True
        self.relax_off()
        print("Pause wurde auf true gesetzt", self.paused)

    def unpause(self):
        self.paused = False
        print("Pause wurde auf False gesetzt", self.paused)
        
        
        
    def nextprogramm(self):
        
        print("nächstes programm aufgerufen")
        self.stop()
        manager.next_program(self)
        
    def previousprogramm(self):
        
        print("vorheriges programm aufgerufen")
        self.stop()
        manager.previous_program(self)
        
        
#_Touchinputfunktionende________________________________________________ 


#relax = Relax(False)
#relax.start()
