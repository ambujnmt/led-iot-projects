
import threading
import time
import json
import time

import gc


class Led_programm_get_times():
    
    def __init__(self, lamp_config):
        
        #### dieser wert wird benötigt um in der microdot heartbeat adresse zu informieren ob das aktuelle json file an die app zurück gesendet werden soll (z.b. bei lokaler steuerung der lampe)
        self.ischanged = False
        
        self.json_file = "current_lampmodel.json"
        
        self.timer = threading.Timer
        self.timer.cancel()
        
        self.laufzeit1start_hours = None
        self.laufzeit1start_minutes = None
        
        self.laufzeit1start = None
        self.laufzeit1ende = None
        self.laufzeit2start = None
        self.laufzeit2ende = None
        self.laufzeit3start = None
        self.laufzeit3ende = None
        self.laufzeit4start = None
        self.laufzeit4ende = None
        
        self.programms = None
        self.lamp_config = lamp_config
        
#         try:
#             from main import lamp_config
#         except Exception as e:
#             print("Konnte Lamp_conifg von der main nicht importieren", e)
#             pass
#         try:
#             from webserver_microdot import lamp_config
#         except Exception as e:
#             print("Konnte Lamp_conifg von der microdot_webserver nicht importieren", e)
#             pass
        
        self.programms = lamp_config.get_all_programms()
        self.unpack_programms()
        
    
    # Die Methode startet das ganze kalkulieren des Laufzeit-Modus, welcher letztendlich ausgeführt werden soll
    def start(self):
        
        with open(self.json_file, "r") as f:
            data = json.load(f)
        
        self.start_calculate_timer(data["laufzeit1start"])
        self.start_calculate_timer(data["laufzeit2start"])
        self.start_calculate_timer(data["laufzeit3start"])        
        self.start_calculate_timer(data["laufzeit4start"])
        
        self.start_calculate_timer(data["laufzeit1ende"])
        self.start_calculate_timer(data["laufzeit2ende"])
        self.start_calculate_timer(data["laufzeit3ende"])        
        self.start_calculate_timer(data["laufzeit4ende"])
        print()
        
        #print("Kürzeste ZEIT: ", self.get_smallest_time())
        print()
        
        self.compare_and_print(self.get_smallest_time())
        
    # Diese Methode berechnet, wie viele Sekunden bis zur Zielzeit noch verbleiben
    def start_calculate_timer(self, laufzeit_string):

        with open(self.json_file, "r") as f:
            data = json.load(f)
        
        # Inizialisere Stunden und Minuten
        hour = self.get_hours(laufzeit_string)
        minute = self.get_minutes(laufzeit_string)
        
        # Aktuelle Zeit in Sekunden seit dem 1. Januar 2000
        current_time = time.mktime(time.localtime())

        # Zielzeit für heute festlegen
        target_time = time.mktime((time.localtime()[0], time.localtime()[1], time.localtime()[2], hour, minute, 0, 0, 0))

        # Wenn die Zielzeit für heute bereits vergangen ist, Zielzeit auf morgen setzen
        if target_time < current_time:
            target_time += 86400  # Eine Sekunde hat 86400 Sekunden

        # Berechnen, wie viele Sekunden bis zur Zielzeit verbleiben
        remaining_time = target_time - current_time
        
        if laufzeit_string == data["laufzeit1start"]:
            self.laufzeit1start = remaining_time
            #print("Bis zur START Zielzeit 1: ", self.laufzeit1start)
        elif laufzeit_string == data["laufzeit2start"]:
            self.laufzeit2start = remaining_time
            #print("Bis zur START Zielzeit 2: ", self.laufzeit2start)
        elif laufzeit_string == data["laufzeit3start"]:
            self.laufzeit3start = remaining_time
            #print("Bis zur START Zielzeit 3: ", self.laufzeit3start)
        elif laufzeit_string == data["laufzeit4start"]:
            self.laufzeit4start = remaining_time
            #print("Bis zur START Zielzeit 4: ", self.laufzeit4start)
        
        elif laufzeit_string == data["laufzeit1ende"]:
            self.laufzeit1ende = remaining_time
            #print("Bis zur END Zielzeit 1: ", self.laufzeit1ende)
        elif laufzeit_string == data["laufzeit2ende"]:
            self.laufzeit2ende = remaining_time
            #print("Bis zur END Zielzeit 2: ", self.laufzeit2ende)
        elif laufzeit_string == data["laufzeit3ende"]:
            self.laufzeit3ende = remaining_time
            #print("Bis zur END Zielzeit 3: ", self.laufzeit3ende)
        elif laufzeit_string == data["laufzeit4ende"]:
            self.laufzeit4ende = remaining_time
            #print("Bis zur END Zielzeit 4: ", self.laufzeit4ende)        
        
        

    # Gibt die Stunden eines Strings zurück
    def get_hours(self, laufzeit_string):
        
        hours = laufzeit_string[:2]
        
        hours_int = int(hours)
        
        return hours_int
    
    # Gibt die Minuten eines Strings zurück    
    def get_minutes(self, laufzeit_string):
        
        minutes = laufzeit_string[-2:]
        
        minutes_int = int(minutes)
        
        return minutes_int
    
    
    # Gibt den kleinsten Wert aller Laufzeiten zurück
    def get_smallest_time(self):
        times = {
            self.laufzeit1start: "self.laufzeit1start",
            self.laufzeit1ende: "self.laufzeit1ende",
            self.laufzeit2start: "self.laufzeit2start",
            self.laufzeit2ende: "self.laufzeit2ende",
            self.laufzeit3start: "self.laufzeit3start",
            self.laufzeit3ende: "self.laufzeit3ende",
            self.laufzeit4start: "self.laufzeit4start",
            self.laufzeit4ende: "self.laufzeit4ende"
        }
        
        valid_times = {time: var_name for time, var_name in times.items() if time is not None}

        if not valid_times:
            return None, None

        min_time = min(valid_times.keys())
        corresponding_var = valid_times[min_time]
        return min_time

    # Vergleicht den kleinsten Wert mit allen vorhandenen und startet daraufhin den Timer, um die Laufzeit mit dem kleinsten Wert zu starten 
    def compare_and_print(self, value_to_compare):
        if self.timer.is_alive():
            self.timer.cancel()
        times = {
            self.laufzeit1start: "self.laufzeit1start",
            self.laufzeit1ende: "self.laufzeit1ende",
            self.laufzeit2start: "self.laufzeit2start",
            self.laufzeit2ende: "self.laufzeit2ende",
            self.laufzeit3start: "self.laufzeit3start",
            self.laufzeit3ende: "self.laufzeit3ende",
            self.laufzeit4start: "self.laufzeit4start",
            self.laufzeit4ende: "self.laufzeit4ende"
        }

        for time, var_name in times.items():
            if time == value_to_compare:
                print("###############################    TEST 1")
                print(f"Übereinstimmung gefunden: Variable {var_name} = {time}")
                print("###############################    TEST 2")
                self.check_future_mode(var_name, time)
                print("###############################    TEST 4")
                break
        else:
            print(f"Keine Übereinstimmung gefunden für Wert {value_to_compare}.")
            
    
    def check_future_mode(self, var_name, remaining_time):
        print("###############################    TEST 3")
        with open(self.json_file, "r") as f:
            data = json.load(f)
        if self.timer.is_alive():
            self.timer.cancel()
            
        if var_name == "self.laufzeit1start":
            print("Laufzeit 1 wird gestartet")
            self.change_modus(data["moduslaufzeit1"])
            self.timer.cancel()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.start_function())
            print("Timer 1 start wird gestartet")
        elif var_name == "self.laufzeit2start":
            print("Laufzeit 2 wird gestartet")
            self.change_modus(data["moduslaufzeit2"])
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.start_function())
        elif var_name == "self.laufzeit3start":
            print("Laufzeit 3 wird gestartet")
            self.change_modus(data["moduslaufzeit3"])
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.start_function())
        elif var_name == "self.laufzeit4start":
            print("Laufzeit 4 wird gestartet")
            self.change_modus(data["moduslaufzeit4"])
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.start_function())
            
        elif var_name == "self.laufzeit1ende":
            print("Laufzeit 1 wird beendet")
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.stop_function())
            print("Timer 1 stop wird gestartet")
        elif var_name == "self.laufzeit2ende":
            print("Laufzeit 1 wird beendet")
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.stop_function())
        elif var_name == "self.laufzeit3ende":
            print("Laufzeit 1 wird beendet")
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.stop_function())
        elif var_name == "self.laufzeit4ende":
            print("Laufzeit 1 wird beendet")
            self.timer.deinit()
            self.timer.init(period=remaining_time * 1000, mode=machine.Timer.ONE_SHOT, callback=lambda t: self.stop_function())
        
        else:
            print("Irgendwas stimmt hier nicht")
            
    def change_modus(self, new_mode):
        gc.collect()
        with open(self.json_file, "r") as f:
            data = json.load(f)
            
        data["modus"] = new_mode
        
        # JSON-Daten in die Datei schreiben
        with open(self.json_file, 'w') as f:
            json.dump(data, f)
            
    # Startet das Leuchtprogramm an der Lampe
    def start_function(self):
        print("start FUNKTION AUFGEWRUFEN")
        self.timer.deinit()
        self.start()  
        
        with open(self.json_file, "r") as f:
            data = json.load(f)     
        
        self.try_stop_all_other_modes(data["modus"])
        self.try_start_modus(data["modus"], data)

        
    # Stoppt das bzw. alle aktiven Leuchtprogramme an der Lampe        
    def stop_function(self):
        
        print("STOP FUNKTION AUFGEWRUFEN")
        
        self.timer.deinit()
        self.start()  
        
        with open(self.json_file, "r") as f:
            data = json.load(f)
        try:    
            self.try_stop_all_other_modes(data["modus"])
        except Exception as e:
            print("STOppen anderer Modis nicht erfolgreich", e)
#         time.sleep(2)
#         self.start()

    def unpack_programms(self):
        
        for x in self.programms:
            current_classname = type(x).__name__
            print("Current Classname unpack", current_classname)            
            
            #1
            if current_classname == "Benutzerdefiniert":
                self.benutzerdefiniert = x 
            
            #2
            if current_classname == "Galaxy":
                self.galaxy = x 
            #3
            if current_classname == "RainyDays":
                self.rainy_days = x
            #4
            if current_classname == "RainbowLED":
                self.rainbow = x
            #5    
            if current_classname == "Indigo_Cure":
                self.indigo_cure = x
            #6
            if current_classname == "SleepingMotion":
                self.sleeping_motion = x
            #7
            if current_classname == "Xmas":
                self.xmas = x
            #8   
            if current_classname == "Relax":
                self.relax = x
            #9   
            if current_classname == "Pulsar":
                self.pulsar = x
            #10    
            if current_classname == "Crazy_alien":
                self.crazy_alien = x
            #11   
            if current_classname == "Earth":
                self.earth = x
            
        print(self.benutzerdefiniert)
        print(self.galaxy)    
        print(self.rainy_days)    
        print(self.rainbow)
        print(self.indigo_cure)    
        print(self.sleeping_motion)              
        print(self.xmas)    
        print(self.relax)            
        print(self.sleeping_motion)              
        #print(self.pulsar)    
        print(self.crazy_alien)             
        print(self.earth)
        
        
        
    def try_start_modus(self, modus, data):
        
        if modus == "Rainy Days":
            modus = self.rainy_days
            
        
        if modus == "Rainbow":
            modus = self.rainbow
            
        if modus == "Benutzerdefiniert":
            modus = self.benutzerdefiniert
            
            
        if modus == "Indigo Cure":
            print("Modus ist Indigo Cure")
            modus = self.indigo_cure
            
        
        if modus == "Galaxy":
            modus = self.galaxy
        
        if modus == "Sleeping Motion":
            modus = self.sleeping_motion
        
        if modus == "X-Mas":
            modus = self.xmas
            
        if modus == "Relax":
            modus = self.relax
            
        if modus == "Pulsar":
            #modus = pulsar
            return
            
        if modus == "Crazy Alien":
            modus = self.crazy_alien
            
            
        if modus == "Earth":
            modus = self.earth
            
        try:    
            if modus.get_Status() == True:
                return
        except:
            pass

        else:
            
            if modus == self.benutzerdefiniert:
                modus.start(data["color1"], data["color2"], data["color3"], data['dimmValue1'], data['dimmValue2'], data['dimmValue3'])
            else:
                try:
                    print("Lampmodel Interpreter versuche " ,modus, " zu starten")
                    modus.start()
                except: print (modus, " konnte nicht gestartet werden")
                    
                self.ischanged = True
        
        
    def try_stop_all_other_modes(self, exception):
        print("IN METHODE GEKOMMEN :D")
        if exception == "Rainy Days":
            exceptions = [self.rainy_days]
        
        elif exception == "Rainbow":
            exceptions = [self.rainbow]
            
        elif exception == "Benutzerdefiniert":
            exceptions = [self.benutzerdefiniert]
            
        elif exception == "Indigo Cure":
            exceptions = [self.indigo_cure]
        
        elif exception == "Galaxy":
            exceptions = [self.galaxy]
        
        elif exception == "Sleeping Motion":
            exceptions = [self.sleeping_motion]
        
        elif exception == "X-Mas":
            exceptions = [self.xmas]
            
        elif exception == "Relax":
            exceptions = [self.relax]
            
        #elif exception == "Pulsar":
            #exceptions = [pulsar]
            #pass
            
            
        elif exception == "Crazy Alien":
            exceptions = [self.crazy_alien]
            
            
        elif exception == "Earth":
            exceptions = [self.earth]
            
        else:
            exceptions = []
         
        #es können aktuell wegen memory alloc fehler nicht alle led programme abgefragt werden daher nur testweise indigo_cure und benutzerdefiniert
        # all_modes = [rainy_days, rainbow, indigo_cure, benutzerdefiniert, pulsar, galaxy, sleeping_motion, xmas, relax, earth, crazy_alien]  # Add all the modes here    
        all_modes = [self.rainy_days, self.rainbow, self.indigo_cure, self.benutzerdefiniert, self.galaxy, self.sleeping_motion, self.xmas, self.relax, self.earth, self.crazy_alien ]  # Add all the modes here
        for mode in all_modes:
            if mode not in exceptions and mode.get_Status() == True:
                try:
                    print ("Versuche, ", mode, " zu beenden")
                    mode.stop()
                except Exception as e:
                    print("Fehler aufgetreten beim Versuch, ", mode," zu stoppen: ", repr(e))
                    mode.stop()
            '''       
            #test ob dann die led programme sauberer beendet werden (sollte ein thread noch laufen aber get-status nicht richtig reagieren
            try:
                mode.stop()
            except Exception as e:
                print("2. Durchlauf alle Modies beenden ohne get_Status zu prüfen, Fehler aufgetreten: ", e)
            '''
                
              
        
