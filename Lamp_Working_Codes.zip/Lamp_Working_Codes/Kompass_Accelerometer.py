import time

import board
import digitalio
from adafruit_bus_device import i2c_device
import math


class MC64XX:
    ACCL_DATA_REG_ADDR = 0x10
    SR_REG_ADDR = 0x1D
    MODE_REG_ADDR = 0x1B
    RANGE_REG_ADDR = 0x1E
    SENSITIVITY = 0.15
    I2C_ADDR = 0x0C
    RANGE = 0x10  # E_M_DRV_MC6700_RANGE_15BIT

    def __init__(self, i2c: board.I2C):
        self.i2c_device = i2c_device.I2CDevice(i2c, self.I2C_ADDR)
        self.init_sensor()

    def init_sensor(self):
        self.set_SR()
        self.set_dynamic_range()
        self.set_cont_mode()

    def write_to_device(self, register: int, data: bytearray):
        with self.i2c_device as i2c:
            i2c.write(bytes([register] + list(data)))

    def read_from_device(self, register: int, num_bytes: int):
        data = bytearray(num_bytes)
        with self.i2c_device as i2c:
            i2c.write_then_readinto(bytearray([register]), data)
        return data

    def set_SR(self):
        self.write_to_device(self.SR_REG_ADDR, bytearray([0x80]))
        self.write_to_device(self.SR_REG_ADDR, bytearray([0x80]))

    def set_cont_mode(self):
        self.write_to_device(self.MODE_REG_ADDR, bytearray([0x80 | 0x18]))
        self.write_to_device(self.MODE_REG_ADDR, bytearray([0x80 | 0x18]))

    def set_dynamic_range(self):
        self.write_to_device(self.RANGE_REG_ADDR, bytearray([0x80 | self.RANGE]))
        self.write_to_device(self.RANGE_REG_ADDR, bytearray([0x80 | self.RANGE]))

    def read_data(self):
        data = self.read_from_device(self.ACCL_DATA_REG_ADDR, 6)
        ax = ((data[1] << 8) | data[0])
        ay = (data[3] << 8) | data[2]
        az = (data[5] << 8) | data[4]

        print("read Data MC64XX ,", ax ," ", ay, " ", az)

        # Berechne die Sensitivität und gib sie zurück
        return [ax * self.SENSITIVITY, ay * self.SENSITIVITY, az * self.SENSITIVITY]


class Accelerometer:
    ADDR_A5_0 = 0x4C
    ADDR_A5_1 = 0x6C
    RESOLUTION_14_BIT = 0b101
    RANGE_8g = 0b010
    CONFIG_REG_ADDR = 0x20
    MODE_REG_ADDR = 0x07
    WAKE_UP_MODE = 0x01
    ACCL_DATA_REG_ADDR = 0x0D
    GRAVITATIONAL_ACCELERATION = 9.81
    SENSITIVITY = 0.15

    MAGNETIC_SENSOR_ADDR = 0x0C
    MAGNETIC_SENSOR_DATA_REG_ADDR = 0x10
    MAGNETIC_SENSOR_POWER_MODE_REGISTER = 0x1b
    MAGNETIC_POWER_MODE_VALUE = 0x25

    def __init__(self, i2c_bus, A5_state=0, resolution=RESOLUTION_14_BIT, range=RANGE_8g):
        if A5_state == 0:
            self.address = Accelerometer.ADDR_A5_0
        else:
            self.address = Accelerometer.ADDR_A5_1

        print("Init_Accelerometer a5 State = ", self.address)
        self.i2c_device = i2c_device.I2CDevice(i2c_bus, self.address)
        self.range = range
        self.resolution = resolution
        config = (range << 4) | resolution
        self.magnetometersensitivity = 0.15

        # Accelerometer init
        with self.i2c_device as i2c:
            i2c.write(bytearray([Accelerometer.CONFIG_REG_ADDR, config]))
            time.sleep(0.1)
            i2c.write(bytearray([Accelerometer.MODE_REG_ADDR, Accelerometer.WAKE_UP_MODE]))
            time.sleep(0.1)

    @staticmethod
    def get_data_length_in_bits(resolution):
        switcher = {
            0: 6,
            1: 7,
            2: 8,
            3: 10,
            4: 12,
            5: 14,
        }
        return switcher.get(resolution)

    @staticmethod
    def get_angle_in_degrees(ax, ay):
        rad = math.atan2(ay, ax)
        # deg = rad * (180.0/math.pi) + 180
        deg = math.degrees(rad) + 180
        return deg

    def convert_digital_to_analog_magnetometer(self, digital_value):
        if digital_value & 0x8000 > 0:
            analog_value = -(((~digital_value) & 0xFFFF) + 1)
        else:
            analog_value = digital_value
        analog_value *= self.magnetometersensitivity
        return analog_value

    def convert_digital_to_analog(self, digital_value):
        if (digital_value & 0x8000 > 0):
            analog_value = -(((~digital_value) & 0xFFFF) + 1)
        else:
            analog_value = digital_value
        analog_value *= (2 ** (self.range + 1)) * Accelerometer.GRAVITATIONAL_ACCELERATION / (
                (2 ** (Accelerometer.get_data_length_in_bits(self.resolution) - 1)) - 1)
        return analog_value

    def get_data(self):
        #print("get Data aufgerufen")
        data = bytearray(6)
        try:
            with self.i2c_device as i2c:
                i2c.write(bytearray([Accelerometer.ACCL_DATA_REG_ADDR]))
                i2c.readinto(data)
        except Exception as e:
            print("Fehler in get Data", e)

        ax = ((data[1] << 8) | data[0])
        ax = self.convert_digital_to_analog(ax)
        ay = (data[3] << 8) | data[2]
        ay = self.convert_digital_to_analog(ay)
        az = (data[5] << 8) | data[4]
        az = self.convert_digital_to_analog(az)
        return (ax, ay, az)

    def get_data_magnetic_sensor(self):
        data = bytearray(6)
        with self.i2c_device as i2c:
            i2c.write(bytearray([Accelerometer.MAGNETIC_SENSOR_DATA_REG_ADDR]))
            i2c.readinto(data)

        ax = ((data[1] << 8) | data[0])
        ax = self.convert_digital_to_analog_magnetometer(ax)
        ay = (data[3] << 8) | data[2]
        ay = self.convert_digital_to_analog_magnetometer(ay)
        az = (data[5] << 8) | data[4]
        az = self.convert_digital_to_analog_magnetometer(az)

        print("Magnetic Sensor data output nach Umwandlung: ax:", ax, "ay:", ay, "az:", az)
        return [ax, ay, az]

    def get_orientation_angles(self):
        ax, ay, az = self.get_data()

        # ax1, ay1, az1 = self.get_data()

        # ax2, ay2, az2 = self.get_data()

        # ax = (ax + ax1 + ax2) /3
        # ay = (ay + ay1 + ay2) /3
        # az = (az + az1 + az2) /3

        # Berechnen des Pitch-Winkels
        pitch = math.atan2(-ax, math.sqrt(ay * ay + az * az))
        # Berechnen des Roll-Winkels
        roll = math.atan2(ay, az)

        # Umrechnen in Grad
        pitch = math.degrees(pitch)
        roll = math.degrees(roll)

        return roll, pitch

    ### Das hier ist die wichtigste Methode zum erhalten der benötigten Kompasswerte welche wiederrum durch die get_angle_in Degrees methode eingebunden wird.

    def get_tilt_compensated_data(self):
        # Beschleunigungsmesserdaten lesen
        ax, ay, az = self.get_data()

        # Magnetometerdaten lesen
        mag_x, mag_y, mag_z = self.get_data_magnetic_sensor()

        # noch je 2 mal messen um genauere werte zu erhalten

        # ax1, ay1, az1 = self.get_data()

        # mag_x1, mag_y1, mag_z1 = self.get_data_magnetic_sensor()

        # ax2, ay2, az2 = self.get_data()

        # mag_x2, mag_y2, mag_z2 = self.get_data_magnetic_sensor()

        # nun werte zusammenrechnen und durch 3 nehmen

        # ax = (ax + ax1+ ax2) / 3
        # ay = (ay + ay1 +ay2) /3
        # az = (az + az1 + az2) / 3

        # mag_x = (mag_x + mag_x1 + mag_x2) /3
        # mag_y = (mag_y + mag_y1 + mag_y2) /3
        # mag_z = (mag_z + mag_z1 + mag_z2) /3

        # Roll- und Pitch-Winkel berechnen
        roll = math.atan2(ay, az)
        pitch = math.atan2(-ax, math.sqrt(ay * ay + az * az))

        # Neigungskorrigierte Magnetometerdaten berechnen
        mag_x_comp = mag_x * math.cos(pitch) + mag_y * math.sin(roll) * math.sin(pitch) + mag_z * math.cos(
            roll) * math.sin(pitch)
        mag_y_comp = mag_y * math.cos(roll) - mag_z * math.sin(roll)

        return mag_x_comp, mag_y_comp



class Kompass:
    def __init__(self, i2c):
        self.SENSOR_POWER_ON_PIN_NUMBER = board.D8  # Sie können den Pin gemäß Ihrer Hardwarekonfiguration ändern
        self.sensor_power_on = digitalio.DigitalInOut(self.SENSOR_POWER_ON_PIN_NUMBER)
        self.sensor_power_on.direction = digitalio.Direction.OUTPUT
        self.sensor_power_on.value = True
        time.sleep(0.030)  # Umwandlung in Sekunden

        self.accelerometer = Accelerometer(i2c)
        self.magnetometer = MC64XX(i2c)
        self.i2c = i2c

    def get_tilt(self):
        if not self.sensor_power_on.value:
            self.sensor_power_on.value = True
            time.sleep(0.050)
        tiltwerte = self.accelerometer.get_orientation_angles()
        print("Erhaltene Tiltwerte: roll:", tiltwerte[0], ", pitch:", tiltwerte[1])
        return tiltwerte[0] # returned roll nicht pitch für gyro reset

    def get_orientation(self):
        if not self.sensor_power_on.value:
            print("get_orientation sensor power ist 0")
            self.sensor_power_on.value = True
            time.sleep(0.050)
        postionswerte = self.accelerometer.get_tilt_compensated_data()
        degree = self.accelerometer.get_angle_in_degrees(postionswerte[0], postionswerte[1])
        print("Neigungskompensierter Winkel: ", degree, " Grad")
        return degree

    def turn_sensor_power_off(self):
        self.sensor_power_on.value = False

i2c_bus = board.I2C()
kompass = Kompass(i2c_bus)


# while True:
#
#     kompass.get_orientation()
#     # kompass.get_tilt()
#     time.sleep(1)


