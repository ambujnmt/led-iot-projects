import Kompass_Accelerometer
from tilt_motor_control import Tilt_MotorControl
from rotation_motor_control import Rotation_MotorControl
import board
import json
import threading
import os
import time
from concurrent.futures import ThreadPoolExecutor
import control_sun_tracking
import control_compass
from shared_ressources import shared_resources
import busio



i2c = busio.I2C(board.SCL, board.SDA)
magnetometer = control_compass.Magnetometer(i2c)
time.sleep(0.5)
fail_save = 0

while True:
    x, y, z = magnetometer.read_magnetic_field()
    heading = magnetometer.get_heading(x, y)

    heading = int(heading)

    print(heading)
    time.sleep(1)