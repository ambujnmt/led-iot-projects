import threading
import time

import led_programm_bluetooth_active

test = led_programm_bluetooth_active.bt_led()

stop = threading.Event()
run = True
count = 0
start = 1
bt_blink_thread = threading.Thread(target=test.advertisingblinking, args=(stop,))



for _ in range(20):
    time.sleep(1)
    count = count + 1


    if start == 1:
        print("start: ", count)
        bt_blink_thread.start()
        start = 0
    print("For count: ", count)
    if count == 5:
        stop.set()
        time.sleep(1)
        teaaaa = threading.Thread(target=test.connected)
        teaaaa.start()
        time.sleep(3)

