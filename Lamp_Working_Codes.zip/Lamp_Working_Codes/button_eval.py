# import time
# import digitalio
# import board
#
# def evaluate_button():
#     # Initialize the button
#     button = digitalio.DigitalInOut(board.D26)  # Adjust the pin as needed
#     button.direction = digitalio.Direction.INPUT
#     button.pull = digitalio.Pull.UP  # Assumes an internal pull-up resistor is used
#
#     print("Evaluating button state. Press CTRL+C to exit.")
#
#     try:
#         while True:
#             button_state = button.value
#             if button_state:
#                 print("Button is released (button.value = True)")
#             else:
#                 print("Button is pressed (button.value = False)")
#             time.sleep(0.5)  # Adjust the delay as needed
#
#     except KeyboardInterrupt:
#         print("Exiting button evaluation.")
#
# if __name__ == "__main__":
#     evaluate_button()
# import time
# import board
# import digitalio
#
# button = digitalio.DigitalInOut(board.D26)
# button.direction = digitalio.Direction.INPUT
# button.pull = digitalio.Pull.UP
#
# last_pressed_time = time.monotonic()
# debounce_duration = 1  # 500 milliseconds
#
# print("Monitoring the touch button. Press Ctrl+C to exit.")
#
# while True:
#     if not button.value:  # Button is pressed
#         last_pressed_time = time.monotonic()
#         print("Button State: Pressed")
#     elif time.monotonic() - last_pressed_time > debounce_duration:
#         # Only consider it released if it's been released for more than the debounce duration
#         print("Button State: Released")
#
#     time.sleep(0.1)
import time
import board
import digitalio

button = digitalio.DigitalInOut(board.D26)  # Adjust the pin as necessary
button.direction = digitalio.Direction.INPUT
button.pull = digitalio.Pull.UP  # Adjust this based on your button's wiring

# Dynamic thresholding parameters
history_length = 10  # Number of recent states to consider
state_history = []  # Stores the recent history of states
press_threshold = 0.7  # Threshold to consider the button pressed based on history

print("Monitoring the touch button with dynamic thresholding. Press Ctrl+C to exit.")

while True:
    # Read the current state (Pressed = False, Released = True in Pull-UP configuration)
    current_state = button.value

    # Update the state history
    state_history.append(current_state)
    if len(state_history) > history_length:
        state_history.pop(0)  # Remove the oldest entry

    # Calculate the average of the recent states (False = 0, True = 1)
    average_state = sum(state_history) / len(state_history)

    # Determine the button state based on the dynamic threshold
    if average_state < press_threshold:
        print("Button State: Pressed")
    else:
        print("Button State: Released")

    time.sleep(0.1)  # Adjust the sleep time if needed
