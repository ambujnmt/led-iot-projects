def erstelle_textdatei():
    with open('etc/test.txt', 'w') as datei:
        datei.write('Dies ist ein Test.\n')
        datei.write('Hallo, Welt!')



def main():
    erstelle_textdatei()


main()