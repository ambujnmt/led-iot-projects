#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time

import random
import gc

class SleepingMotion:
    def __init__(self, touchenabled):
             
        manager.add_programm(self)    
            
        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12
        
        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)
        
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = board.D12 #18        
        
        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23        
        '''
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23
        
        #Belegung ESP32 Platine
        
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''


        # Define the colors
        
        self.ORANGE = [(255, 51, 0, 0)]
        
        self.YELLOW = [(255, 255, 0, 0)]      


        self.sleeping_motion_running = False
        self.thread_running = None
        self.paused = False
        
        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.sleeping_motion_on = False
        
        print("Relax wurde initialisiert")

        self.thread_mid = None

        self.init = True
        
        time.sleep(0.1)

    def np_top_array(self, position, value):
        
         self.np[position] = value
    
    def np_mid_array(self, position, value):
        
        #print("Position mid array: ", position)
   
        
        self.np[position + self.NUM_LEDS_TOP] = value
    
    def bottom1_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value
    
    def bottom2_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value
        
    def bottom3_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value


        
    '''
    async def async_mid_led_on(self):
        for i in range(self.NUM_LEDS_MID):
            self.np_mid[i] = (255, 0, 0, 0) # Hier wird der RGBW-Wert (255, 0, 0, 0) für Rot gesetzt
            self.np_mid.write()
            time.sleep(0.5) # Hier wird eine kurze Pause eingelegt, um die LED-Farbe zu aktualisieren

        # Schalten Sie den LED-Streifen aus
        self.np_mid.fill((0, 0, 0, 0)) # Hier werden alle LEDs ausgeschaltet
        self.np_mid.write()
        
    '''
        

    def sleeping_motion_loop(self, stop_event, diming, change_timing = True):

        if diming:
            #self.ORANGE = [(128,26, 0, 0)] 50% gedimmt
            #self.YELLOW = [(128, 128, 0, 0)]
            
                # auf 25% gedimmt

                self.ORANGE = [(64, 13, 0, 0)]
                self.YELLOW = [(64, 64, 0, 0)]

                print("hallooooooo")

        gc.enable()
        r4 = 0
        r5 = 0
        
        brightness = 0.0
        switch_brightness = 0
        
        current_Color = self.ORANGE[0]
        
        current_mid_Color = self.YELLOW[0]
        
        color_round = 0
        
        start = True
        
        current_mid_led = 97
        
        '''
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        '''
        

        while self.sleeping_motion_on:
            
            '''
            if self.sleeping_motion_running == False:
                return
            '''
            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''
            
            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            if change_timing == True:
                time.sleep(0.01)
           
            
            r4 = r4 + 1
            r5 = r5 + 1
            if(r4 == 1):
                
                if brightness == 0.0:
                    switch_brightness = 1
                    if color_round == 1:
                        print('new color')
                        if current_Color == self.ORANGE[0]:
                            
                            current_Color = self.YELLOW[0]
                        else:
                            current_Color = self.ORANGE[0]
                        color_round = 0
                    
                
                if brightness == 100.0:
                    switch_brightness = 0
                    color_round = 1
                
                if switch_brightness == 1:
                    brightness += 1.0
                else:
                    brightness -= 1.0
                    
                
                
                
                
                # TOP - LEDS
                self.np_top_array(0, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(1, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(2, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(3, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(4, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(5, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(6, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(7, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(8, self.scale_color(current_Color, brightness, stop_event))
                self.np_top_array(9, self.scale_color(current_Color, brightness, stop_event))

                if change_timing == True:
                    time.sleep(0.01)
                
                # MID - LEDS
                if start == True:
                    self.mid_led_start(100.0, stop_event)
                    start = False
                
                if r5 == 2:
                    
                    if(current_mid_led < 0):
                        current_mid_led = 97
                        if current_mid_Color == self.YELLOW[0]:
                            current_mid_Color = self.ORANGE[0]
                        else:
                            current_mid_Color = self.YELLOW[0]
                    
                    self.np_mid_array(current_mid_led, self.scale_color(current_mid_Color, 100.0, stop_event))
                    
                    current_mid_led -= 1
                    
                    r5 = 0
                
                
                
                
                
                # BOTTOM - LEDS   
                self.bottom1_array(0, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(1, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(2, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(3, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(4, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(5, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(6, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(7, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(8, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(9, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(10, self.scale_color(current_Color, brightness, stop_event))
                self.bottom1_array(11, self.scale_color(current_Color, brightness, stop_event))

                self.bottom2_array(0, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(1, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(2, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(3, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(4, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(5, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(6, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(7, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(8, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(9, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(10, self.scale_color(current_Color, brightness, stop_event))
                self.bottom2_array(11, self.scale_color(current_Color, brightness, stop_event))
                
                self.bottom3_array(0, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(1, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(2, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(3, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(4, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(5, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(6, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(7, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(8, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(9, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(10, self.scale_color(current_Color, brightness, stop_event))
                self.bottom3_array(11, self.scale_color(current_Color, brightness, stop_event))
    
                if change_timing == True:
                    time.sleep(0.01)
                
                
                r4 = 0
                
            #soll relax beendet werden?
            if stop_event.is_set():
                self.stop()
                return
            
            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()
            
           # print("Sleeping Motion Leuchtprigramm hat funltionier :)")
        
        print("hat irgendwie nicht funktioniert")
            
    
    def mid_led_start(self, brightness, stop_event):
        # MID - LEDS
        self.np_mid_array(0, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(1, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(2, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(3, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(4, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(5, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(6, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(7, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(8, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(9, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(10, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(11, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(12, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(13, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(14, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(15, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(16, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(17, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(18, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(19, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(20, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(21, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(22, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(23, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(24, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(25, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(26, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(27, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(28, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(29, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(30, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(31, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(32, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(33, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(34, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(35, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(36, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(37, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(38, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(39, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(40, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(41, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(42, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(43, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(44, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(45, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(46, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(47, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(48, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(49, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(50, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(51, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(52, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(53, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(54, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(55, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(56, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(57, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(58, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(59, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(60, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(61, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(62, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(63, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(64, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(65, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(66, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(67, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(68, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(69, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(70, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(71, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(72, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(73, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(74, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(75, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(76, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(77, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(78, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(79, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(80, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(81, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(82, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(83, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(84, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(85, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(86, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(87, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(88, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(89, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(90, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(91, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(92, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(93, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(94, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(95, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(96, self.scale_color(self.ORANGE[0], brightness, stop_event))
        self.np_mid_array(97, self.scale_color(self.ORANGE[0], brightness, stop_event))
    
    def mid_led(self):
        for i in range(self.NUM_LEDS_MID):
            self.np_mid_array(i, (255, 0, 0, 0)) # Hier wird der RGBW-Wert (255, 0, 0, 0) für Rot gesetzt
            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()
            time.sleep(0.5) # Hier wird eine kurze Pause eingelegt, um die LED-Farbe zu aktualisieren        

    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    def scale_color(self, color_tupel, brightness, stop_event):
        
        floatbrightness = float(brightness)
        
        r, g, b, w = color_tupel
        
        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)
        
        floatbrightness = floatbrightness / 100.0
        
        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)
        
        return (r, g, b, w)


    def start(self, stop_event, diming):
        #print("start Sleeping Motion innerhalb Sleeping Motion Klasse getrigget!")
        self.sleeping_motion_on = True
        self.sleeping_motion_loop(stop_event, diming)         
        
        '''
        print("Start SLEEEEEEEPINNNGGGG MOOOTTTIIIOOOON_____________________________")
        
        # time.sleep()
        self.sleeping_motion_running = True
        self.thread_running = None

        try:
            self.thread_running = _thread.start_new_thread(self.sleeping_motion_on, ())

        except:

            time.sleep_ms(70)
            self.start()

         
        return True
        '''

    def stop(self):
        self.sleeping_motion_on = False
        self.sleeping_motion_off()
        self.np.deinit()         
        
        '''
        self.sleeping_motion_running = False

        # self.thread_mid.exit()

        if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            self.thread_running.exit()

        self.sleeping_motion_off()
        '''

    def sleeping_motion_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.sleeping_motion_on


#sleeping_motion = SleepingMotion(False)
# 
# time.sleep(1)
# 
#sleeping_motion.start()

#sleeping_motion = SleepingMotion(False)
#stop_event = multiprocessing.Event()
#diming = True
#sleeping_motion.start(stop_event, diming)
