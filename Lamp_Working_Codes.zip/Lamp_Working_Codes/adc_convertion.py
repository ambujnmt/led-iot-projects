import smbus
import time

# Constants for the BQ25731
BQ25731_I2C_ADDR = 0x6B  # Replace with your device's I2C address if it's different

# ADCOption Register and its bits
ADCOPTION_REG = 0x3B
EN_ADC_VBAT = 0  # Enable ADC conversion of the battery voltage
EN_ADC_VSYS = 1  # Enable ADC conversion of the system voltage
EN_ADC_ICHG = 2  # Enable ADC conversion of the charge current
EN_ADC_IDCHG = 3  # Enable ADC conversion of the discharge current
ADC_START = 6  # Start ADC conversion
ADC_CONV = 7  # ADC conversion done

# Initialize the I2C bus
bus = smbus.SMBus(1)  # 1 indicates /dev/i2c-1

# Function to write to a register
def write_register(addr, reg, value):
    try:
        bus.write_byte_data(addr, reg, value)
    except Exception as e:
        print(f"Failed to write to I2C device: {e}")

# Function to read from a register
def read_register(addr, reg):
    try:
        return bus.read_byte_data(addr, reg)
    except Exception as e:
        print(f"Failed to read from I2C device: {e}")
        return None

# Set ADC options - enabling the battery voltage and current ADC conversions

def enable():
    adc_option_value = (1 << EN_ADC_ICHG) | (1 << EN_ADC_IDCHG) | (1 << ADC_START)
    write_register(BQ25731_I2C_ADDR, ADCOPTION_REG, adc_option_value)



def print_register_bits(i2c_addr, reg_addr):
    try:
        # Read a byte from the specified register
        reg_value = bus.read_byte_data(i2c_addr, reg_addr)
        # Convert the byte value to a string of bits
        bit_str = format(reg_value, '08b')  # Convert to a binary string
        # Print each bit
        print(f"Register 0x{reg_addr:02X} value: 0b{bit_str} (0x{reg_value:02X})")
        print("Bit by bit:")
        for i, bit in enumerate(bit_str[::-1]):  # Reverse the string to match 0-indexing of bits
            print(f"Bit {i}: {bit}")
    except Exception as e:
        print(f"Failed to read from I2C device: {e}")


def print_regs():
    reg = input("insert register (0x2A):")
    print_register_bits(0x6B, int(reg, 16))  # Hypothetical address for charge current

print_regs()