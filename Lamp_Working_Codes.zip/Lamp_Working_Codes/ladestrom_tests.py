import smbus
import time

class BQ25731:
    def __init__(self, i2c_bus=1):
        self.device_address = 0x6B  # I2C-Adresse des BQ25731
        self.i2c = smbus.SMBus(i2c_bus)

    def set_charge_current(self, current):
        # Ladestrom-Register

        # CHARGE_CURRENT_REG_03 = 0x03
        CHARGE_CURRENT_REG_02 = 0x02

        # Bereite die Werte vor, die in die Register geschrieben werden sollen
        if current == 1:  # 1 A
            reg_values = [0x00, 0x02]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]
        elif current == 2:  # 1.75 A
            reg_values = [0x40, 0x03]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]
        elif current == 3:  # 3 A
            reg_values = [0x00, 0x06]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]
        elif current == 4:  # 4 A
            reg_values = [0x00, 0x08]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]
        elif current == 5:  # 8 A
            reg_values = [0x00, 0x10]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]
        else:  # Default 350 mA (nächstniedrigerer Wert ist 256 mA)
            reg_values = [0x80, 0x00]  # [CHARGE_CURRENT_REG_03, CHARGE_CURRENT_REG_02]

        # Schreibe die Werte in die Register in einer einzigen I²C-Transaktion
        # Hinweis: block_write erfordert eine Liste von Werten
        # auto increments the reg_address and writes next value
        self.i2c.write_i2c_block_data(self.device_address, CHARGE_CURRENT_REG_02, reg_values)
        time.sleep(0.5)

# Erstellen Sie eine Instanz der Klasse
# charger = BQ25731()
#
# # Setzen Sie den Ladestrom auf 1A
# charger.set_charge_current(1)
