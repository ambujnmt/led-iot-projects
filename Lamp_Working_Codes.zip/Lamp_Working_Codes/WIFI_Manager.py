import subprocess
import time
import re


def run_command(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True, check=True)
    return result.stdout


class Wifi_Connection:

    @classmethod
    def get_wlan_and_bt_status(cls):
        output = run_command("rfkill list")
        entries = output.split("1")
        wlan_info, bt_info = None, None
        for entry in entries:
            if "Wireless LAN" in entry:
                wlan_info = entry
            if "Bluetooth" in entry:
                bt_info = entry
        return wlan_info, bt_info

    @classmethod
    def enable_wifi(cls):
        run_command("sudo rfkill unblock wifi")
        while True:
            wlan_output, bluetooth_output = Wifi_Connection.get_wlan_and_bt_status()
            if not ("Soft blocked: yes" in wlan_output or "Hard blocked: yes" in wlan_output):
                print("WiFi module enabled")
                time.sleep(1)
                return

    @classmethod
    def disable_wifi(cls):
        run_command("sudo rfkill block wifi")
        while True:
            wlan_output, bluetooth_output = Wifi_Connection.get_wlan_and_bt_status()
            if not ("Soft blocked: no" in wlan_output or "Hard blocked: no" in wlan_output):
                print("WiFi module disabled")
                time.sleep(1)
                return

    @classmethod
    def wifi_is_connected(cls):
        try:
            result = subprocess.run(['iwconfig'], capture_output=True, text=True, check=True)
            if "ESSID:off/any" in result.stdout:
                return False
            return True
        except subprocess.CalledProcessError:
            return False

    @classmethod
    def get_single_ip_attempt(cls):
        try:
            result = subprocess.run(['ip', 'addr', 'show', 'wlan0'], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True)
            ip_match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', result.stdout)
            if ip_match:
                return ip_match.group(1)
            else:
                return 'false'
        except:
            return 'false'

    @classmethod
    def get_ip(cls, attempts=10):
        for attempt in range(attempts):
            ip_address = cls.get_single_ip_attempt()
            if ip_address != 'false':
                print("Current IP address of RasPI: ", ip_address)
                return ip_address
            else:
                print(f"Attempt {attempt + 1} of {attempts}, retrying in 1 second...")
                time.sleep(1)
        return "false"

    @classmethod
    def scan_for_ssids(cls):
        ssids = [cell.ssid for cell in Cell.all('wlan0')]
        return ssids

    @classmethod
    def get_current_wlan_config(cls, interface="wlan0"):
        ip_result = subprocess.run(["hostname", "-I"], capture_output=True, text=True)
        ip_address = ip_result.stdout.strip().split()[0]

        route_result = subprocess.run(["route", "-n"], capture_output=True, text=True)
        lines = route_result.stdout.strip().split("\n")
        router = [line.split()[1] for line in lines if line.endswith(interface)][0]

        with open("/etc/resolv.conf", "r") as file:
            dns_lines = file.readlines()
        dns_servers = [line.split(" ")[1].strip() for line in dns_lines if line.startswith("nameserver")]

        return ip_address, router, " ".join(dns_servers)

    @classmethod
    def connect_to_wifi(cls, ssid, password):
        Wifi_Connection.enable_wifi()
        try:
            result = subprocess.run(["systemctl", "is-active", "--quiet", "NetworkManager"])
            if result.returncode != 0:
                print("NetworkManager is not running. Attempting to start it...")
                subprocess.run(["sudo", "systemctl", "start", "NetworkManager"], check=True)

                result = subprocess.run(["systemctl", "is-active", "--quiet", "NetworkManager"])
                if result.returncode != 0:
                    print("Failed to start NetworkManager. Please check system logs for details.")
                    return
                else:
                    print("NetworkManager successfully started.")

            time.sleep(3)
            result = subprocess.run(["nmcli", "-t", "connection", "show", "--active"], stdout=subprocess.PIPE,
                                    text=True)
            active_connections = result.stdout.split('\n')
            print(active_connections)
            for connection in active_connections:
                if "802-11-wireless" in connection:
                    conn_name = connection.split(':')[0]
                    subprocess.run(["nmcli", "connection", "delete", conn_name], check=True)
                    print(f"Existing connection '{conn_name}' has been deleted.")
                    Wifi_Connection.connect_to_wifi(ssid, password)
                    return

            print(f"Attempting to connect to new SSID \'{ssid}\' with password {password}")
            create_cmd = f"nmcli connection add type wifi ifname wlan0 con-name \'{ssid}\' ssid \'{ssid}\'"
            run_command(create_cmd)

            modify_cmd1 = f"nmcli connection modify \'{ssid}\' wifi-sec.key-mgmt wpa-psk"
            run_command(modify_cmd1)

            modify_cmd2 = f"nmcli connection modify \'{ssid}\' wifi-sec.psk \"{password}\""
            run_command(modify_cmd2)

            connect_cmd = f"nmcli connection up \'{ssid}\'"
            run_command(connect_cmd)

            print(f"Successfully connected to '{ssid}'")

            print("Obtaining IP address from DHCP...")
            run_command(f"nmcli connection modify \'{ssid}\' ipv4.method auto")
            run_command(f"nmcli connection up \'{ssid}\'")

            result = subprocess.run(["nmcli", "connection", "show", ssid], capture_output=True, text=True)
            output = result.stdout
            ip_info = ""
            ip_address = ""
            gateway = " "
            netmask = ""
            for line in output.split('\n'):
                if line.startswith("IP4.ADDRESS[1]:"):
                    ip_info = line.split(":")[1].strip()
                    ip_address, netmask = ip_info.split('/')
                elif line.startswith("IP4.GATEWAY:"):
                    gateway = line.split(":")[1].strip()
            print("Data from DHCP: ", ip_info)
            print("IPv4 address from DHCP: ", ip_address)
            print("Received gateway value:", gateway)

            print(f"Setting static IP address to {ip_address}...")
            run_command(
                f"nmcli connection modify \'{ssid}\' ipv4.method manual ipv4.addresses {ip_address}/{netmask} ipv4.gateway {gateway}")
            run_command(f"nmcli connection up \'{ssid}\'")

            subprocess.run(["sudo", "systemctl", "restart", "NetworkManager"], check=True)

            print("Connection successful with static IP address set.")
        except subprocess.CalledProcessError as e:
            print(f"Command failed: {e}")
            return False
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
        return True

    # @classmethod
    # def get_mac_address(cls, interface="wlan0"):
    #     result = subprocess.run(["ip", "link", "show", interface], capture_output=True, text=True)
    #     output = result.stdout
    #
    #     for line in output.split("\n"):
    #         if "link/ether" in line:
    #             return line.split()[1]
    #
    #     return None

    @classmethod
    def get_mac_address(cls, interface="wlan0"):
        try:
            result = subprocess.run(["ethtool", "-P", interface], capture_output=True, text=True)
            output = result.stdout
            # Answer looks like this normally: "Permanent address: XX:XX:XX:XX:XX:XX"
            if "Permanent address:" in output:
                return output.split()[-1]  # Mac-address is last word in output
        except Exception as e:
            print(f"Error calling permanent MAC-Address: {e}")

        return None

    # def get_permanent_mac_address(cls, interface="wlan0"):
    #     try:
    #         result = subprocess.run(["ethtool", "-P", interface], capture_output=True, text=True)
    #         output = result.stdout
    #         # Ausgabe sieht in der Regel so aus: "Permanent address: XX:XX:XX:XX:XX:XX"
    #         if "Permanent address:" in output:
    #             return output.split()[-1]  # Die MAC-Adresse ist das letzte Wort in der Ausgabe
    #     except Exception as e:
    #         print(f"Fehler beim Abrufen der permanenten MAC-Adresse: {e}")
    #
    #     return None

    @classmethod
    def delete_all_wifi_credentials(cls):
        try:
            connections = subprocess.run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"],
                                         stdout=subprocess.PIPE, text=True).stdout
            for connection in connections.split('\n'):
                if connection and "802-11-wireless" in connection:
                    conn_name = connection.split(':')[0]
                    subprocess.run(["nmcli", "connection", "delete", conn_name], check=True)
                    print(f"WLAN connection '{conn_name}' has been deleted.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to delete WLAN credentials: {e}")

    @classmethod
    def set_static_ip(interface="wlan0"):
        import os
        static_ip, router, domain_name_server = Wifi_Connection.get_current_wlan_config()
        config_lines = [
            f"\ninterface {interface}",
            f"static ip_address={static_ip}",
            f"static routers={router}",
            f"static domain_name_servers={domain_name_server}\n"
        ]

        with open("/etc/dhcpcd.conf", "a") as file:
            file.writelines(config_lines)

        os.system("sudo service dhcpcd restart")

# Example usage:
# available_ssids = Wifi_Connection.scan_for_ssids()
# print(available_ssids)

# Connect to a Wi-Fi network
# Wifi_Connection.connect_to_wifi('YourSSID', 'YourPassword')
