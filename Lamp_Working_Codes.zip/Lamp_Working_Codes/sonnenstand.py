# sunpos.py
# https://levelup.gitconnected.com/python-sun-position-for-solar-energy-and-research-7a4ead801777
# John Clark Craig
import math
import datetime

# FÃ¼r TESTS folgende Seite verwenden: https://www.sonnenverlauf.de/#/48.8593,9.2176,9/2023.02.27/07:14/1/3






class Sunposition():
    
    def __init__(self):
        self.azimuth = None
        self.elevation = None

    def sunpos(self, when, location, refraction):
        # Extract the passed data
        year, month, day, hour, minute, second, timezone = when
        latitude, longitude = location
        # Math typing shortcuts
        rad, deg = math.radians, math.degrees
        sin, cos, tan = math.sin, math.cos, math.tan
        asin, atan2 = math.asin, math.atan2
        # Convert latitude and longitude to radians
        rlat = rad(latitude)
        rlon = rad(longitude)
        # Decimal hour of the day at Greenwich
        greenwichtime = hour - timezone + minute / 60 + second / 3600
        # Days from J2000, accurate from 1901 to 2099
        daynum = (
            367 * year
            - 7 * (year + (month + 9) // 12) // 4
            + 275 * month // 9
            + day
            - 730531.5
            + greenwichtime / 24
        )
        # Mean longitude of the sun
        mean_long = daynum * 0.01720279239 + 4.894967873# Mean anomaly of the Sun
        mean_anom = daynum * 0.01720197034 + 6.240040768# Ecliptic longitude of the sun
        eclip_long = (
            mean_long
            + 0.03342305518 * sin(mean_anom)
            + 0.0003490658504 * sin(2 * mean_anom)
        )
        # Obliquity of the ecliptic
        obliquity = 0.4090877234 - 0.000000006981317008 * daynum
        # Right ascension of the sun
        rasc = atan2(cos(obliquity) * sin(eclip_long), cos(eclip_long))
        # Declination of the sun
        decl = asin(sin(obliquity) * sin(eclip_long))
        # Local sidereal time
        sidereal = 4.894961213 + 6.300388099 * daynum + rlon
        # Hour angle of the sun
        hour_ang = sidereal - rasc
        # Local elevation of the sun
        elevation = asin(sin(decl) * sin(rlat) + cos(decl) * cos(rlat) * cos(hour_ang))
        # Local azimuth of the sun
        azimuth = atan2(
            -cos(decl) * cos(rlat) * sin(hour_ang),
            sin(decl) - sin(rlat) * sin(elevation),
        )
        # Convert azimuth and elevation to degrees
        azimuth = self.into_range(deg(azimuth), 0, 360)
        elevation = self.into_range(deg(elevation), -180, 180)
        # Refraction correction (optional)
        if refraction:
            targ = rad((elevation + (10.3 / (elevation + 5.11))))
            elevation += (1.02 / tan(targ)) / 60
        # Return azimuth and elevation in degrees
        return (round(azimuth, 2), round(elevation, 2))

    def into_range(self, x, range_min, range_max):
        shiftedx = x - range_min
        delta = range_max - range_min
        return (((shiftedx % delta) + delta) % delta) + range_min

    def get_sunposition(self):
        # Aktualisierte Zeit von RTC abrufen
        current_time = datetime.datetime.now()
        
        # Close Encounters latitude, longitude
        #location = (48.85932, 09.21755) # Postition von Stuttgart
        location = (48.3738, 10.8920) # Postition von Chitin
        location = (10.8920, 48.3738)
        
        when = (current_time.year, current_time.month, current_time.day, current_time.hour, current_time.minute, current_time.second, +2)
        print("Aktueller Ort und Zeit: ", when)
        #when = (2023, 2, 27, 7, 0, 0, +1)
        # Get the Sun's apparent location in the sky
        azimuth, elevation = self.sunpos(when, location, True)
        # Output the results
        print("\nWhen: ", when)
        print("Where: ", location) 
        print("Azimuth: ", azimuth)
        print("Elevation: ", elevation) # Elevation ist die SonnenhÃ¶he. Bei unter 0 ist es dunkel/nacht
        self.azimuth =  azimuth
        self.elevation =  elevation
    
    # Azumith gibt die Sonnenrichtung zurÃ¼ck
    # x-Achse
    def get_azumith(self):
        self.get_sunposition()
        print("Azimuth: ", self.azimuth)
        return self.azimuth
    
    # Elevation gibt die SonnenhÃ¶he zurÃ¼ck.
    # y-Achse
    def get_elevation(self):
        self.get_sunposition()
        print("Elevation: ", self.elevation)
        return self.elevation


sunpos = Sunposition()

sunpos.get_azumith()
sunpos.get_elevation()




    