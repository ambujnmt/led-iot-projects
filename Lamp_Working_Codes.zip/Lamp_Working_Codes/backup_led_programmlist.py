# import machine
import time
import json
import multiprocessing

from lamp_demo import Motormovement_Demo


class LEDProgramManager:
    def __init__(self):
        self.led_programs = []
        self.current_program = None
        self.led_process = None
        self.stop_event = multiprocessing.Event()

        self.motormovement_process = None
        self.motormovement_stop_event = multiprocessing.Event()

        self.motormovement_ini = Motormovement_Demo()
        self.start_motormovement_demo = self.motormovement_ini.start_demo

        self.change_led_programm_periodic_process = None
        self.change_led_programm_periodic_stop_event = multiprocessing.Event()

        # fügt ein programm in der led Liste hinzu, in jedem led Programm sollte im Init manager.add_programm(self) hinzugefügt werden.

    def add_programm(self, program):
        self.led_programs.append(program)
        print("LED Programm erhalten und der programmliste hinzugefügt: ", program)

    def change_led_programm_periodic(self, stop_event):
        data = None

        with open("current_lampmodel.json") as f:
            data = json.load(f)

        self.start_named_program("Rainbow", data)

        # duration = 10
        # start_time = time.time()
        # while True:
        #     if stop_event.is_set():
        #         return
        #     current_time = time.time()
        #     if current_time - start_time >= duration:
        #         print("Next program")
        #         self.next_program()
        #         start_time = time.time()

    def stop_demo(self):
        print("Stop_demo triggered")
        # print(self.motormovement_process.is_alive)
        # print(self.change_led_programm_periodic_process.is_alive)
        # print(self.led_process.is_alive)

        # Stop the motor process
        if self.motormovement_process and self.motormovement_process.is_alive():
            try:
                self.motormovement_ini.stop_demo()
                self.motormovement_stop_event.set()
                self.motormovement_process.join()
                self.motormovement_process.terminate()  # Terminate the process

            except Exception as e:
                print("Error in LED Program Manager stop_demo_MOTOR: ", e)
            finally:
                self.motormovement_process = None
                self.motormovement_stop_event.clear()
            print("Motor demo stopped")
        else:
            print("No motor demo process to stop")

        if self.led_process:
            if self.led_process.is_alive():
                try:
                    self.stop_led_Process()
                except Exception as e:
                    print("Error in LED Program Manager stop_demo_LED: ", e)
                finally:
                    self.led_process = None
                print("LED demo stopped")
            else:
                print("No LED demo process to stop")
        else:
            print("No LED demo process to stop")

        # Stop the LED process
        if self.change_led_programm_periodic_process and self.change_led_programm_periodic_process.is_alive():
            try:
                print("try block change led program-------------------------------------")
                self.stop_led_Process()
                self.change_led_programm_periodic_stop_event.set()
                # self.change_led_programm_periodic_process.join()
                self.change_led_programm_periodic_process.terminate()  # Terminate the process

            except Exception as e:
                print("Error in LED Program Manager stop_demo_LED: ", e)
            finally:
                self.change_led_programm_periodic_process = None
                self.change_led_programm_periodic_stop_event.clear()
            print("LED demo stopped")
        else:
            print("No LED demo process to stop")

    def start_demo(self):
        self.stop_led_Process()

        print("start demo trigger and stop_led_process")
        try:
            # self.stop_led_Process()
            # start auto programm wechsel alle 10 sekunden
            if self.motormovement_stop_event.is_set():
                self.motormovement_stop_event.clear()
            if self.change_led_programm_periodic_stop_event.is_set():
                self.change_led_programm_periodic_stop_event.clear()

            if self.motormovement_process is None and self.change_led_programm_periodic_process is None:
                self.motormovement_process = multiprocessing.Process(target=self.start_motormovement_demo,
                                                                     args=(self.motormovement_stop_event,))
                self.motormovement_process.start()

                self.change_led_programm_periodic_process = multiprocessing.Process(
                    target=self.change_led_programm_periodic,
                    args=(self.change_led_programm_periodic_stop_event,))

                self.change_led_programm_periodic_process.start()
        except Exception as e:
            print("fehler start_demo", e)


    # def start_demo(self):
    #     pass
    #
    # def stop_demo(self):
    #     pass



    def get_benutzerdefiniert(self):
        for program in self.led_programs:
            if type(program).__name__ == "Benutzerdefiniert":
                return program
        return None

    def get_benutzerdefiniert_parameter_values(self, data):
        if data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
            # alle Ebenen anschalten
            return data["color1"], data["color2"], data["color3"], data['dimmValue1'], data['dimmValue2'], data[
                'dimmValue3']

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
            # mid und bottom aktivieren
            return 'Color(0xff000000)', data["color2"], data["color3"], 0.0, data['dimmValue2'], data['dimmValue3']

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
            # top und mid aktivieren
            return data["color1"], data["color2"], 'Color(0xff000000)', data['dimmValue1'], data['dimmValue2'], 0.0

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
            # top und bottom aktivieren
            return data["color1"], 'Color(0xff000000)', data["color3"], data['dimmValue1'], 0.0, data['dimmValue3']

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'false':
            # top aktivieren
            return data["color1"], 'Color(0xff000000)', 'Color(0xff000000)', data['dimmValue1'], 0.0, 0.0

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
            # mid aktivieren
            return 'Color(0xff000000)', data["color2"], 'Color(0xff000000)', 0.0, data['dimmValue2'], 0.0

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
            # bottom aktivieren
            return 'Color(0xff000000)', 'Color(0xff000000)', data["color3"], 0.0, 0.0, data['dimmValue3']

        else:
            return None

    def update_benutzerdefiniert(self, data):
        benutzerdefiniertprogramm = self.get_benutzerdefiniert()
        if benutzerdefiniertprogramm != None:
            # Abschnitt Logikabfrage:
            if data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':

                # alle Ebenen anschalten

                benutzerdefiniertprogramm.update_Color(data["color1"], data["color2"], data["color3"],
                                                       data['dimmValue1'], data['dimmValue2'], data['dimmValue3'])


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
                # mid und bottom aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', data["color2"], data["color3"], 0.0,
                                                       data['dimmValue2'], data['dimmValue3'])

            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
                # top und mid aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], data["color2"], 'Color(0xff000000)',
                                                       data['dimmValue1'], data['dimmValue2'], 0.0)


            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
                # top und bottom aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], 'Color(0xff000000)', data["color3"],
                                                       data['dimmValue1'], 0.0, data['dimmValue3'])


            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'false':
                # top aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], 'Color(0xff000000)', 'Color(0xff000000)',
                                                       data['dimmValue1'], 0.0, 0.0)


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
                # mid aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', data["color2"], 'Color(0xff000000)', 0.0,
                                                       data['dimmValue2'], 0.0)


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
                # bottom aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', 'Color(0xff000000)', data["color3"], 0.0,
                                                       0.0, data['dimmValue3'])
        else:
            print("Programm Manager: Kein Benutzerdefiniert LED Programm in der Programmliste gefunden")
            return

    def start_named_program(self, program_name, data):
        programmclassname = self.get_programClassName(program_name)

        print("manager start named Programm getriggert!")
        print("manager versuche ", programmclassname, " zu starten..")

        if programmclassname == "Demo":
            self.start_demo()
            return

        for ledprog in self.led_programs:
            if type(ledprog).__name__ == programmclassname:
                print("LED Manager.start_named_program: passendes Programm zum starten gefunden: ", ledprog)
                print(type(ledprog).__name__)
                self.start_program(ledprog, data)
        return

    def start_program(self, program, data):

        if type(program).__name__ == "Benutzerdefiniert":
            print("Benutzerdefiniert Programm soll im manager gestartet werden ")
            print("prüfe ob Benutzedefiniert bereits läuft und nur update oder start ausgeführt werden muss...")
            self.stop_led_Process()

            params = self.get_benutzerdefiniert_parameter_values(data)
            if params:
                self.benutzerdefiniert_running = True
                print("Jetzte wird der Multiprocess im LED Programm manager funktion start_programm getriggered")
                self.led_process = multiprocessing.Process(target=program.start, args=(self.stop_event, *params))
                self.led_process.start()
                # self.led_process.join()

            else:
                print("Keine gültigen Farbvalues für Benutzerdefiniert aus den Daten erhalten")

        elif self.current_program == program and self.led_process.is_alive():

            print("manager: zu startendes Programm läuft bereits, nichts zu tun")
            self.current_program = program
            return

        else:
            self.stop_led_Process()
            print("manager start programm versuche nun den neuen led_process via multiprocessing zu starten....",
                  program)
            self.led_process = multiprocessing.Process(target=program.start, args=(self.stop_event,))
            self.led_process.start()

            print("Sollte nun gestartet sein: ", program)

            # self.led_process.join()

        self.current_program = program

        return

    def stop_led_Process(self):
        print("stop led process getriggert")
        if self.led_process and self.led_process.is_alive():
            print("stop led process: lebenden prozess gefunden!")
            try:
                # Hier wird ein multiprocessing.Event verwendet, um die stop Methode im laufenden Prozess zu triggern
                self.stop_event.set()
                self.led_process.join()  # Warte auf den Prozess, um ordnungsgemäß zu beenden
            except Exception as e:
                print(f"Fehler beim Stoppen des Modus: {e}")
            finally:
                # self.led_process = None
                self.stop_event.clear()  # Setze das Event zurück für den nächsten Gebrauch
        else:
            try:
                self.stop_event.clear()
            except:
                pass
            print("Kein laufender Modus zum Stoppen")
        return

    def read_lampmodeldata(self):
        with open("current_lampmodel.json", 'r') as file:
            data = json.load(file)
            return data

    def next_program(self):

        if self.current_program != None:

            current_program_index = self.led_programs.index(self.current_program)
            next_program_index = (current_program_index + 1) % len(self.led_programs)

        else:
            next_program_index = 0

        next_programm_classname = type(self.led_programs[next_program_index]).__name__
        print("nächstes programm klassenname: ", next_programm_classname)

        jsonclassname = self.get_programmStringname(next_programm_classname)
        print("name für json Datei: ", jsonclassname)

        try:
            print("Versuche lampmodel mit neuen Modus zu aktualisieren")
            self.writeprogramm_into_lampmodel(jsonclassname)

        except Exception as e:
            time.sleep_ms(100)
            self.writeprogramm_into_lampmodel(jsonclassname)
            print("manager exception: ", e)

        self.start_program(self.led_programs[next_program_index])

    def previous_program(self):

        if self.current_program != None:

            current_program_index = self.led_programs.index(self.current_program)
            previous_program_index = (current_program_index - 1) % len(self.led_programs)
        else:
            previus_program_index = 0

        previous_programm_classname = type(self.led_programs[previous_program_index]).__name__

        print("vorheriges programm klassenname: ", previous_programm_classname)
        jsonclassname = self.get_programmStringname(previous_programm_classname)

        try:
            print("Versuche lampmodel mit neuen Modus zu aktualisieren")
            self.writeprogramm_into_lampmodel(jsonclassname)

        except Exception as e:
            print("manager exception: ", e)
            time.sleep_ms(100)
            self.writeprogramm_into_lampmodel(jsonclassname)

        print("name für json Datei: ", jsonclassname)

        self.start_program(self.led_programs[previous_program_index])

    def get_programClassName(self, programmStringname):

        # 1
        if programmStringname == "Benutzerdefiniert":
            return "Benutzerdefiniert"

        # 2
        if programmStringname == "Galaxy":
            return "Galaxy"

        # 3
        if programmStringname == "Rainy Days":
            return "RainyDays"

        # 4
        if programmStringname == "Rainbow":
            return "RainbowLED"

        # 5
        if programmStringname == "Indigo Cure":
            return "Indigo_Cure"

        # 6
        if programmStringname == "Sleeping Motion":
            return "SleepingMotion"

        # 7
        if programmStringname == "X-Mas":
            return "Xmas"

        # 8
        if programmStringname == "Relax":
            return "Relax"

        # 9
        if programmStringname == "Pulsar":
            return "Pulsar"

        # 10
        if programmStringname == "Crazy Alien":
            return "Crazy_alien"

        # 11
        if programmStringname == "Earth":
            return "Earth"

        # 12
        if programmStringname == "Demo":
            return "Demo"

    def get_programmStringname(self, classname):

        # 1
        if classname == "Benutzerdefiniert":
            return "Benutzerdefiniert"

        # 2
        if classname == "Galaxy":
            return "Galaxy"
        # 3
        if classname == "RainyDays":
            return "Rainy Days"
        # 4
        if classname == "RainbowLED":
            return "Rainbow"
        # 5
        if classname == "Indigo_Cure":
            return "Indigo Cure"
        # 6
        if classname == "SleepingMotion":
            return "Sleeping Motion"
        # 7
        if classname == "Xmas":
            return "X-Mas"
        # 8
        if classname == "Relax":
            return "Relax"
        # 9
        if classname == "Pulsar":
            return "Pulsar"
        # 10
        if classname == "Crazy_alien":
            return "Crazy Alien"
        # 11
        if classname == "Earth":
            return "Earth"

    def writeprogramm_into_lampmodel(self, programmstringname):

        with open("current_lampmodel.json", 'r') as f:
            data = json.load(f)

            # Schritt 2: Inhalt als Dictionary parsen
            # (dies geschieht bereits durch json.load)

            # Schritt 3: Gewünschten Wert ändern
            data["modus"] = programmstringname
            data["isGlowShowing"] = "true"
            data["isGlow1"] = "true"
            data["isGlow2"] = "true"
            data["isGlow3"] = "true"
            data["isGlowShowing"] = "true"

            # Schritt 4: Dictionary als JSON speichern
            updated_json = json.dumps(data)

            # Schritt 5: Datei mit aktualisiertem Inhalt überschreiben
            with open("current_lampmodel.json", 'w') as f:
                f.write(updated_json)




# Initialisiere den Manager mit den LED-Programmen

manager = LEDProgramManager()
