#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time


import random
import gc

class RainyDays:
    def __init__(self, touchenabled):

        manager.add_programm(self)

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)

        #'Belegung ESP32 mehr Ram'

        self.PIN = board.D12 #18

        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23
        '''
        #'Belegung ESP32 mehr Ram'

        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23

        #Belegung ESP32 Platine

        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''


        # Define the colors
        self.DARK = (0, 0, 0, 0)
        self.ONLY_BLUE = [(0, 0, 255, 0),
                          (0, 0, 240, 0),
                          (0, 0, 225, 0),
                          (0, 0, 210, 0),
                          (0, 0, 195, 0),
                          (0, 0, 180, 0),
                          (0, 0, 165, 0),
                          (0, 0, 150, 0),
                          (0, 0, 135, 0),
                          (0, 0, 120, 0),
                          (0, 0, 105, 0),
                          (0, 0, 90, 0),
                          (0, 0, 75, 0),
                          (0, 0, 60, 0),
                          (0, 0, 45, 0),
                          (0, 0, 30, 0),
                          (0, 0, 15, 0),
                          (0, 0, 0, 0),
                          (0, 0, 0, 0),
                          (0, 0, 0, 0)]

        self.rainy_days_running = False
        self.thread_running = None

        self.paused = False

        # Global variable to track whether the rainy_days LED is on or off
        self.rainy_days_on = False

        self.init = True

        time.sleep(0.1)

    def np_top_array(self, position, value):
        # print(f"np_top_array called with position { position} and value {value}")
        self.np[position] = value
       

    def np_mid_array(self, position, value):

        #print("Position mid array: ", position)
        
        # print(f"np_mid_array called with position {position} and value {value} if")
        self.np[position + self.NUM_LEDS_TOP] = value
        

    def bottom1_array(self, position, value):
        corrected_position = position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID
        # print(f"bottom1_array called with position {position} and value {value} -> index {corrected_position}")
        self.np[corrected_position] = value

    def bottom2_array(self, position, value):
        corrected_position = position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM
        # print(f"bottom2_array called with position {position} and value {value} -> index {corrected_position}")
        self.np[corrected_position] = value

    def bottom3_array(self, position, value):
        corrected_position = position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + 2 * self.NUM_LEDS_BOTTOM
        # print(f"bottom3_array called with position {position} and value {value} -> index {corrected_position}")
        self.np[corrected_position] = value

    def rainy_days_loop(self, stop_event, diming, change_timing = True):
        # print("rainy_days_loop started")

        if diming:
            print("Diming enabled")
           
            self.DARK = (0, 0, 0, 0) # auf 25% gedimmt
            self. ONLY_BLUE = [
                (0, 0, 64, 0),
                (0, 0, 60, 0),
                (0, 0, 57, 0),
                (0, 0, 53, 0),
                (0, 0, 49, 0),
                (0, 0, 47, 0),
                (0, 0, 42, 0),
                (0, 0, 38, 0),
                (0, 0, 34, 0),
                (0, 0, 30, 0), 
                (0, 0, 27, 0),
                (0, 0, 23, 0),
                (0, 0, 19, 0),
                (0, 0, 15, 0),
                (0, 0, 11, 0),
                (0, 0, 8, 0),
                (0, 0, 4, 0),
                (0, 0, 0, 0),
                (0, 0, 0, 0),
                (0, 0, 0, 0)
            ]


        gc.enable()

        # print("initial variables set")

        r3 = 0   # wird verwendet, um für den ERSTEN Wassertropfen durch das Array der Farbe durchzuinterieren
        r33 = 0  # wird verwendet, um für den ERSTEN Wassertropfen durch das Array der Farbe durchzuinterieren
        r333 = 0 # wird verwendet, um für den ZWEITEN Wassertropfen durch das Array der Farbe durchzuinterieren
        r3333 = 0
        r33333 = 0
        r333333 = 0
        r4 = 0   # wird verwendet, um den Durchlauf der Schleife langsamer ablaufen zu lassen, bzw. der Vorgang des Dimmens einer Led läuft langsamer

        number1 = 0 # erstem Wassertropfen eine zufällige Zahl geben
        number2 = 4 # zweiten Wassertropfen eine zufällige Zahl geben
        number3 = 2 # drittem Wassertropfen eine zufällige Zahl geben
        number4 = 8
        number5 = 6
        number6 = 3

        count_round = 0    # runde für den ersten Wassertropfen
        count_round2 = 0   # runde für den zweiten Wassertropfen
        count_round3 = 0   # runde für den dritten Wassertropfen
        count_round4 = 0
        count_round5 = 0
        count_round6 = 0

        second_round = False
        third_round = False
        fourth_round = False
        fifth_round = False
        sixth_round = False

        '''
        if self.touchenabled:

            self.touch_threshold = self.touch_pin.read()
        '''



        array = [number1, number2, number3, number4, number5, number6]

        while self.rainy_days_on:




            if stop_event.is_set():
                self.stop()
                return

            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''

            # ist rainbow pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue




            r4 = r4 + 1
            if(r4 == 1):         # Je höher die Zahl, desto langsamer wird die aktuelle Leds gedimmt

                # print("Running LED assigned in loop")
                self.durchlauf_eines_wassertropfens(count_round, number1, r3)
                # erster Tropfen, bei count_round wird Oberen LED angesprochen

                # Zweiten Tropfen aktivieren
                if count_round == 1:
                    if r3 == 10:
                        second_round = True
                if(second_round == True):
                    self.durchlauf_eines_wassertropfens(count_round2, number2, r33)


                # Dritten Tropfen aktivieren
                if count_round2 == 1:
                    if r33 == 10:
                        third_round = True
                if(third_round == True):
                    self.durchlauf_eines_wassertropfens(count_round3, number3, r333)


                # vierter Tropfen aktivieren
                if count_round3 == 1:
                    if r333 == 10:
                        fourth_round = True
                if(fourth_round == True):
                    self.durchlauf_eines_wassertropfens(count_round4, number4, r3333)

                # fünfter Tropfen aktivieren
                if count_round4 == 1:
                    if r3333 == 10:
                        fifth_round = True
                if(fifth_round == True):
                    self.durchlauf_eines_wassertropfens(count_round5, number5, r33333)

                # sechster Tropfen aktivieren
                if count_round5 == 1:
                    if r33333 == 10:
                        sixth_round = True
                if(sixth_round == True):
                    self.durchlauf_eines_wassertropfens(count_round6, number6, r333333)

                if change_timing == True:
                    time.sleep(0.01)

                r3 = r3 + 1

                if(second_round == True):
                    r33 = r33 + 1

                if(third_round == True):
                    r333 = r333 + 1

                if(fourth_round == True):
                    r3333 = r3333 + 1

                if(fifth_round == True):
                    r33333 = r33333 + 1

                if(sixth_round == True):
                    r333333 = r333333 + 1

                # Erster Tropfen
                if r3 == len(self.ONLY_BLUE) - 1:
                    r3 = 0
                    count_round = count_round + 1

                    if count_round == 2:
                        count_round = 0
                        number1 = self.remove_and_replace_number(number1, array)


                if change_timing == True:
                    time.sleep(0.01)

                # Zweiter Tropfen
                if r33 == len(self.ONLY_BLUE) - 1:
                    r33 = 0
                    count_round2 = count_round2 + 1

                    if count_round2 == 2:
                        count_round2 = 0
                        number2 = self.remove_and_replace_number(number2, array)

                # Dritter Tropfen
                if r333 == len(self.ONLY_BLUE) - 1:
                    r333 = 0
                    count_round3 = count_round3 + 1

                    if(count_round3 == 2):
                        count_round3 = 0
                        number3 = self.remove_and_replace_number(number3, array)

                # vierter Tropfen
                if r3333 == len(self.ONLY_BLUE) - 1:
                    r3333 = 0
                    count_round4 = count_round4 + 1

                    if(count_round4 == 2):
                        count_round4 = 0
                        number4 = self.remove_and_replace_number(number4, array)

                # fünfter Tropfen
                if r33333 == len(self.ONLY_BLUE) - 1:
                    r33333 = 0
                    count_round5 = count_round5 + 1

                    if(count_round5 == 2):
                        count_round5 = 0
                        number5 = self.remove_and_replace_number(number5, array)




                # sechster Tropfen
                if r333333 == len(self.ONLY_BLUE) - 1:
                    r333333 = 0
                    count_round6 = count_round6 + 1

                    if(count_round6 == 2):
                        count_round6 = 0
                        number6 = self.remove_and_replace_number(number6, array)

                self.bottom_led_on(r3, 0)
                self.bottom_led_on(r33, 1)
                self.bottom_led_on(r333, 2)

                r4 = 0

            '''
            if self.rainy_days_running == False:
                return
            '''
            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()
            if stop_event.is_set():
                self.stop()
                return



    #@micropython.native
    def remove_and_replace_number(self, number, array):
        # Prüfe, ob die Zahl im Array vorhanden ist
        if number in array:
            # Falls ja, entferne die Zahl aus dem Array
            array.remove(number)

        # Wähle eine neue Zahl zwischen 0 und 8, die nicht im Array vorhanden ist
        new_number = random.choice([i for i in range(9) if i not in array])
        array.append(new_number)

        # Gib die neue Zahl zurück
        return new_number

    #@micropython.native
    def new_number(self, random_number):
        if random_number == 8:
            random_number = 0
        else:
            random_number += 1


    #@micropython.native
    def durchlauf_eines_wassertropfens(self, count_round, random_number, r3):
        if(count_round == 0):
            # start
            self.top_leds_on(random_number, r3)

        if(count_round == 1):
            # start
            self.mid_leds_on(random_number, r3)
            # stop
            self.top_leds_off(random_number, r3)

        if(count_round == 2):
            # start
            self.bottom_led_on(r3, 1)
            # stop
            self.mid_leds_off(random_number)

    #@micropython.native
    def starte_neue_interierung_von_r(self, count_round, r):
        # Erster Tropfen
        if r == len(self.ONLY_BLUE) - 1:
            r = 0
            count_round = count_round + 1

            if count_round == 2:
                count_round = 0

    def top_leds_on(self, number1, r3):
        if(number1 == 0):
            self.np_top_array(0, self.ONLY_BLUE[r3])

        if(number1 == 1):
            self.np_top_array(1, self.ONLY_BLUE[r3])

        if(number1 == 2):
            self.np_top_array(2, self.ONLY_BLUE[r3])

        if(number1 == 3):
            self.np_top_array(3, self.ONLY_BLUE[r3])

        if(number1 == 4):
            self.np_top_array(4, self.ONLY_BLUE[r3])

        if(number1 == 5):
            self.np_top_array(5, self.ONLY_BLUE[r3])

        if(number1 == 6):
            self.np_top_array(6, self.ONLY_BLUE[r3])

        if(number1 == 7):
            self.np_top_array(7, self.ONLY_BLUE[r3])

        if(number1 == 8):
            self.np_top_array(8, self.ONLY_BLUE[r3])

        if(number1 == 9):
            self.np_top_array(9, self.ONLY_BLUE[r3])

    def top_leds_off(self, number1, r):
        if(number1 == 0):
            self.np_top_array(0, self.DARK)

        if(number1 == 1):
            self.np_top_array(1, self.DARK)

        if(number1 == 2):
            self.np_top_array(2, self.DARK)

        if(number1 == 3):
            self.np_top_array(3, self.DARK)

        if(number1 == 4):
            self.np_top_array(4, self.DARK)

        if(number1 == 5):
            self.np_top_array(5, self.DARK)

        if(number1 == 6):
            self.np_top_array(6, self.DARK)

        if(number1 == 7):
            self.np_top_array(7, self.DARK)

        if(number1 == 8):
            self.np_top_array(8, self.DARK)

        if(number1 == 9):
            self.np_top_array(9, self.DARK)

    def mid_leds_on(self, number1, r3):
        if(number1 == 0):
            self.np_mid_array(96, self.ONLY_BLUE[r3])
            self.np_mid_array(97, self.ONLY_BLUE[r3])
            self.np_mid_array(0, self.ONLY_BLUE[r3])
            self.np_mid_array(1, self.ONLY_BLUE[r3])
            self.np_mid_array(2, self.ONLY_BLUE[r3])

        if(number1 == 1):
            self.np_mid_array(7, self.ONLY_BLUE[r3])
            self.np_mid_array(8, self.ONLY_BLUE[r3])
            self.np_mid_array(9, self.ONLY_BLUE[r3])
            self.np_mid_array(10, self.ONLY_BLUE[r3])
            self.np_mid_array(11, self.ONLY_BLUE[r3])

        if(number1 == 2):
            self.np_mid_array(17, self.ONLY_BLUE[r3])
            self.np_mid_array(18, self.ONLY_BLUE[r3])
            self.np_mid_array(19, self.ONLY_BLUE[r3])
            self.np_mid_array(20, self.ONLY_BLUE[r3])
            self.np_mid_array(21, self.ONLY_BLUE[r3])

        if(number1 == 3):
            self.np_mid_array(26, self.ONLY_BLUE[r3])
            self.np_mid_array(27, self.ONLY_BLUE[r3])
            self.np_mid_array(28, self.ONLY_BLUE[r3])
            self.np_mid_array(29, self.ONLY_BLUE[r3])
            self.np_mid_array(30, self.ONLY_BLUE[r3])

        if(number1 == 4):
            self.np_mid_array(37, self.ONLY_BLUE[r3])
            self.np_mid_array(38, self.ONLY_BLUE[r3])
            self.np_mid_array(39, self.ONLY_BLUE[r3])
            self.np_mid_array(40, self.ONLY_BLUE[r3])
            self.np_mid_array(41, self.ONLY_BLUE[r3])

        if(number1 == 5):
            self.np_mid_array(47, self.ONLY_BLUE[r3])
            self.np_mid_array(48, self.ONLY_BLUE[r3])
            self.np_mid_array(49, self.ONLY_BLUE[r3])
            self.np_mid_array(50, self.ONLY_BLUE[r3])
            self.np_mid_array(51, self.ONLY_BLUE[r3])

        if(number1 == 6):
            self.np_mid_array(57, self.ONLY_BLUE[r3])
            self.np_mid_array(58, self.ONLY_BLUE[r3])
            self.np_mid_array(59, self.ONLY_BLUE[r3])
            self.np_mid_array(60, self.ONLY_BLUE[r3])
            self.np_mid_array(61, self.ONLY_BLUE[r3])

        if(number1 == 7):
            self.np_mid_array(67, self.ONLY_BLUE[r3])
            self.np_mid_array(68, self.ONLY_BLUE[r3])
            self.np_mid_array(69, self.ONLY_BLUE[r3])
            self.np_mid_array(70, self.ONLY_BLUE[r3])
            self.np_mid_array(71, self.ONLY_BLUE[r3])

        if(number1 == 8):
            self.np_mid_array(78, self.ONLY_BLUE[r3])
            self.np_mid_array(79, self.ONLY_BLUE[r3])
            self.np_mid_array(80, self.ONLY_BLUE[r3])
            self.np_mid_array(81, self.ONLY_BLUE[r3])
            self.np_mid_array(82, self.ONLY_BLUE[r3])

        if(number1 == 9):
            self.np_mid_array(88, self.ONLY_BLUE[r3])
            self.np_mid_array(89, self.ONLY_BLUE[r3])
            self.np_mid_array(90, self.ONLY_BLUE[r3])
            self.np_mid_array(91, self.ONLY_BLUE[r3])
            self.np_mid_array(92, self.ONLY_BLUE[r3])

    def mid_leds_off(self, number1):
        if(number1 != 0):
            self.np_top_array(0, self.DARK)
            self.np_mid_array(96, self.DARK)
            self.np_mid_array(97, self.DARK)
            self.np_mid_array(0, self.DARK)
            self.np_mid_array(1, self.DARK)
            self.np_mid_array(2, self.DARK)

        if(number1 != 1):
            self.np_top_array(1, self.DARK)
            self.np_mid_array(7, self.DARK)
            self.np_mid_array(8, self.DARK)
            self.np_mid_array(9, self.DARK)
            self.np_mid_array(10, self.DARK)
            self.np_mid_array(11, self.DARK)

        if(number1 != 2):
            self.np_top_array(2, self.DARK)
            self.np_mid_array(17, self.DARK)
            self.np_mid_array(18, self.DARK)
            self.np_mid_array(19, self.DARK)
            self.np_mid_array(20, self.DARK)
            self.np_mid_array(21, self.DARK)

        if(number1 != 3):
            self.np_top_array(3, self.DARK)
            self.np_mid_array(26, self.DARK)
            self.np_mid_array(27, self.DARK)
            self.np_mid_array(28, self.DARK)
            self.np_mid_array(29, self.DARK)
            self.np_mid_array(30, self.DARK)

        if(number1 != 4):
            self.np_top_array(4, self.DARK)
            self.np_mid_array(37, self.DARK)
            self.np_mid_array(38, self.DARK)
            self.np_mid_array(39, self.DARK)
            self.np_mid_array(40, self.DARK)
            self.np_mid_array(41, self.DARK)

        if(number1 != 5):
            self.np_top_array(5, self.DARK)
            self.np_mid_array(47, self.DARK)
            self.np_mid_array(48, self.DARK)
            self.np_mid_array(49, self.DARK)
            self.np_mid_array(50, self.DARK)
            self.np_mid_array(51, self.DARK)

        if(number1 != 6):
            self.np_top_array(6, self.DARK)
            self.np_mid_array(57, self.DARK)
            self.np_mid_array(58, self.DARK)
            self.np_mid_array(59, self.DARK)
            self.np_mid_array(60, self.DARK)
            self.np_mid_array(61, self.DARK)

        if(number1 != 7):
            self.np_top_array(7, self.DARK)
            self.np_mid_array(67, self.DARK)
            self.np_mid_array(68, self.DARK)
            self.np_mid_array(69, self.DARK)
            self.np_mid_array(70, self.DARK)
            self.np_mid_array(71, self.DARK)

        if(number1 != 8):
            self.np_top_array(8, self.DARK)
            self.np_mid_array(78, self.DARK)
            self.np_mid_array(79, self.DARK)
            self.np_mid_array(80, self.DARK)
            self.np_mid_array(81, self.DARK)
            self.np_mid_array(82, self.DARK)

        if(number1 != 9):
            self.np_top_array(9, self.DARK)
            self.np_mid_array(88, self.DARK)
            self.np_mid_array(89, self.DARK)
            self.np_mid_array(90, self.DARK)
            self.np_mid_array(91, self.DARK)
            self.np_mid_array(92, self.DARK)

    def bottom_led_on(self, r3, random_number):
        if random_number == 0:
            self.bottom1_array(0, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(1, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(2, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(3, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(4, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(5, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(6, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(7, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(8, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(9, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(10, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom1_array(11, self.scale_color(self.ONLY_BLUE[r3], 30.0))

        elif random_number == 1:
            self.bottom2_array(0, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(1, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(2, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(3, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(4, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(5, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(6, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(7, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(8, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(9, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(10, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom2_array(11, self.scale_color(self.ONLY_BLUE[r3], 30.0))

        else:
            self.bottom3_array(0, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(1, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(2, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(3, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(4, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(5, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(6, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(7, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(8, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(9, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(10, self.scale_color(self.ONLY_BLUE[r3], 30.0))
            self.bottom3_array(11, self.scale_color(self.ONLY_BLUE[r3], 30.0))

    def bottom_led_off(self, random_number):
        if random_number == 0:
            self.bottom1_array(0, self.DARK)
            self.bottom1_array(1, self.DARK)
            self.bottom1_array(2, self.DARK)
            self.bottom1_array(3, self.DARK)
            self.bottom1_array(4, self.DARK)
            self.bottom1_array(5, self.DARK)
            self.bottom1_array(6, self.DARK)
            self.bottom1_array(7, self.DARK)
            self.bottom1_array(8, self.DARK)
            self.bottom1_array(9, self.DARK)
            self.bottom1_array(10, self.DARK)
            self.bottom1_array(11, self.DARK)

        elif random_number == 1:
            self.bottom2_array(0, self.DARK)
            self.bottom2_array(1, self.DARK)
            self.bottom2_array(2, self.DARK)
            self.bottom2_array(3, self.DARK)
            self.bottom2_array(4, self.DARK)
            self.bottom2_array(5, self.DARK)
            self.bottom2_array(6, self.DARK)
            self.bottom2_array(7, self.DARK)
            self.bottom2_array(8, self.DARK)
            self.bottom2_array(9, self.DARK)
            self.bottom2_array(10, self.DARK)
            self.bottom2_array(11, self.DARK)

        else:
            self.bottom3_array(0, self.DARK)
            self.bottom3_array(1, self.DARK)
            self.bottom3_array(2, self.DARK)
            self.bottom3_array(3, self.DARK)
            self.bottom3_array(4, self.DARK)
            self.bottom3_array(5, self.DARK)
            self.bottom3_array(6, self.DARK)
            self.bottom3_array(7, self.DARK)
            self.bottom3_array(8, self.DARK)
            self.bottom3_array(9, self.DARK)
            self.bottom3_array(10, self.DARK)
            self.bottom3_array(11, self.DARK)


    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    def scale_color(self, color_tupel, brightness):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)

        return (r, g, b, w)


    def start(self, stop_event, diming):
        print("start rainy_days innerhalb rainy_days Klasse getrigget!")
        self.rainy_days_on = True
        self.rainy_days_loop(stop_event, diming)

    def stop(self):
        self.rainy_days_on = False
        self.rainy_days_off()
        self.np.deinit()


    def rainy_days_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.rainy_days_on


# rainy_days = RainyDays(False)
# stop_event = multiprocessing.Event()
# diming = True
# rainy_days.start(stop_event, diming)

