import Kompass_Accelerometer
from tilt_motor_control import Tilt_MotorControl
from rotation_motor_control import Rotation_MotorControl
import board
import json
import threading
import os
import time
from concurrent.futures import ThreadPoolExecutor
import control_sun_tracking
import control_compass
from shared_ressources import shared_resources
import busio
import control_gps


motor = Rotation_MotorControl(board.D10, board.D24, board.D11)


i2c = busio.I2C(board.SCL, board.SDA)
magnetometer = control_compass.Magnetometer(i2c)
time.sleep(2)
actual_rota = 0
gps = control_gps

try:
    lat, long = gps.get_lat_long_cached()
except Exception as e:
    lat = 50
    long = 10
    print("error in get_lat_long", e)

while True:
    x, y, z = magnetometer.read_magnetic_field()
    heading = magnetometer.get_heading(x, y)
    print(heading)
    time.sleep(0.1)
