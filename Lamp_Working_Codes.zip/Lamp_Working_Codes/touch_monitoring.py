import board
import busio
import digitalio
import time
import neopixel

# Import the AT42QT1050 class from your module
from i2c_devices_new.at42qt.odt_at42qt1050 import AT42QT1070

# Initialize I2C
i2c = busio.I2C(board.SCL, board.SDA)

# Setup the AT42QT1050, assuming AT42QT1050 class has similar methods to AT42QT1070
qtouch = AT42QT1070(i2c, address=0x41)
qtouch.set_key_neg_threshold(0, 255)
qtouch.setpulseandscale(4)
qtouch.set_di(8)

# Setup the CHANGE pin from AT42QT1050
CHANGE_PIN = 20  # Replace with the actual GPIO pin number you're using
touch = digitalio.DigitalInOut(board.D20)
touch.direction = digitalio.Direction.INPUT
touch.pull = digitalio.Pull.DOWN

# Configure touch sensor if necessary, similar to how you did with set_key_neg_threshold and setpulseandscale


# Configuration for the top LEDs
NUM_LEDS_TOP = 10
PIN = board.D12

# Initialize the NeoPixel object for the top LEDs
np_top = neopixel.NeoPixel(PIN, NUM_LEDS_TOP, bpp=4)


def activate_top_leds():
    for i in range(NUM_LEDS_TOP):
        np_top[i] = (255, 255, 255, 255)  # White color with full brightness for RGBW
    np_top.show()


def deactivate_top_leds():
    for i in range(NUM_LEDS_TOP):
        np_top[i] = (0, 0, 0, 0)  # Turn off the LEDs
    np_top.show()


# Example usage:
# activate_top_leds()
# time.sleep(5)  # Keep the LEDs on for 5 seconds
# deactivate_top_leds()


def test():
    while True:

        # Read the touch status using the method from your at42qt.odt_at42qt1050 library
        if qtouch.this_key_touched(0):
            print("Berührt")
            # activate_top_leds()
        else:
            print("Nicht berührt")
            # deactivate_top_leds()
        time.sleep(0.05)

# def interpret_gesture(durations):
#     if len(durations) == 1:
#         if durations[0] < 1:
#             print("Short Tap")
#         elif 1 <= durations[0] < 3:
#             print("Long Tap")
#         elif durations[0] >= 3:
#             print("Long Hold")
#     elif len(durations) == 2:
#         if all(d < 1 for d in durations) and (durations[1] - durations[0]) < 0.5:
#             print("Double Short Tap")
#
#
# def test():
#     touch_start = None
#     touch_end = None
#     touch_durations = []
#
#     while True:
#         touched = qtouch.this_key_touched(0)
#
#         if touched and touch_start is None:
#             touch_start = time.time()
#             print("Berührt")
#             # activate_top_leds()
#         elif not touched and touch_start is not None:
#             touch_end = time.time()
#             duration = touch_end - touch_start
#             touch_durations.append(duration)
#             interpret_gesture(touch_durations)
#             touch_start = None
#             print("Nicht Berührt")
#             # deactivate_top_leds()
#
#         time.sleep(0.05)

def main(on=False):
    if not on:
        return
    else:
        test()

main(True)
