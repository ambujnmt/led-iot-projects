import multiprocessing
import threading

from control_sun_tracking import set_azimuth_elevation
from control_gps import get_lat_long_cached
import time
import logging

# Configure logging
logging.basicConfig(filename='daylight_log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Daylight_LED:
    def __init__(self, manager=None):
        self.multithread = None
        self.stopevent = threading.Event()
        self.cord_set = False
        self.previous_elevation = None
        self.elevation_change_detected = False
        self.manager = manager

    def start_background_check(self):
        self.multithread = threading.Thread(target=self.checkloop)
        self.multithread.start()

    def stop_background_check(self):
        self.stopevent.set()
        self.multithread.join()
        self.multithread = None

    def checkloop(self):
        while not self.stopevent.is_set():
            current_elevation = self.get_elevation()
            self.detect_elevation_change(current_elevation)
            # logging.info(f"Current elevation: {current_elevation} at {time.strftime('%Y-%m-%d %H:%M:%S')}")
            time.sleep(600)  # Checks every 10 minutes


    def detect_elevation_change(self, current_elevation):
        if self.previous_elevation is not None and self.previous_elevation < 0 and current_elevation >= 0:
            self.elevation_change_detected = True
            self.perform_action_on_elevation_change()
            self.reset_for_next_day()
        self.previous_elevation = current_elevation

    def perform_action_on_elevation_change(self):
        # Log entry when elevation change is detected
        # logging.info("Elevation change detected: from negative to positive.")
        # print("Pause wurde getriggert")
        from led_programmliste import manager
        if self.elevation_change_detected:
            self.manager.stop_led_Process()
            logging.info("LED process stopped in manager")
        logging.info("LED process stopped due to elevation change.")

    def reset_for_next_day(self):
        self.elevation_change_detected = False

    def get_elevation(self):
        if not self.cord_set:
            lat, long = get_lat_long_cached()
            self.cord_set = True
        else:
            lat, long = 50, 10 # Default coordinates
            # lat, long = 0, 0
        azi, ele = set_azimuth_elevation(lat, long)
        return ele

# Example of using the Daylight_LED class
# daylight_led = Daylight_LED()
# daylight_led.start_background_check()

# When stopping the background check (for example, on program termination):
# daylight_led.stop_background_check()
