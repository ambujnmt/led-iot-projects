#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time





import random
import gc


class RainbowLED:
    def __init__(self, touchenabled):
        
        '''
        #manager mit led programm füttern, muss gemacht werden um zirkuläre importe zu vermeiden
        
#mit touch initialisieren?
        self.touchenabled = touchenabled
        
                #manager mit led programm füttern, muss gemacht werden um zirkuläre importe zu vermeiden
        if self.touchenabled:
            
            manager.add_programm(self)
            
        else:
            print(self, " ohne touch initialisiert")
        '''
        manager.add_programm(self)  
        
        self.paused = False
        
        self.init = False
        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12
        
        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)
        
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = board.D12 #18
        
        
        
        
        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23
        
        
        #Belegung ESP32 Platine
        '''
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''
        
        
        #self.np = Pixels(machine.Pin(self.PIN), self.NUM_LEDS_TOP)
        #self.np_bottom_first = Pixels(machine.Pin(self.PIN_BOTTOM_FIRST), self.NUM_LEDS_BOTTOM)
        #self.np_bottom_second = pixels.Pixels(machine.Pin(self.PIN_BOTTOM_SECOND), self.NUM_LEDS_BOTTOM)
        #self.np_bottom_third = pixels.Pixels(machine.Pin(self.PIN_BOTTOM_THIRD), self.NUM_LEDS_BOTTOM)
        

        #self.strip = Pixels(machine.Pin(self.PIN_MID), self.NUM_LEDS_MID)  # Use pixel_order = neopixel.RGBW to indicate RGBW LEDs
        
        
        # Erstelle das Neopixel-Objekt
        #self.np = neopixel.NeoPixel(board.D12, TotalLedCount, auto_write=False, bpp=4)
        #self.np_bottom_first = neopixel.NeoPixel(self.PIN_BOTTOM_FIRST, self.NUM_LEDS_BOTTOM, pixel_order = neopixel.RGBW)
        #self.np_bottom_second = neopixel.NeoPixel(self.PIN_BOTTOM_SECOND, self.NUM_LEDS_BOTTOM, pixel_order = neopixel.RGBW)
        #self.np_bottom_third = neopixel.NeoPixel(self.PIN_BOTTOM_THIRD, self.NUM_LEDS_BOTTOM, pixel_order = neopixel.RGBW)
        


        #self.strip = neopixel.NeoPixel(self.PIN_MID, self.NUM_LEDS_MID, pixel_order = neopixel.RGBW)  # Use pixel_order = neopixel.RGBW to indicate RGBW LEDs
        
        
        self.RAINBOW_COLORS = [
            (255, 0, 0, 0),  # Rot  
            (255, 15, 0, 0),
            (255, 31, 0, 0),
            (255, 47, 0, 0),
            (255, 63, 0, 0),
            (255, 79, 0, 0),
            (255, 95, 0, 0),
            (255, 111, 0, 0),
            (255, 127, 0, 0),  # Orange
            (255, 143, 0, 0),
            (255, 159, 0, 0),
            (255, 175, 0, 0),
            (255, 191, 0, 0),
            (255, 207, 0, 0),
            (255, 223, 0, 0),
            (255, 255, 0, 0),  # Gelb
            (239, 255, 0, 0),
            (223, 255, 0, 0),
            (207, 255, 0, 0),
            (191, 255, 0, 0),
            (175, 255, 0, 0),
            (159, 255, 0, 0),
            (143, 255, 0, 0),
            (127, 255, 0, 0),  # Grün-Gelb
            (111, 255, 0, 0),
            (95, 255, 0, 0),
            (79, 255, 0, 0),
            (63, 255, 0, 0),
            (47, 255, 0, 0),
            (31, 255, 0, 0),
            (15, 255, 0, 0),
            (0, 255, 0, 0),  # Grün
            (0, 255, 15, 0),
            (0, 255, 31, 0),
            (0, 255, 47, 0),
            (0, 255, 63, 0),
            (0, 255, 79, 0),
            (0, 255, 95, 0),
            (0, 255, 111, 0),
            (0, 255, 127, 0),  # Türkis-Grün
            (0, 255, 143, 0),
            (0, 255, 159, 0),
            (0, 255, 175, 0),
            (0, 255, 191, 0),
            (0, 255, 207, 0),
            (0, 255, 223, 0),
            (0, 255, 239, 0),
            (0, 255, 255, 0),  # Hellblau
            (0, 239, 255, 0),
            (0, 223, 255, 0),
            (0, 207, 255, 0),
            (0, 191, 255, 0),
            (0, 175, 255, 0),
            (0, 159, 255, 0),
            (0, 143, 255, 0),
            (0, 127, 255, 0),  # Blau-Türkis
            (0, 111, 255, 0),
            (0, 95, 255, 0),
            (0, 79, 255, 0),
            (0, 63, 255, 0),
            (0, 47, 255, 0),
            (0, 31, 255, 0),
            (0, 15, 255, 0),
            (0, 0, 255, 0),  # Blau
            (15, 0, 255, 0),
            (31, 0, 255, 0),
            (40, 0, 255, 0),
            (42, 0, 255, 0),
            (47, 0, 255, 0),
            (63, 0, 255, 0),
            (79, 0, 255, 0),
            (95, 0, 255, 0),
            (111, 0, 255, 0),
            (127, 0, 255, 0),  # Violett-Blau
            (143, 0, 255, 0),
            (159, 0, 255, 0),
            (175, 0, 255, 0),
            (191, 0, 255, 0),
            (207, 0, 255, 0),
            (223, 0, 255, 0),
            (255, 0, 255, 0),  # Pink
            (255, 0, 239, 0),
            (255, 0, 223, 0),
            (255, 0, 207, 0),
            (255, 0, 191, 0),
            (255, 0, 175, 0),
            (255, 0, 159, 0),
            (255, 0, 143, 0),
            (255, 0, 127, 0),  # Pink-Rot
            (255, 0, 111, 0),
            (255, 0, 95, 0),
            (255, 0, 79, 0),
            (255, 0, 63, 0),
            (255, 0, 47, 0),
            (255, 0, 31, 0),
            (255, 0, 15, 0),
            (255, 0, 7, 0),
            (255, 0, 3, 0)  ]


            # auf 25% gedimmt
        self.RAINBOW_COLORS2 = [
            (64, 0, 0, 0),  # Rot
            (64, 4, 0, 0),
            (64, 8, 0, 0),
            (64, 12, 0, 0),
            (64, 16, 0, 0),
            (64, 20, 0, 0),
            (64, 24, 0, 0),
            (64, 28, 0, 0),
            (64, 32, 0, 0),  # Orange
            (64, 36, 0, 0),
            (64, 40, 0, 0),
            (64, 44, 0, 0),
            (64, 48, 0, 0),
            (64, 52, 0, 0),
            (64, 56, 0, 0),
            (64, 64, 0, 0),  # Gelb
            (60, 64, 0, 0),
            (56, 64, 0, 0),
            (52, 64, 0, 0),
            (48, 64, 0, 0),
            (44, 64, 0, 0),
            (40, 64, 0, 0),
            (36, 64, 0, 0),
            (32, 64, 0, 0),  # Grün-Gelb
            (28, 64, 0, 0),
            (24, 64, 0, 0),
            (20, 64, 0, 0),
            (16, 64, 0, 0),
            (11, 64, 0, 0),
            (8, 64, 0, 0),
            (4, 64, 0, 0),
            (0, 64, 0, 0),  # Grün
            (0, 64, 4, 0),
            (0, 64, 8, 0),
            (0, 64, 12, 0),
            (0, 64, 16, 0),
            (0, 64, 20, 0),
            (0, 64, 24, 0),
            (0, 64, 28, 0),
            (0, 64, 32, 0),  # Türkis-Grün
            (0, 64, 36, 0),
            (0, 64, 40, 0),
            (0, 64, 44, 0),
            (0, 64, 48, 0),
            (0, 64, 52, 0),
            (0, 64, 56, 0),
            (0, 64, 60, 0),
            (0, 64, 64, 0),  # Hellblau
            (0, 60, 64, 0),
            (0, 56, 64, 0),
            (0, 52, 64, 0),
            (0, 48, 64, 0),
            (0, 44, 64, 0),
            (0, 40, 64, 0),
            (0, 36, 64, 0),
            (0, 32, 64, 0),  # Blau-Türkis
            (0, 28, 64, 0),
            (0, 24, 64, 0),
            (0, 20, 63, 0),
            (0, 16, 64, 0),
            (0, 12, 64, 0),
            (0, 8, 64, 0),
            (0, 4, 64, 0),
            (0, 0, 64, 0),  # Blau
            (3, 0, 63, 0),
            (8, 0, 64, 0),
            (11, 0, 64, 0),
            (11, 0, 64, 0),
            (12, 0, 64, 0),
            (16, 0, 64, 0),
            (20, 0, 64, 0),
            (24, 0, 64, 0),
            (28, 0, 64, 0),
            (32, 0, 64, 0),  # Violett-Blau
            (36, 0, 64, 0),
            (40, 0, 64, 0),
            (44, 0, 64, 0),
            (48, 0, 64, 0),
            (52, 0, 64, 0),
            (56, 0, 64, 0),
            (64, 0, 64, 0),  # Pink
            (64, 0, 60, 0),
            (64, 0, 56, 0),
            (64, 0, 52, 0),
            (64, 0, 48, 0),
            (64, 0, 44, 0),
            (64, 0, 40, 0),
            (64, 0, 36, 0),
            (64, 0, 32, 0),  # Pink-Rot
            (64, 0, 28, 0),
            (64, 0, 24, 0),
            (64, 0, 20, 0),
            (64, 0, 16, 0),
            (64, 0, 12, 0),
            (64, 0, 8, 0),
            (64, 0, 4, 0),
            (64, 0, 2, 0)]

            
            
        # Global variable to track whether the rainbow LED is on or off
        self.rainbow_on = False
        
        print("Rainbow wurde initialisiert")

        self.thread_mid = None

        self.init = True
        
        time.sleep(0.1)
        
    def np_top_array(self, position, value):
        
         self.np[position] = value
    
    def np_mid_array(self, position, value):
        
        #print("Position mid array: ", position)
   
        
        self.np[position + self.NUM_LEDS_TOP] = value
    
    def bottom1_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value
    
    def bottom2_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value
        
    def bottom3_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value

                
    def rainbow_mid_led(self, stop_event, diming, firstround = True):

        if diming:
            print("rainbow dimming activ")
            self.RAINBOW_COLORS = [
                (127, 0, 0, 0), # Rot
                (128, 8, 0, 0),
                (128, 16, 0, 0),
                (128, 24, 0, 0),
                (128, 32, 0, 0),
                (128, 40, 0, 0),
                (128, 48, 0, 0),
                (128, 56, 0, 0),
                (127, 64, 0, 0),
                (128, 72, 0, 0),
                (128, 80, 0, 0),
                (128, 88, 0, 0),
                (128, 96, 0, 0),
                (128, 104, 0, 0),
                (128, 112, 0, 0),
                (128, 128, 0, 0), # Orange
                (120, 128, 0, 0),
                (112, 128, 0, 0),
                (104, 128, 0, 0),
                (96, 128, 0, 0),
                (88, 128, 0, 0),
                (80, 128, 0, 0),
                (72, 128, 0, 0),
                (64, 128, 0, 0),
                (56, 128, 0, 0),
                (48, 128, 0, 0),
                (40, 128, 0, 0),
                (32, 128, 0, 0),
                (24, 128, 0, 0),
                (16, 128, 0, 0),
                (8, 128, 0, 0),
                (0, 128, 0, 0), # Grün
                (0, 128, 8, 0),
                (0, 128, 16, 0),
                (0, 128, 24, 0),
                (0, 128, 32, 0),
                (0, 128, 40, 0),
                (0, 128, 48, 0),
                (0, 128, 56, 0),
                (0, 128, 64, 0),
                (0, 128, 72, 0),
                (0, 128, 80, 0),
                (0, 128, 88, 0),
                (0, 128, 96, 0),
                (0, 128, 104, 0),
                (0, 128, 112, 0),
                (0, 128, 120, 0),
                (0, 128, 128, 0), # Türkis-Grün
                (0, 120, 128, 0),
                (0, 112, 128, 0),
                (0, 104, 128, 0),
                (0, 96, 128, 0),
                (0, 88, 128, 0),
                (0, 80, 128, 0),
                (0, 72, 128, 0),
                (0, 64, 128, 0),
                (0, 56, 128, 0),
                (0, 48, 128, 0),
                (0, 40, 128, 0),
                (0, 32, 128, 0),
                (0, 24, 128, 0),
                (0, 16, 128, 0),
                (0, 8, 128, 0),
                (0, 0, 128, 0), # Blau
                (8, 0, 128, 0),
                (16, 0, 128, 0),
                (21, 0, 128, 0),
                (22, 0, 128, 0),
                (24, 0, 128, 0),
                (32, 0, 128, 0),
                (40, 0, 128, 0),
                (48, 0, 128, 0),
                (56, 0, 128, 0),
                (64, 0, 128, 0),
                (72, 0, 128, 0),
                (80, 0, 128, 0),
                (88, 0, 128, 0),
                (96, 0, 128, 0),
                (104, 0, 128, 0),
                (112, 0, 128, 0),
                (128, 0, 128, 0), # Violett-Blau
                (128, 0, 120, 0),
                (128, 0, 112, 0),
                (128, 0, 104, 0),
                (128, 0, 96, 0),
                (128, 0, 88, 0),
                (128, 0, 80, 0),
                (128, 0, 72, 0),
                (128, 0, 64, 0),
                (128, 0, 56, 0),
                (128, 0, 48, 0),
                (128, 0, 40, 0),
                (128, 0, 32, 0),
                (128, 0, 24, 0),
                (128, 0, 16, 0),
                (128, 0, 8, 0),
                (128, 0, 4, 0),
                (128, 0, 2, 0)]
            


            # 25% gedimmt



        	

        

        gc.enable()

        # Define the rainbow colors
        # Display the colors
        
        r4= 0
        r2 = 0  # wird verwendet um den Farbindex der oberen Schleife zu tracken (soll um 1 erhöht werden jedes mal wenn in TOP LED geschrieben wurde)
        r = 0  # wird verwendet um die oberen LEDs langsamer zu triggern als der Mittlere LED Streifen da sonst (zu schnell)
        j = 0  # wird verwendet um die Anzahl der durchläufe der True Schleife zu zählen
        if self.rainbow_on == False:
                return
            
            

            
            
                
            
        while self.rainbow_on:
            
            #print("Rainbow durchlauf anfang")
            
            # Iterate through each LED

            #soll rainbow beendet werden?
            if stop_event.is_set():
                self.stop()
                return
            

            
            
            # ist rainbow pausiert?
            if self.paused == True:
                time.sleep(0.01)
                continue
            if firstround != True:
                time.sleep(0.01)
           
            # obere LEDS
            
            self.np_top_array(0, self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)])
            self.np_top_array(1, self.RAINBOW_COLORS[(r2+2) % len(self.RAINBOW_COLORS)])
            self.np_top_array(2, self.RAINBOW_COLORS[(r2+4) % len(self.RAINBOW_COLORS)])
            self.np_top_array(3, self.RAINBOW_COLORS[(r2+6) % len(self.RAINBOW_COLORS)])
            self.np_top_array(4, self.RAINBOW_COLORS[(r2+8) % len(self.RAINBOW_COLORS)])
            self.np_top_array(5, self.RAINBOW_COLORS[(r2+10) % len(self.RAINBOW_COLORS)])
            self.np_top_array(6, self.RAINBOW_COLORS[(r2+8) % len(self.RAINBOW_COLORS)])
            self.np_top_array(7, self.RAINBOW_COLORS[(r2+6) % len(self.RAINBOW_COLORS)])
            self.np_top_array(8, self.RAINBOW_COLORS[(r2+4) % len(self.RAINBOW_COLORS)])
            self.np_top_array(9, self.RAINBOW_COLORS[(r2+2) % len(self.RAINBOW_COLORS)])
          

            
            if stop_event.is_set():
                self.stop()
                return
            if firstround != True:
                time.sleep(0.01)

            self.np_mid_array(0, self.RAINBOW_COLORS[((r4) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(1, self.RAINBOW_COLORS[((r4+1) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(2, self.RAINBOW_COLORS[((r4+2) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(3, self.RAINBOW_COLORS[((r4+3) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(4, self.RAINBOW_COLORS[((r4+4) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(5, self.RAINBOW_COLORS[((r4+5) % self.NUM_LEDS_MID*-1)])
            
            self.np_mid_array(6, self.RAINBOW_COLORS[((r4 + 6) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(7, self.RAINBOW_COLORS[((r4 + 7) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(8, self.RAINBOW_COLORS[((r4 + 8) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(9, self.RAINBOW_COLORS[((r4 + 9) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(10, self.RAINBOW_COLORS[((r4 + 10) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(11, self.RAINBOW_COLORS[((r4 + 11) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(12, self.RAINBOW_COLORS[((r4 + 12) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(13, self.RAINBOW_COLORS[((r4 + 13) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(14, self.RAINBOW_COLORS[((r4 + 14) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(15, self.RAINBOW_COLORS[((r4 + 15) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(16, self.RAINBOW_COLORS[((r4 + 16) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(17, self.RAINBOW_COLORS[((r4 + 17) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(18, self.RAINBOW_COLORS[((r4 + 18) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(19, self.RAINBOW_COLORS[((r4 + 19) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(20, self.RAINBOW_COLORS[((r4 + 20) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(21, self.RAINBOW_COLORS[((r4 + 21) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(22, self.RAINBOW_COLORS[((r4 + 22) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(23, self.RAINBOW_COLORS[((r4 + 23) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(24, self.RAINBOW_COLORS[((r4 + 24) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(25, self.RAINBOW_COLORS[((r4 + 25) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(26, self.RAINBOW_COLORS[((r4 + 26) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(27, self.RAINBOW_COLORS[((r4 + 27) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(28, self.RAINBOW_COLORS[((r4 + 28) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(29, self.RAINBOW_COLORS[((r4 + 29) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(30, self.RAINBOW_COLORS[((r4 + 30) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(31, self.RAINBOW_COLORS[((r4 + 31) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(32, self.RAINBOW_COLORS[((r4 + 32) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(33, self.RAINBOW_COLORS[((r4 + 33) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(34, self.RAINBOW_COLORS[((r4 + 34) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(35, self.RAINBOW_COLORS[((r4 + 35) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(36, self.RAINBOW_COLORS[((r4 + 36) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(37, self.RAINBOW_COLORS[((r4 + 37) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(38, self.RAINBOW_COLORS[((r4 + 38) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(39, self.RAINBOW_COLORS[((r4 + 39) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(40, self.RAINBOW_COLORS[((r4 + 40) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(41, self.RAINBOW_COLORS[((r4 + 41) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(42, self.RAINBOW_COLORS[((r4 + 42) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(43, self.RAINBOW_COLORS[((r4 + 43) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(44, self.RAINBOW_COLORS[((r4 + 44) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(45, self.RAINBOW_COLORS[((r4 + 45) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(46, self.RAINBOW_COLORS[((r4 + 46) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(47, self.RAINBOW_COLORS[((r4 + 47) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(48, self.RAINBOW_COLORS[((r4 + 48) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(49, self.RAINBOW_COLORS[((r4 + 49) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(50, self.RAINBOW_COLORS[((r4 + 50) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(51, self.RAINBOW_COLORS[((r4 + 51) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(52, self.RAINBOW_COLORS[((r4 + 52) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(53, self.RAINBOW_COLORS[((r4 + 53) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(54, self.RAINBOW_COLORS[((r4 + 54) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(55, self.RAINBOW_COLORS[((r4 + 55) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(56, self.RAINBOW_COLORS[((r4 + 56) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(57, self.RAINBOW_COLORS[((r4 + 57) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(58, self.RAINBOW_COLORS[((r4 + 58) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(59, self.RAINBOW_COLORS[((r4 + 59) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(60, self.RAINBOW_COLORS[((r4 + 60) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(61, self.RAINBOW_COLORS[((r4 + 61) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(62, self.RAINBOW_COLORS[((r4 + 62) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(63, self.RAINBOW_COLORS[((r4 + 63) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(64, self.RAINBOW_COLORS[((r4 + 64) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(65, self.RAINBOW_COLORS[((r4 + 65) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(66, self.RAINBOW_COLORS[((r4 + 66) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(67, self.RAINBOW_COLORS[((r4 + 67) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(68, self.RAINBOW_COLORS[((r4 + 68) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(69, self.RAINBOW_COLORS[((r4 + 69) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(70, self.RAINBOW_COLORS[((r4 + 70) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(71, self.RAINBOW_COLORS[((r4 + 71) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(72, self.RAINBOW_COLORS[((r4 + 72) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(73, self.RAINBOW_COLORS[((r4 + 73) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(74, self.RAINBOW_COLORS[((r4 + 74) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(75, self.RAINBOW_COLORS[((r4 + 75) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(76, self.RAINBOW_COLORS[((r4 + 76) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(77, self.RAINBOW_COLORS[((r4 + 77) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(78, self.RAINBOW_COLORS[((r4 + 78) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(79, self.RAINBOW_COLORS[((r4 + 79) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(80, self.RAINBOW_COLORS[((r4 + 80) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(81, self.RAINBOW_COLORS[((r4 + 81) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(82, self.RAINBOW_COLORS[((r4 + 82) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(83, self.RAINBOW_COLORS[((r4 + 83) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(84, self.RAINBOW_COLORS[((r4 + 84) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(85, self.RAINBOW_COLORS[((r4 + 85) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(86, self.RAINBOW_COLORS[((r4 + 86) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(87, self.RAINBOW_COLORS[((r4 + 87) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(88, self.RAINBOW_COLORS[((r4 + 88) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(89, self.RAINBOW_COLORS[((r4 + 89) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(90, self.RAINBOW_COLORS[((r4 + 90) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(91, self.RAINBOW_COLORS[((r4 + 91) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(92, self.RAINBOW_COLORS[((r4 + 92) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(93, self.RAINBOW_COLORS[((r4 + 93) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(94, self.RAINBOW_COLORS[((r4 + 94) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(95, self.RAINBOW_COLORS[((r4 + 95) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(96, self.RAINBOW_COLORS[((r4 + 96) % self.NUM_LEDS_MID*-1)])
            self.np_mid_array(97, self.RAINBOW_COLORS[((r4 + 97) % self.NUM_LEDS_MID*-1)])

#             
#             
#             if self.rainbow_on == False:
#                 return
#             
#             self.np_mid_array((r4 + 6) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[6]) 
#             self.np_mid_array((r4 + 7) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[7])
#             self.np_mid_array((r4 + 8) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[8])
#             self.np_mid_array((r4 + 9) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[9]) 
#             self.np_mid_array((r4 + 10) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[10]) 
#             self.np_mid_array((r4 + 11) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[11]) 
#             self.np_mid_array((r4 + 12) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[12]) 
#             self.np_mid_array((r4 + 13) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[13]) 
# 
#             self.np_mid_array((r4 + 14) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[14]) 
#             self.np_mid_array((r4 + 15) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[15]) 
#             self.np_mid_array((r4 + 16) % self.NUM_LEDS_MID*-1,self.RAINBOW_COLORS[16]) 
#             self.np_mid_array((r4 + 17) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[17]) 
#             self.np_mid_array((r4 + 18) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[18]) 
#             self.np_mid_array((r4 + 19) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[19]) 
# 
#             self.np_mid_array((r4 + 20) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[20])
#             self.np_mid_array((r4 + 21) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[21])
#             self.np_mid_array((r4 + 22) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[22])
#             self.np_mid_array((r4 + 23) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[23])
#             self.np_mid_array((r4 + 24) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[24])
#             self.np_mid_array((r4 + 25) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[25])
#             self.np_mid_array((r4 + 26) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[26])
#             self.np_mid_array((r4 + 27) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[27])
#             self.np_mid_array((r4 + 28) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[28])
#             self.np_mid_array((r4 + 29) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[29])
#             
#             self.np_mid_array((r4 + 30) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[30])
#             self.np_mid_array((r4 + 31) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[31])
#             self.np_mid_array((r4 + 32) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[32])
#             self.np_mid_array((r4 + 33) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[33])
#             self.np_mid_array((r4 + 34) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[34])
#             self.np_mid_array((r4 + 35) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[35])
#             self.np_mid_array((r4 + 36) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[36])
#             self.np_mid_array((r4 + 37) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[37])
#             self.np_mid_array((r4 + 38) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[38])
#             self.np_mid_array((r4 + 39) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[39])
#             
#             self.np_mid_array((r4 + 40) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[40])
#             self.np_mid_array((r4 + 41) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[41])
#             self.np_mid_array((r4 + 42) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[42])
#             self.np_mid_array((r4 + 43) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[43])
#             self.np_mid_array((r4 + 44) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[44])
#             self.np_mid_array((r4 + 45) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[45])
#             self.np_mid_array((r4 + 46) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[46])
#             self.np_mid_array((r4 + 47) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[47])
#             self.np_mid_array((r4 + 48) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[48])
#             self.np_mid_array((r4 + 49) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[49])
#             
#             self.np_mid_array((r4 + 50) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[50])
#             self.np_mid_array((r4 + 51) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[51])
#             self.np_mid_array((r4 + 52) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[52])
#             self.np_mid_array((r4 + 53) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[53])
#             self.np_mid_array((r4 + 54) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[54])
#             self.np_mid_array((r4 + 55) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[55])
#             self.np_mid_array((r4 + 56) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[56])
#             self.np_mid_array((r4 + 57) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[57])
#             self.np_mid_array((r4 + 58) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[58])
#             self.np_mid_array((r4 + 59) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[59])
#             
#             self.np_mid_array((r4 + 60) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[60])
#             self.np_mid_array((r4 + 61) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[61])
#             self.np_mid_array((r4 + 62) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[62])
#             self.np_mid_array((r4 + 63) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[63])
#             self.np_mid_array((r4 + 64) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[64])
#             self.np_mid_array((r4 + 65) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[65])
#             self.np_mid_array((r4 + 66) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[66])
#             self.np_mid_array((r4 + 67) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[67])
#             self.np_mid_array((r4 + 68) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[68])
#             self.np_mid_array((r4 + 69) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[69])
#             
#             self.np_mid_array((r4 + 70) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[70])
#             self.np_mid_array((r4 + 71) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[71])
#             self.np_mid_array((r4 + 72) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[72])
#             self.np_mid_array((r4 + 73) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[73])
#             self.np_mid_array((r4 + 74) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[74])
#             self.np_mid_array((r4 + 75) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[75])
#             self.np_mid_array((r4 + 76) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[76])
#             self.np_mid_array((r4 + 77) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[77])
#             self.np_mid_array((r4 + 78) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[78])
#             self.np_mid_array((r4 + 79) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[79])
#             
#             self.np_mid_array((r4 + 80) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[80])
#             self.np_mid_array((r4 + 81) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[81])
#             self.np_mid_array((r4 + 82) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[82])
#             self.np_mid_array((r4 + 83) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[83])
#             self.np_mid_array((r4 + 84) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[84])
#             self.np_mid_array((r4 + 85) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[85])
#             self.np_mid_array((r4 + 86) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[86])
#             self.np_mid_array((r4 + 87) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[87])
#             self.np_mid_array((r4 + 88) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[88])
#             self.np_mid_array((r4 + 89) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[89])
#             
#             self.np_mid_array((r4 + 90) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[90])
#             self.np_mid_array((r4 + 91) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[91])
#             self.np_mid_array((r4 + 92) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[92])
#             self.np_mid_array((r4 + 93) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[93])
#             self.np_mid_array((r4 + 94) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[94])
#             self.np_mid_array((r4 + 95) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[95])
#             self.np_mid_array((r4 + 96) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[96])
#             self.np_mid_array((r4 + 97) % self.NUM_LEDS_MID*-1, self.RAINBOW_COLORS[97])
# 
            
            if stop_event.is_set():
                self.stop()
                return

            if firstround != True:
                time.sleep(0.01)
            
          
# 
#             #             for u in range(self.NUM_LEDS_BOTTOM):
#             #                 
#             #                 self.np_bottom_first[u] = self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)]
#             #                 self.np_bottom_second[u] = self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)]
#             #                 self.np_bottom_third[u] = self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)]
# 
#             # untere LEDS
# 
            self.bottom1_array(0, self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(1,  self.RAINBOW_COLORS[(r2 + 1) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(2,  self.RAINBOW_COLORS[(r2 + 2) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(3,  self.RAINBOW_COLORS[(r2 + 3) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(4,  self.RAINBOW_COLORS[(r2 + 4) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(5,  self.RAINBOW_COLORS[(r2 + 5) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(6,  self.RAINBOW_COLORS[(r2 + 6) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(7,  self.RAINBOW_COLORS[(r2 + 7) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(8,  self.RAINBOW_COLORS[(r2 + 8) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(9,  self.RAINBOW_COLORS[(r2 + 9) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(10,  self.RAINBOW_COLORS[(r2 + 10) % len(self.RAINBOW_COLORS)])
            self.bottom1_array(11,  self.RAINBOW_COLORS[(r2 + 11) % len(self.RAINBOW_COLORS)])
            
            self.bottom2_array(0, self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(1,  self.RAINBOW_COLORS[(r2 + 1) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(2,  self.RAINBOW_COLORS[(r2 + 2) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(3,  self.RAINBOW_COLORS[(r2 + 3) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(4,  self.RAINBOW_COLORS[(r2 + 4) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(5,  self.RAINBOW_COLORS[(r2 + 5) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(6,  self.RAINBOW_COLORS[(r2 + 6) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(7,  self.RAINBOW_COLORS[(r2 + 7) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(8,  self.RAINBOW_COLORS[(r2 + 8) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(9,  self.RAINBOW_COLORS[(r2 + 9) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(10,  self.RAINBOW_COLORS[(r2 + 10) % len(self.RAINBOW_COLORS)])
            self.bottom2_array(11,  self.RAINBOW_COLORS[(r2 + 11) % len(self.RAINBOW_COLORS)])
            
            self.bottom3_array(0, self.RAINBOW_COLORS[(r2) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(1,  self.RAINBOW_COLORS[(r2 + 1) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(2,  self.RAINBOW_COLORS[(r2 + 2) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(3,  self.RAINBOW_COLORS[(r2 + 3) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(4,  self.RAINBOW_COLORS[(r2 + 4) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(5,  self.RAINBOW_COLORS[(r2 + 5) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(6,  self.RAINBOW_COLORS[(r2 + 6) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(7,  self.RAINBOW_COLORS[(r2 + 7) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(8,  self.RAINBOW_COLORS[(r2 + 8) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(9,  self.RAINBOW_COLORS[(r2 + 9) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(10,  self.RAINBOW_COLORS[(r2 + 10) % len(self.RAINBOW_COLORS)])
            self.bottom3_array(11,  self.RAINBOW_COLORS[(r2 + 11) % len(self.RAINBOW_COLORS)])
#             

#             if self.rainbow_on == False:
#                 return
#             
#             self.np_bottom_second[0] = self.RAINBOW_COLORS[(r2 + 0) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[1] = self.RAINBOW_COLORS[(r2 + 1) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[2] = self.RAINBOW_COLORS[(r2 + 2) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[3] = self.RAINBOW_COLORS[(r2 + 3) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[4] = self.RAINBOW_COLORS[(r2 + 4) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[5] = self.RAINBOW_COLORS[(r2 + 5) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[6] = self.RAINBOW_COLORS[(r2 + 6) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[7] = self.RAINBOW_COLORS[(r2 + 7) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[8] = self.RAINBOW_COLORS[(r2 + 8) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[9] = self.RAINBOW_COLORS[(r2 + 9) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[10] = self.RAINBOW_COLORS[(r2 + 10) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_second[11] = self.RAINBOW_COLORS[(r2 + 11) % len(self.RAINBOW_COLORS)]
# 
#             self.np_bottom_third[0] = self.RAINBOW_COLORS[(r2 + 0) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[1] = self.RAINBOW_COLORS[(r2 + 1) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[2] = self.RAINBOW_COLORS[(r2 + 2) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[3] = self.RAINBOW_COLORS[(r2 + 3) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[4] = self.RAINBOW_COLORS[(r2 + 4) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[5] = self.RAINBOW_COLORS[(r2 + 5) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[6] = self.RAINBOW_COLORS[(r2 + 6) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[7] = self.RAINBOW_COLORS[(r2 + 7) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[8] = self.RAINBOW_COLORS[(r2 + 8) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[9] = self.RAINBOW_COLORS[(r2 + 9) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[10] = self.RAINBOW_COLORS[(r2 + 10) % len(self.RAINBOW_COLORS)]
#             self.np_bottom_third[11] = self.RAINBOW_COLORS[(r2 + 11) % len(self.RAINBOW_COLORS)]
#             
            if stop_event.is_set():
                self.stop()
                return
            # bedingung wann obere leds neu beschrieben werden
            # if j % 2 is 0:

            # self.np.write()

            j = j + 1
            r = r + 1
            
            if r%2 == 0:
                
                if stop_event.is_set():
                    self.stop()
                    return
            
                r4 = r4 +1
            # schreibe in jeden durchlauf mittleren led streifen

                #self.strip.show()

            if r > 4:
                r = 0
                r2 = r2 + 1
                try:
                

                    if firstround == True:
                        firstround = False

                    #print("sollte sichtbar sein")
                
                except Exception as e:
                    print("Fehler beim schreiben aufgetreten: ", e)

            self.np.show()
            if stop_event.is_set():
                self.stop()
                return
            
            #print("Durchlauf")

            
            #zeitmessung:
            
            #print('Total time ein durchlauf: {:4d} straight python'.format(end - start))
            

    #     def rainbow_mid_led3(self):
    #         color = (0, 0, 0, 200)
    #         for i in range(self.NUM_LEDS_MID):
    #             self.np_mid_array(i] = color
    #             self.strip.write()
    #             time.sleep_us(4)





    def rainbow_off(self):

        ##self.strip.fill((0, 0, 0, 0))
        self.np.fill((0, 0, 0, 0))

        #self.strip.write()
        #self.np_bottom_first.fill((0, 0, 0, 0))
        #self.np_bottom_second.fill((0, 0, 0, 0))
        #self.np_bottom_third.fill((0, 0, 0, 0))

        self.np.write()
        #self.np_bottom_first.write()
        #self.np_bottom_second.write()
        #self.np_bottom_third.write()
        

        
        
  

    def start(self, stop_event, diming):
        print("start Rainbow innerhalb Rainbow Klasse getrigget!")
        self.rainbow_on = True
        self.rainbow_mid_led(stop_event, diming)
        
        '''
        try:
            _thread.exit
        except:
            pass
        self.rainbow_on = True
        
        try: 
            _thread.start_new_thread(self.rainbow_mid_led, ())
        except:
            time.sleep(0.07)
            self.start()
        return True
        '''

    def stop(self):
     
        self.rainbow_on = False

        
        self.rainbow_off()
        
        self.np.deinit()


    def get_Status(self):
        return self.rainbow_on


#rainbow = RainbowLED(False)
#stop_event = multiprocessing.Event()
#diming = True
#rainbow.start(stop_event, diming)
