import os
import re
import subprocess
import uuid
import time

from WIFI_Manager import Wifi_Connection, run_command


def get_mac_address(interface='eth0'):
    try:
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) for elements in range(2, 7)][::-1])
    except FileNotFoundError:
        mac = '00:00:00:00:00:00'
    return mac.strip()

def generate_unique_name(prefix='solarlampe'):
    mac_address = get_mac_address()
    cleaned_mac = re.sub('[:]', '', mac_address)
    unique_name = '{}{}'.format(prefix, cleaned_mac)
    return unique_name

def get_current_hostname():
    try:
        with open('/etc/hostname', 'r') as file:
            return file.read().strip()
    except Exception as e:
        print(f"Fehler beim Lesen des Hostnamens: {e}")
        return None


def update_hosts_file(new_hostname):
    # Verwendet sed, um den Hostnamen in /etc/hosts zu aktualisieren
    # sed_command = f"sed -i 's/{old_hostname}/{new_hostname}/g' /etc/hosts"
    # subprocess.run(['sudo', 'bash', '-c', sed_command], check=True)
    with open('/etc/hosts', 'r') as file:
        # read a list of lines into data
        data = file.readlines()

        # the host name is on the 6th line following the IP address
        # so this replaces that line with the new hostname
    data[5] = '127.0.1.1       ' + new_hostname

    # save the file temporarily because /etc/hosts is protected
    with open('temp.txt', 'w') as file:
        file.writelines(data)

    # use sudo command to overwrite the protected file
    os.system('sudo mv temp.txt /etc/hosts')


def set_hostname(new_hostname):
    # Aktualisiert /etc/hostname
    subprocess.run(['sudo', 'bash', '-c', f'echo "{new_hostname}" > /etc/hostname'], check=True)

    # Aktualisiert /etc/hosts
    current_hostname = get_current_hostname()
    if current_hostname:
        update_hosts_file(new_hostname)

    # Setzt den Hostnamen im laufenden System
    subprocess.run(['sudo', 'hostname', new_hostname], check=True)
    subprocess.run(['sudo', 'reboot'], check=True)

def change_hostname():
    desired_hostname = generate_unique_name()

    current_hostname = get_current_hostname()
    print("Current Hostname:", current_hostname)

    if current_hostname != desired_hostname:
        print("Changing Hostname to:", desired_hostname)

        # Löscht alle WLAN-Credentials
        Wifi_Connection.delete_all_wifi_credentials()
        print("Hostname changed and WiFi credentials deleted.")

        # Optional: Neustart des Netzwerkdienstes
        run_command("sudo systemctl restart networking")

        set_hostname(desired_hostname)



    else:
        print("Hostname is already correct.")


# change_hostname()
# current_name = get_current_hostname()
# set_hostname(current_name)