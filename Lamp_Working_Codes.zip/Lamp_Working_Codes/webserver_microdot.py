# import network
import asyncio
# from led_programm_rainbow import rainbow
# import pkg_resources
# from led_programm_rainy_days import rainy_days

# from touch_input import touchinput
import check_ist_am_laden
from check_ist_am_laden import checkloading

import json
import os

from control_motor_interpreter import MotorInterpreter

from microdot_asyncio import Microdot
import threading
import gc

lock = threading.Lock()
motor_interpreter = MotorInterpreter()


def unquote(s):
    result = s.replace('+', ' ')
    parts = result.split('%')
    for i in range(1, len(parts)):
        h = parts[i][0:2]
        c = chr(int(h, 16))
        parts[i] = c + parts[i][2:]
    return ''.join(parts)


def parse_urlencoded_data(data):
    result = {}
    pairs = data.split("&")
    for pair in pairs:
        key, value = pair.split("=", 1)
        result[unquote(key)] = unquote(value)
    return result


def delete_files():
    files = ['ssid_package1.txt', 'pwd_package1.txt', 'ip_adress.txt']
    for file in files:
        try:
            os.remove(file)
            print("Die Datei '{file}' wurde erfolgreich gelöscht.")
        except FileNotFoundError:
            print("Die Datei '{file}' konnte nicht gefunden werden.")
        except Exception as e:
            print("Ein Fehler ist beim Löschen der Datei '{file}' aufgetreten: {e}")

    return True


lamp_config = None
# motor_interpreter = None

# JSON Datei zum Testen
jsonData = {"sensor": "temperature", "value": "10"}

from update_manager import updatemanager

###############################################
# setup webserver
app = Microdot()


# @app.route('/')
# async def hello(request):
#     return jsonData


@app.route('/heartbeat')
async def heartbeat(request):
    # Öffnet das current lampmodel .json um isSolarpowered zu aktualisieren bevor der state zurück an die Lampe geht
    checkloading.write_is_solarpowered()
    from control_ladechip import MAX17261
    from ladestrom_tests import BQ25731
    import gauge_test
    from spannung_staerke_test import ControlBattery

    battery_controller = ControlBattery(i2c_bus=1, chip_address=0x6B)  # i2c connection to power-chip on adress 0x6B
    akku = MAX17261()  # batterie chip
    power_control = BQ25731()  # power-chip for load power settings
    battery_controller.disable_watchdog()
    battery_controller.update_registers()
    power_control.set_charge_current(4)  # sets loading to 3 A max
    # gauge = gauge_test
    ladestand = akku.run_ladechip()
    ladestand = round(ladestand)

    adc_dac_value = battery_controller.read_current(0x29)  # reads value from register 0x29
    adc_iin_value = battery_controller.read_current(0x2B)  # reads value from register 0x2B
    adc_dacdic_value = battery_controller.read_current(0x28)
    ladestaerke = battery_controller.calculate_current(adc_dac_value, lsb=128.0)  # charging value in mA
    total_power_uncalc = battery_controller.calculate_current(adc_iin_value,
                                                              lsb=100.0)  # power consumption on chip in mA
    discharge_batterie = battery_controller.calculate_current(adc_dacdic_value, lsb=512.0)  # discharge value in mA
    voltage, psys, input_current, charge_current = battery_controller.get_battery_charge_data()
    discharge_total = discharge_batterie / 1000
    ladestaerke = ladestaerke / 1000
    akku_cap = 12000

    if 95 < ladestand < 105:
        ladestand = 100
    elif 1 >= ladestand > 0:
        ladestand = 1

    akku_in_ah = (akku_cap * (ladestand / 100)) / 1000

    #ladestand = -1  # for testing frontend

    # Lese den aktuellen Zustand des Lampenmodells
    with open('current_lampmodel.json', 'r') as file:
        data = json.load(file)  # Lädt den JSON-Inhalt direkt in ein Python-Dictionary

    # Aktualisiere den Ladestand im Dictionary
    data['akkuladungInProzent'] = str(ladestand)
    data['ladestaerke'] = str(ladestaerke)
    data['akkuladungInAh'] = str(akku_in_ah)
    data['rotationSliderValue'] = str(discharge_total)  # need to be refactored naming etc.
    # Schreibe das aktualisierte Dictionary zurück in die JSON-Datei

    with open('current_lampmodel.json', 'w') as file:
        json.dump(data, file, indent=4)  # Für eine schön formatierte Ausgabe

    with open('current_lampmodel.json', 'r') as file:
        json_str = file.read()
        print(json_str)

    # JSON-String als Antwort zurückgeben
    print(voltage, "VOLTAGE--------------")
    print(total_power_uncalc, "charging_power max--------------")
    print(ladestaerke, "actuall charging")
    print(discharge_total, "Discharge--------------")
    print(psys, "    psys--------------")
    return json_str


# @app.route('/heartbeat')
# async def heartbeat(request):
#     # öffnet das current lampmodel .json um isSolarpowered zu aktiualisieren bevor der state zurück an die Lampe geht
#     checkloading.write_is_solarpowered()
#     from ladechip_tests import MAX17261
#     akku = MAX17261()
#     ladestand = akku.get_soc()
#
#     with open('current_lampmodel.json', 'r') as file:
#         json_str = file.read()
#         print(json_str)
#
#         # JSON-String als Antwort zurückgeben
#     return json_str


@app.route('/heartbeat_shared')
async def heartbeat(request):
    # öffnet das current lampmodel .json um isSolarpowered zu aktiualisieren bevor der state zurück an die Lampe geht
    checkloading.write_is_solarpowered()

    with open('current_lampmodel_shared.json', 'r') as file:
        json_str = file.read()
        print(json_str)

        # JSON-String als Antwort zurückgeben
    return json_str


def update_missing_keys_from_check(current_json_path, check_json_path):
    # Load the check JSON with default values
    with open(check_json_path, 'r') as file:
        check_json = json.load(file)

    # Load the current motor status
    with open(current_json_path, 'r') as file:
        current_motor_status = json.load(file)

    # Flag to track if updates are made
    update_needed = False

    # Check each key in check_json to see if it's missing in current_motor_status
    for key, value in check_json.items():
        if key not in current_motor_status:
            current_motor_status[key] = value  # Add missing key with default value
            update_needed = True

    # If any updates were made, write back to the current JSON file
    if update_needed:
        with open(current_json_path, 'w') as file:
            json.dump(current_motor_status, file, indent=4)


@app.route('/motor_heartbeat')
async def motor_heartbeat(request):
    current_json_path = 'current_motor_status.json'
    check_json_path = 'check_motor_status.json'

    try:
        # Attempt to read and print the current motor status for debugging
        with open(current_json_path, 'r') as file:
            json_str = file.read()
            # print(json_str)  # Ensure this prints valid JSON
        # Update missing keys based on the check JSON

        update_missing_keys_from_check(current_json_path, check_json_path)
        print(json_str)
    except json.decoder.JSONDecodeError as e:
        # If there's a JSON error, print it out
        print(f"Error reading {current_json_path}: {e}")
        return "Error in JSON formatting", 500
    except Exception as e:
        # Catch any other exceptions and print them out
        print(f"An error occurred: {e}")
        return "An unexpected error occurred", 500

    # Assuming the update goes through, return the updated JSON string
    with open(current_json_path, 'r') as file:
        updated_json_str = file.read()
    print(updated_json_str)
    return updated_json_str


# @app.route('/motor_heartbeat')
# async def motor_heartbeat(request):
#     current_json = 'current_motor_status.json'
#     check_json = 'check_motor_status.json'
#
#     with open('current_motor_status.json', 'r') as file:
#         json_str = file.read()
#         print(json_str)
#     update_missing_keys_from_check(current_json, check_json)
#         # JSON-String als Antwort zurückgeben
#     return json_str

# Define the fields you want to update from the received JSON
allowed_fields_to_update = {"modus", "isGlowShowing", "isGlowAll", "isGlow1", "isGlow2", "isGlow3", "dimmValue1",
                            "dimmValue2", "dimmValue3", "laufzeit1start", "laufzeit1ende", "laufzeit2start",
                            "laufzeit2ende", "laufzeit3start", "laufzeit3ende", "laufzeit4start", "laufzeit4ende",
                            "moduslaufzeit1", "moduslaufzeit2", "moduslaufzeit3", "moduslaufzeit4",
                            "rotationSliderValue", "color1", "color2", "color3", "color4", "customcolor11",
                            "customcolor12", "customcolor13", "customcolor14", "customcolor21", "customcolor22",
                            "customcolor23", "customcolor24", "customcolor31", "customcolor32", "customcolor33",
                            "customcolor34", "customcolor41", "customcolor42", "customcolor43", "customcolor44",
                            "currentlaufzeitnummer", "currentlaufzeitstart", "currentlaufzeitende",
                            "currentlaufzeitmodus", "currentlaufzeitisactive", "istrackingactive"}


@app.route('/updatelamp_shared', methods=['POST'])
async def updatelamp_shared(request):
    with lock:
        body = request.body.decode()
        print("Received body: ", body)
        parsed_data = parse_urlencoded_data(body)

        # Load the current shared lamp model data
        with open("current_lampmodel_shared.json", "r") as file:
            current_data = json.load(file)

        with open("current_lampmodel.json", "r") as file:
            non_shared_data = json.load(file)

        # if all(current_data.get(key) == value for key, value in parsed_data.items()):
        #     print("Daten sind identisch, keine Aktion erforderlich.")
        #     return

        # Update only allowed fields present in the parsed_data from the POST request
        for field in parsed_data:
            if field in allowed_fields_to_update and field in current_data:
                current_data[field] = parsed_data[field]

        # Write the updated data back to the JSON file
        with open("current_lampmodel_shared.json", "w") as file:
            json.dump(current_data, file, indent=4)

        with open('current_lampmodel_shared.json', "r") as file:
            data_for_interp = json.load(file)

        run_shared = non_shared_data.get('isteilenactive', False)
        print("run_shared: ", run_shared)

        if run_shared == "true":
            lamp_config.load_json_data(data_for_interp, shared=1)
            print("Updated shared lamp model with selected data from POST request and run interpreter.")
        else:
            print("Updated shared lamp model with selected data from POST request.")


@app.route('/updatelamp', methods=['POST'])
async def updatelamp(request):
    with lock:
        body = request.body.decode()
        parsed_data = parse_urlencoded_data(body)
        print(parsed_data)

        try:
            with open("current_lampmodel.json", "r") as file:
                current_data = json.load(file)
        except Exception as e:
            print("Error in updatelamp: ", e)

        # Vergleiche die Werte der beiden Datenstrukturen
        if all(current_data.get(key) == value for key, value in parsed_data.items()):
            print("Daten sind identisch, keine Aktion erforderlich.")
            return

        try:
            # Wenn Daten unterschiedlich sind, führe das Update durch
            with open("current_lampmodel.json", "w") as file:
                json.dump(parsed_data, file, indent=4)
        except Exception as e:
            print("Error in updatelamp: ", e)

        if parsed_data.get('isteilenactive') == 'false':
            lamp_config.load_json_data(parsed_data)


# Update the 'updatemotor' route to use motor_interpreter for motor updates

@app.route('/updatemotor', methods=['POST'])
def updatemotor(request):
    global motor_interpreter

    with lock:
        body = request.body.decode()

        print(body)

        parsed_data = parse_urlencoded_data(body)

        with open('current_motor_status.json', 'r') as file:
            current_motorstatus = json.load(file)

        # Assuming 'key1' and 'key2' are the keys you want from the JSON file
        # Adjust the key names according to your actual JSON structure and requirements
        additional_data = {
            'current_tilt': current_motorstatus.get('current_tilt', 0),
            'current_rotation': current_motorstatus.get('current_rotation', 0)
        }

        print(additional_data)
        # Merge the additional data into parsed_data
        parsed_data.update(additional_data)

        print(parsed_data)

        # motor_interpreter call with post-data
        motor_interpreter.update_from_request(parsed_data)

    return "Motor settings updated successfully"


@app.route('/updatemotor_demo', methods=['POST'])
def updatemotor_demo(request):
    global motor_interpreter
    with lock:
        body = request.body.decode()

        print(body)

        parsed_data = parse_urlencoded_data(body)
        motor_interpreter.update_from_request_demo(parsed_data)

    return "Motor_demo settings updated successfully"


@app.route('/updatestatus', methods=['GET'])
async def updatestatus(request):
    with open('Update_Info.json', 'r') as file:
        json_str = file.read()
        print(json_str)

        # JSON-String als Antwort zurückgeben
    return json_str


# Route um Updateprozess manuell zu steuern
@app.route('/manualupdate', methods=['GET'])
async def manualupdate(request):
    try:
        if updatemanager.update_system(manual=True) == True:
            return f"Firmwareupdate erfolgreich, neue Firmwareversion der Lampe: {updatemanager.get_current_version_number()}"
    except Exception as e:
        return e


@app.route('/deletelamp')
async def deletelamp(request):
    print('deleteaktion ausgeführt!')
    # Öffnen Sie die neue -Datei und laden Sie das JSON-Objekt
    with open('default_lamp_model.json', 'r') as file1:
        neue_daten = json.loads(file1)
        print(neue_daten)
        file1.close

    # Öffnen Sie die vorhandene JSON-Datei und laden Sie das JSON-Objekt
    with open('current_lampmodel.json', 'r') as file2:
        vorhandene_daten = json.loads(file2)
        print(vorhandene_daten)
        # return "Deleted"
        file2.close

    # Fügen Sie die neuen Daten zu den vorhandenen Daten hinzu
    vorhandene_daten.update(neue_daten)
    print(vorhandene_daten)

    # Schreiben Sie die aktualisierten Daten zurück in die vorhandene JSON-Datei
    with open('current_lampmodel.json', 'w') as f:
        json.dump(vorhandene_daten, f, indent=4)

    if delete_files():
        return 'true'


def run_command(command):
    import subprocess
    print("run_command wurde getriggert")
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True, check=True)
    return result.stdout


# Startet den Webserver
def start_server(touchenabled=False):
    print(run_command("sudo chmod 777 webserver_microdot.py"))
    print(run_command("sudo chmod 777 microdot.py"))

    global lamp_config
    global motor_config
    if touchenabled == True:

        try:
            from lampmodel_interpreter_new import LampConfig
        except Exception as e:
            print("lampmodel interpreter konnte nicht in Webserver importiert werden: ", e)
        try:
            from control_motor_interpreter import MotorInterpreter
        except Exception as e:
            print("motormodel interpreter konnte nicht in Webserver importiert werden: ", e)

        json_file = "current_lampmodel.json"
        json_file_motor = "current_motor_status.json"

        lamp_config = LampConfig(json_file, True)
        motor_config = MotorInterpreter()

        print('Starting microdot und Interpreter mit Touch erkennung')

        try:
            app.run(debug=True, port=80)
            print("Webserver gestartet!")

        except Exception as e:
            print("Konnte Webserver nicht starten", e)
            app.shutdown()

    else:

        from lampmodel_interpreter_new import LampConfig
        from control_motor_interpreter import MotorInterpreter
        json_file = "current_lampmodel.json"
        json_file_motor = "current_motor_status.json"

        lamp_config = LampConfig(json_file, False)
        motor_config = MotorInterpreter()
        print('Starting microdot und Interpreter mit deaktivierter Touch (haube) erkennung')
        try:

            app.run(debug=True, port=80)
            print("Webserver gestartet!")


        except Exception as e:
            print("Konnte Webserver nicht starten", e)
            app.shutdown()


start_server(False)
