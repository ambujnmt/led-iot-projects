# import smbus
#
# # Erstellen Sie eine Instanz von SMBus
# bus = smbus.SMBus(1)
#
# # I2C Adresse des MAX17261
# device_address = 0x36  # Ersetzen Sie dies mit der tatsächlichen I2C-Adresse Ihres Geräts
#
# # Funktion zum Lesen eines 16-Bit-Werts aus zwei Registern
# def read_16bit_register(high_reg, low_reg):
#     high = bus.read_byte_data(device_address, high_reg)
#     low = bus.read_byte_data(device_address, low_reg)
#     return high | (low << 8)
#
# # Funktion zum Auslesen und Interpretieren des Fault Registers
# def check_faults():
#     fault_value = read_16bit_register(0x20, 0x21)  # Lesen der High- und Low-Bytes
#     if fault_value != 0:  # Wenn das Register nicht 0 ist, liegt ein Fehler vor
#         print(f"Fehler erkannt: {bin(fault_value)}")
#         # Führen Sie hier eine detaillierte Überprüfung der Bits durch, um den spezifischen Fehler zu identifizieren
#     else:
#         print("Keine Fehler erkannt")
#
# # Auslesen und Überprüfen auf Fehler
# check_faults()





import smbus


def setCurrentForLoading(ampere):
    # set current for Loading stellt die Ladestärke für den Akku ein, dieser wird automatisch nach unten korrigiert wenn dieser nicht wiederholt aufgerufen wird
    # Einstellungen für verschiedene Ladeströme (sie scheinen nicht verwendet zu werden, aber ich lasse sie hier)
    Ampere_2_4Register2_Value = 0x0C
    Ampere_2_4Register1_Value = 0xC0
    Ampere_1_4Register2_Value = 0x08
    Ampere_1_4Register1_Value = 0x00
    Ampere_4_4Register2_Value = 0x1C
    Ampere_4_4Register1_Value = 0x00

    Register1Value = None
    Register2Value = None

    # 1 Ampere Ladestrom
    if ampere == 1:
        Register1Value = Ampere_1_4Register1_Value
        Register2Value = Ampere_1_4Register2_Value
    # 2 Ampere Ladestrom
    elif ampere == 2:
        Register1Value = Ampere_2_4Register1_Value
        Register2Value = Ampere_2_4Register2_Value
    # 3 4 Ampere Ladestrom
    elif ampere == 4:
        Register1Value = Ampere_4_4Register1_Value
        Register2Value = Ampere_4_4Register2_Value
    # DEfault 300 mA setzen (0,3A)
    else:
        Register1Value = 0x00  # 300 mah
        Register2Value = 0x03  # 300 mah

    BQ25731_CURRENT_REGISTER1 = 0x02
    BQ25731_CURRENT_REGISTER2 = 0x03

    currentregister1writevalue = bytearray([BQ25731_CURRENT_REGISTER1, Register1Value])
    currentregister2writevalue = bytearray([BQ25731_CURRENT_REGISTER2, Register2Value])

    with i2c_device:
        # Schreiben in BQ25731_CURRENT_REGISTER2
        i2c_device.write(currentregister2writevalue)
        # Schreiben in BQ25731_CURRENT_REGISTER1
        i2c_device.write(currentregister1writevalue)

# Ersetzen Sie 0x1A durch die tatsächliche I2C-Adresse Ihres MAX17261
DEVICE_ADDRESS = 0x36
# Ersetzen Sie 1 durch den entsprechenden I2C-Bus (meistens 1 für neuere Pi Modelle)
bus = smbus.SMBus(1)


# Funktion zum Auslesen eines Registers
def read_register(register):
    return bus.read_byte_data(DEVICE_ADDRESS, register)


# Register 20/21 (Fault) und 22/23 (Status Bits) auslesen
fault = read_register(20) | (read_register(21) << 8)
status = read_register(22) | (read_register(23) << 8)

print(f"Fault: {fault}")
print(f"Status: {status}")
#


# import smbus
# import time
#
# # Erstellen Sie eine Instanz von SMBus
# # 1 bedeutet, dass wir /dev/i2c-1 verwenden (für neuere Raspberry Pi Modelle)
# bus = smbus.SMBus(1)
#
# # I2C Adresse des MAX17261
# device_address = 0x36  # Ersetzen Sie 0x36 durch die tatsächliche Adresse Ihres Geräts
#
# # Funktion, um ein 16-Bit-Register zu lesen
# def read_word(register):
#     low = bus.read_byte_data(device_address, register)
#     high = bus.read_byte_data(device_address, register + 1)
#     value = (high << 8) + low
#     return value
#
# # Funktion, um ein signiertes 16-Bit-Register zu konvertieren
# def convert_to_signed(value):
#     if value >= 0x8000:
#         return -((65535 - value) + 1)
#     else:
#         return value
#
# # Funktionen zum Lesen spezifischer Register
# def read_current():
#     value = read_word(0x0A)
#     return convert_to_signed(value)
#
# def read_avg_current():
#     value = read_word(0x0B)
#     return convert_to_signed(value)
#
# def read_maxmin_current():
#     value = read_word(0x1C)
#     return value  # Beachten Sie, dass eine besondere Behandlung erforderlich sein könnte, um Max und Min zu extrahieren
#
# # Lesen und Ausgeben der Werte
# current = read_current()
# avg_current = read_avg_current()
# maxmin_current = read_maxmin_current()
#
# print(f"Current: {current} LSB")
# print(f"Avg Current: {avg_current} LSB")
# print(f"MaxMin Current: {maxmin_current} LSB")
