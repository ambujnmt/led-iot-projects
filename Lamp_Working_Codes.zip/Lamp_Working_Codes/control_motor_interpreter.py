import Kompass_Accelerometer
from tilt_motor_control import Tilt_MotorControl
from rotation_motor_control import Rotation_MotorControl
import board
import json
import threading
import os
import time
from concurrent.futures import ThreadPoolExecutor
import control_sun_tracking
import control_compass
from shared_ressources import shared_resources
import busio


class MotorInterpreter:
    def __init__(self):

        # Get the absolute path to the JSON file
        self.tilt_fail = False
        self.previous_azimuth = None
        self.sun_tracking_thread = None
        self.control_auto_thread = None
        script_dir = os.path.dirname(os.path.realpath(__file__))
        self.json_filename = os.path.join(script_dir, 'current_motor_status.json')
        self.json_filename_lamp = os.path.join(script_dir, 'current_lampmodel.json')

        # Motor initialization
        self.motor_control_tilt = Tilt_MotorControl(board.D13, board.D7, board.D6)
        self.motor_control_rotation = Rotation_MotorControl(board.D10, board.D24, board.D11)

        self.auto_running = False
        self.stop_event = threading.Event()
        self.json_file_lock = threading.Lock()

        # Dictionary to hold updates from both threads
        self.json_updates = {}
        self.rotation_thread_event = threading.Event()
        self.tilt_thread_event = threading.Event()
        self.isAkku = None
        self.i2c_bus = board.I2C()
        self.kompass = Kompass_Accelerometer.Kompass(self.i2c_bus)

        self.rotation_lock = threading.Lock()
        self.tilt_lock = threading.Lock()
        self.tracking_on = False
        self.reset_on = False

        # Attribute to control continuous rotation
        self.continuous_rotation_event = threading.Event()
        self.rotation_count = 0
        self.continuous_rotation_on = 0
        self.continuous_rotation_thread = None

    def start_sun_tracking(self):
        self.sun_tracking_thread = threading.Thread(target=self.sun_tracking)
        self.sun_tracking_thread.start()

    def stop_sun_tracking(self):
        shared_resources.stop_event.set()
        if self.sun_tracking_thread:
            self.sun_tracking_thread.join()

        self.reset_tracking_state()

    def reset_tracking_state(self):
        # Setzen Sie hier alle relevanten Zustandsvariablen zurück
        self.previous_azimuth = None
        # self.update_json_entry('current_rotation', 0)
        # self.update_json_entry('desired_rotation', 0)
        # self.apply_json_updates()

    def get_north(self):
        i2c = busio.I2C(board.SCL, board.SDA)
        magnetometer = control_compass.Magnetometer(i2c)
        motor = Rotation_MotorControl(board.D10, board.D24, board.D11)
        data = self.load_settings()
        angle = data['current_rotation']
        try:
            try:
                while True:

                    x, y, z = magnetometer.read_magnetic_field()
                    heading = magnetometer.get_heading(x, y)

                    print(f"Magnetische Feldstärken: X={x}, Y={y}, Z={z}")
                    print(f"Himmelsrichtung: {heading} Grad")
                    if shared_resources.stop_event.is_set():
                        break

                    if 89 <= heading <= 91:
                        print(heading, "tilt toward north")
                        data['current_rotation'] = 0
                        break
                    if 270 > heading and 0 <= heading < 89:
                        motor.run(angle, 30)
                    else:
                        motor.run(angle * -1, 30)
                    angle = angle + 1
            except KeyboardInterrupt:
                print("Programm durch Benutzerunterbrechung beendet.")
                return
        except KeyboardInterrupt:
            print("Programm durch Benutzerunterbrechung beendet.")
            return
        except Exception as e:
            print(f"Fehler aufgetreten: {e}")

    def sun_tracking(self):
        import control_gps
        motor = Rotation_MotorControl(board.D10, board.D24, board.D11)
        self.previous_azimuth = None  # Speichert den vorherigen Azimut
        self.tracking_on = True
        i2c = busio.I2C(board.SCL, board.SDA)
        magnetometer = control_compass.Magnetometer(i2c)
        time.sleep(2)
        actual_rota = 0
        gps = control_gps
        direction_check = None
        try:
            lat, long = gps.get_lat_long_cached()
        except Exception as e:
            lat = 40
            long = 10
            print("error in get_lat_long", e)
        while self.tracking_on:
            if shared_resources.stop_event.is_set():
                break

            azimuth, elevation = control_sun_tracking.set_azimuth_elevation(lat, long)

            print("-------------------")
            print("-------------------")
            print("-azi und ele debug-")
            print("-azi:--", azimuth)
            print("-ele:--", elevation)
            print("-lat:--", lat)
            print("-long:--", long)
            print("-------------------")
            print("-------------------")
            if elevation > 0:

                # Bestimmen der Tilt-Motor Position

                if self.previous_azimuth is None:
                    with self.rotation_lock:
                        print(int(azimuth), "azi in rotation")
                        needed_rotation = azimuth + 90
                        fail_save = 0

                        while True:
                            x, y, z = magnetometer.read_magnetic_field()
                            heading = magnetometer.get_heading(x, y)

                            # time.sleep(0.1)
                            print("Heading: ", heading)
                            print("needed Rotation: ", needed_rotation)
                            # Direkte Differenz
                            direct_diff = needed_rotation - heading

                            # Differenz über die 360-Grad-Grenze hinweg
                            if direct_diff > 0:
                                reverse_diff = direct_diff - 360
                            else:
                                reverse_diff = 360 + direct_diff

                            # Wählen Sie den kürzeren Weg
                            if abs(direct_diff) < abs(reverse_diff):
                                diff = direct_diff
                            else:
                                diff = reverse_diff

                            motor.direction_pin.value = diff > 0 if abs(direct_diff) <= abs(reverse_diff) else diff < 0
                            if diff > 0:
                                direction_check = True
                                self.update_json_entry('rotation_direction', True)
                                self.apply_json_updates()
                            elif diff <= 0:
                                direction_check = False
                                self.update_json_entry('rotation_direction', False)
                                self.apply_json_updates()

                            print("diff value: ", int(diff))
                            print("actual_rota: ", int(actual_rota))
                            actual_rota = actual_rota + int(diff)

                            if (needed_rotation - 4) < heading < (needed_rotation + 4) or fail_save == 10:
                                break
                            if shared_resources.stop_event.is_set():
                                break
                            speed = 0.02 / 70
                            num_steps = int(abs(diff)) * 91  # 171 für 1:51 getriebe
                            print("num steps: ", num_steps)
                            motor.move_motor(num_steps, speed)
                            fail_save = fail_save + 1
                        self.previous_azimuth = azimuth

                if shared_resources.stop_event.is_set():
                    break

                if elevation < 50:
                    tilt_angle = -40  # Winkel für Tilt-Motor wenn Elevation zwischen 0 und 50

                else:
                    tilt_angle = (90 - elevation) * -1  # Anpassen des Tilt-Motors basierend auf der Elevation

                    # Bewegen des Tilt-Motors
                # with self.tilt_lock:
                self.motor_control_tilt.run(int(tilt_angle), 20)
                self.update_json_entry('current_tilt', int(tilt_angle))
                self.update_json_entry('desired_tilt', int(tilt_angle))
                self.apply_json_updates()
                # Angenommene Geschwindigkeit von 20
                if abs(azimuth - self.previous_azimuth) >= 3:
                    print(
                        f"Azimuth um 3° geändert: prev_azi {self.previous_azimuth}, aktueller azi {azimuth}, "
                        f"aktuelles heading: {heading}")
                    motor.direction_pin = True
                    motor.move_motor(3 * 91, speed)
                    self.previous_azimuth = azimuth

            # Kürzere Schlafintervalle mit regelmäßigen Überprüfungen des Stoppereignisses
            for _ in range(10):  # 10 Iterationen * 1 Sekunde Schlaf = 10 Sekunden
                if shared_resources.stop_event.is_set():
                    self.update_json_entry('current_tilt', 0)
                    self.update_json_entry('current_rotation', abs(actual_rota))
                    self.update_json_entry('desired_rotation', abs(actual_rota))
                    self.update_json_entry('rotation_direction', direction_check)
                    self.apply_json_updates()
                    self.reset_on_start()
                    break
                time.sleep(1)

    def reset_on_start(self):
        # continue_reset = 0
        continue_on = 0
        self.update_json_entry('current_tilt', 0)
        self.update_json_entry('current_rotation', 0)
        self.apply_json_updates()
        if self.continuous_rotation_on == 1:
            continue_on = 1
            # continue_reset = 1

        self.stop_continuous_rotation()

        time.sleep(0.5)
        fail_save = 0
        while True:
            tilt_reset_value = int(self.kompass.get_tilt())
            print(tilt_reset_value, "reset_value--------------------")

            tilt_thread = threading.Thread(target=self.motor_control_tilt.run, args=(tilt_reset_value * -1, 20))
            if continue_on == 0:
                rotation_thread = threading.Thread(target=self.motor_control_rotation.run, args=(0, 70))
                rotation_thread.start()
                rotation_thread.join()
            elif continue_on == 1:
                rotation_thread = threading.Thread(target=self.motor_control_rotation.run, args=(0, 70, 1))
                rotation_thread.start()
                rotation_thread.join()

            tilt_thread.start()
            tilt_thread.join()

            fail_save += 1
            print(fail_save)
            if 1 > tilt_reset_value > -1 or fail_save == 5:
                break

        # self.update_json_entry('current_tilt', 0)
        self.update_json_entry('desired_tilt', 0)
        # self.update_json_entry('current_rotation', 0)
        self.update_json_entry('desired_rotation', 0)
        self.apply_json_updates()

    def write_json_data(self, json_data):
        with self.json_file_lock:
            with open(self.json_filename, 'w') as file:
                json.dump(json_data, file, indent=4)

    def update_json_entry(self, key, new_value):
        self.json_updates[key] = new_value

    def apply_json_updates(self):
        # Read the JSON data
        json_data = self.load_settings()

        # Apply the updates
        for key, value in self.json_updates.items():
            json_data[key] = value

        # Write the updated JSON data back to the file
        self.write_json_data(json_data)

    def control_rotation_motor(self, request_data):
        rotation_direction = request_data.get('rotation_direction', False).lower() == 'true'
        angle = int(request_data.get('desired_rotation', 0))
        custom_speed = int(request_data.get('speed_rotation', 20))

        print("Angle_ROTATE:", angle)
        print("Custom Speed_ROTATE:", custom_speed)

        # Stop any ongoing continuous rotation before starting a new command
        if self.continuous_rotation_thread is not None:
            if self.continuous_rotation_thread.is_alive():
                self.stop_continuous_rotation()

        with self.rotation_lock:
            if angle == 360:
                self.continuous_rotation_event.set()
                self.continuous_rotation_thread = threading.Thread(target=self.run_continuous_rotation,
                                                                   args=(rotation_direction, custom_speed))
                self.continuous_rotation_thread.start()
            else:
                self.continuous_rotation_event.clear()
                self.rotation_count = 0
                if rotation_direction:
                    control_rotation_motor_thread = threading.Thread(target=self.motor_control_rotation.run,
                                                                     args=(angle, custom_speed))
                else:
                    control_rotation_motor_thread = threading.Thread(target=self.motor_control_rotation.run,
                                                                     args=(-angle, custom_speed))

                control_rotation_motor_thread.start()
                control_rotation_motor_thread.join()

        # Update the JSON entry
        if angle == 360:
            self.update_json_entry('current_rotation', 0)
        else:
            self.update_json_entry('current_rotation', int(angle))
        self.update_json_entry('speed_rotation', int(custom_speed))

        # Apply the updates to the JSON file
        self.apply_json_updates()

    def run_continuous_rotation(self, rotation_direction, custom_speed):
        while self.continuous_rotation_event.is_set():
            self.continuous_rotation_on = 1
            angle = 360 if rotation_direction else -360
            # Increment the rotation count to keep track of the number of rotations
            self.rotation_count += 1
            effective_angle = self.rotation_count * angle
            self.motor_control_rotation.run(effective_angle, custom_speed)
            # Add a small delay if necessary to prevent overwhelming the motor controller
            self.update_json_entry('current_rotation', 0)
            self.apply_json_updates()

            time.sleep(0.1)

    def stop_continuous_rotation(self):
        self.continuous_rotation_event.clear()
        self.continuous_rotation_on = 0
        self.update_json_entry('current_rotation', 0)
        self.apply_json_updates()
        self.motor_control_rotation.stop_rotation()  # Add this method to stop the motor
        shared_resources.stop_event_rotate.set()

        # Ensure the thread stops
        if self.continuous_rotation_thread is not None:
            self.continuous_rotation_thread.join()
            self.continuous_rotation_thread = None
            # del self.continuous_rotation_thread

    def control_tilt_motor(self, request_data):

        angle = int(request_data.get('desired_tilt', 0))
        custom_speed = int(request_data.get('speed_tilt', 20))

        print("Angle_TILT:", angle)
        print("Custom Speed_TILT:", custom_speed)

        with self.tilt_lock:
            self.tracking_on = True
            control_tilt_motor_thread = threading.Thread(target=self.motor_control_tilt.run, args=(angle, custom_speed))
            control_tilt_motor_thread.start()
            control_tilt_motor_thread.join()
            self.tilt_fail = False

        # Update the JSON entry
        self.update_json_entry('current_tilt', int(angle))
        self.update_json_entry('speed_tilt', int(custom_speed))
        self.apply_json_updates()
        self.tracking_on = False

    def reset_tilt_rotation(self):
        # reset_rotation_thread = threading.Thread(target=self.motor_control_rotation.reset_rotation, args=())
        reset_tilt_thread = threading.Thread(target=self.reset_on_start(), args=())

        # reset_rotation_thread.start()
        reset_tilt_thread.start()

        # reset_rotation_thread.join()
        reset_tilt_thread.join()

        print("Tilt and Rotation motors reset")

    def control_reset(self, request_data):
        json_data = self.load_settings()

        reset = request_data.get('is_reset', False)

        if reset:
            # Set update values
            self.update_json_entry('speed_tilt', 20)
            self.update_json_entry('current_tilt', 0)
            self.update_json_entry('desired_tilt', 0)
            self.update_json_entry('speed_rotation', 20)
            self.update_json_entry('current_rotation', 0)
            self.update_json_entry('desired_rotation', 0)
            self.update_json_entry('is_reset', False)
            self.update_json_entry('is_auto', False)
            self.update_json_entry('time_auto', 0)
            self.update_json_entry('gyro_tilt', 0)
            self.update_json_entry('gyro_rotation', 0)
            self.update_json_entry('demo_enabled', False)
            self.update_json_entry('tilt_on', False)
            self.update_json_entry('rotation_on', False)

            self.apply_json_updates()
            # Reset call
            self.reset_tilt_rotation()
            # self.reset_on_start()

            print("speed_tilt and speed_rotate set to 20")
        else:
            print("Reset is not activated")

    # Load settings from the JSON file
    def load_settings(self):
        try:
            with open(self.json_filename, 'r') as file:
                json_data = json.load(file)
                return json_data
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def time_remaining(self, start_time, auto_time, stop_event):
        while not stop_event.is_set():
            elapsed_time = time.time() - start_time
            remaining_time = max(auto_time - elapsed_time, 0)
            self.update_json_entry('time_auto', int(remaining_time))
            self.apply_json_updates()
            if remaining_time <= 0:
                break
            time.sleep(1)  # Update every 0.5 seconds

    def set_rotation_tilt_on(self):
        self.update_json_entry('rotation_on', True)
        self.update_json_entry('tilt_on', True)
        self.apply_json_updates()

    def control_rotation_tilt(self, rotation_angle, rotation_speed, tilt_angle, tilt_speed, auto_time):
        start_time = time.time()
        self.stop_event.clear()
        data = self.load_settings()
        self.reset_on = False
        print("rotato_on---------------", data.get('rotation_on', True))
        rotation_on = data.get('rotation_on', False)
        tilt_on = data.get('tilt_on', False)
        rotation_thread_positive = None
        rotation_thread = None
        rota_on = 0

        # Speichern der Startpositionen
        start_rotation_angle = rotation_angle
        start_tilt_angle = tilt_angle

        # Start the continuous time remaining thread
        remaining_time_thread = threading.Thread(target=self.time_remaining,
                                                 args=(start_time, auto_time, self.stop_event))
        remaining_time_thread.start()

        print("------DEBUG-------")
        print("------DEBUG-------")
        print("------TILT-------", tilt_on)
        print("------ROTATO-------", rotation_on)
        print("------DEBUG-------")
        print("------DEBUG-------")

        if tilt_angle > 0:
            tilt_angle = tilt_angle * -1

        while time.time() - start_time < auto_time:
            if rotation_on and (rotation_thread_positive is None or not rotation_thread_positive.is_alive()):
                rotation_thread_positive = threading.Thread(target=self.motor_control_rotation.run,
                                                            args=(rotation_angle, rotation_speed))
            if rotation_on and (rotation_thread is None or not rotation_thread.is_alive()):
                rotation_thread = threading.Thread(target=self.motor_control_rotation.run,
                                                   args=(rotation_angle * -1, rotation_speed))

            if rotation_on and not rotation_thread_positive.is_alive() and not rotation_thread.is_alive():
                if rota_on != 1:
                    rotation_thread_positive.start()
                    rota_on = 1
                elif rota_on == 1:
                    rotation_thread.start()
                    rota_on = 0

            if tilt_on == True:
                tilt_thread_positive = threading.Thread(target=self.motor_control_tilt.run,
                                                        args=(tilt_angle, tilt_speed))
            if tilt_on == True:
                tilt_thread_positive.start()

            if tilt_on == True:
                tilt_thread_positive.join()
                self.update_json_entry('current_tilt', tilt_angle)
                self.apply_json_updates()
            if self.stop_event.is_set():
                break
            time.sleep(1)
            if rotation_on and not rotation_thread_positive.is_alive() and not rotation_thread.is_alive():
                if rota_on != 1:
                    rotation_thread_positive.start()
                    rota_on = 1
                elif rota_on == 1:
                    rotation_thread.start()
                    rota_on = 0

            tilt_angle_2 = tilt_angle * -1
            if tilt_on == True:
                tilt_thread = threading.Thread(target=self.motor_control_tilt.run, args=(tilt_angle_2, tilt_speed))
            if tilt_on == True:
                tilt_thread.start()
            if tilt_on == True:
                tilt_thread.join()
                self.update_json_entry('current_tilt', tilt_angle_2)
                self.apply_json_updates()

            if self.stop_event.is_set():
                break

            # Kurze Pause zwischen den Zyklen
            time.sleep(1)

        self.stop_event.set()
        self.motor_control_rotation.stop_rotation()

        # Beide Motoren zurück in die Startposition bringen, aber sicherstellen, dass beide Bewegungen abgeschlossen sind
        if not self.reset_on:
            # rotation_thread_return = threading.Thread(target=self.motor_control_rotation.run,
            #                                           args=(start_rotation_angle, rotation_speed))
            tilt_thread_return = threading.Thread(target=self.motor_control_tilt.run,
                                                  args=(start_tilt_angle, tilt_speed))

            # Starten Sie beide Threads für die Rückkehrbewegung
            # rotation_thread_return.start()
            tilt_thread_return.start()

            # Warten Sie, bis beide Threads ihre Aktion abgeschlossen haben
            # rotation_thread_return.join()
            tilt_thread_return.join()

        # Jetzt, da beide Motoren ihre Rückkehrbewegung abgeschlossen haben, können Sie den Zustand aktualisieren
        self.update_json_entry('current_tilt', start_tilt_angle)
        self.apply_json_updates()

        remaining_time_thread.join()
        self.update_json_entry('time_auto', 0)
        self.apply_json_updates()
        # Optional: Hier können Sie weitere Aufräumarbeiten oder Resets durchführen

    def control_auto(self, request_data):
        json_data = self.load_settings()
        isAkku_data = self.load_settings_lamp()
        # auto_running

        auto_enabled = request_data.get('is_auto', False).lower() == 'true'
        auto_time = int(request_data.get('time_auto', 0))  # Default to 1 minute
        rotation_angle = int(request_data.get('desired_rotation', 5))
        rotation_speed = int(request_data.get('speed_rotation', 20))
        tilt_angle = int(request_data.get('desired_tilt', 0))
        tilt_speed = int(request_data.get('speed_tilt', 20))
        isAkku = isAkku_data.get("isSolarPowered", False)

        def save_auto():
            self.update_json_entry('is_auto', False)
            self.apply_json_updates()
            self.stop_event.set()

        if auto_enabled:
            while self.auto_running:
                if not auto_enabled:
                    self.stop_event.set()
                print("Auto mode is enabled. Running for {} seconds...".format(auto_time))
                self.control_rotation_tilt(rotation_angle, rotation_speed, tilt_angle, tilt_speed, auto_time)
                print("Auto mode completed.")
                save_auto()
                if self.stop_event.is_set():
                    self.auto_running = False
                    break
        else:
            print("Auto mode is not enabled")

    def stop_auto_mode(self):

        # input("Press Enter to stop Auto_Mode\n")

        self.update_json_entry('is_auto', False)
        # self.update_json_entry('rotation_on', True)
        # self.update_json_entry('tilt_on', True)
        self.apply_json_updates()

        self.auto_running = False
        self.stop_event.set()
        time.sleep(0.5)

    def control_motor_movement(self, request_data):
        json_data = self.load_settings()
        tilt_on = request_data.get('tilt_on', False).lower() == 'true'
        rotate_on = request_data.get('rotation_on', False).lower() == 'true'

        if tilt_on and rotate_on:
            with ThreadPoolExecutor(max_workers=2) as executor:
                executor.submit(self.control_rotation_motor, request_data)
                executor.submit(self.control_tilt_motor, request_data)
        elif tilt_on and not rotate_on:
            self.control_tilt_motor(request_data)
        elif not tilt_on and rotate_on:
            self.control_rotation_motor(request_data)
        else:
            print("Kein Motor aktiviert")

    def load_settings_lamp(self):
        try:
            with open(self.json_filename_lamp, 'r') as file:
                json_data_lamp = json.load(file)
                return json_data_lamp
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def update_from_request(self, request_data):
        # Extract relevant data from the POST request and update parameters accordingly
        # print(request_data.get('tilt_on', False))

        desired_rotation = int(request_data.get('desired_rotation', 0))
        speed_rotation = int(request_data.get('speed_rotation', 1))
        is_rotating = request_data.get('rotation_on', False).lower() == 'true'
        rotation_direction = request_data.get('rotation_direction', False).lower() == 'true'
        desired_tilt = int(request_data.get('desired_tilt', 0))
        speed_tilt = int(request_data.get('speed_tilt', 1))
        is_tilting = request_data.get('tilt_on', False).lower() == 'true'
        is_auto = request_data.get('is_auto', False).lower() == 'true'
        auto_time = int(request_data.get('time_auto', 0))
        is_akku = request_data.get('is_akku', False).lower() == 'true'
        is_reset = request_data.get('is_reset', False).lower() == 'true'
        gyro_tilt = int(request_data.get('gyro_tilt', 0))
        gyro_rotate = int(request_data.get('gyro_rotation', 0))
        demo_enabled = request_data.get('demo_enabled', False) == 'true'
        current_rotation = int(request_data.get('current_rotation', 0))
        current_tilt = int(request_data.get('current_tilt', 0))

        self.update_json_entry('desired_rotation', desired_rotation)
        self.update_json_entry('speed_rotation', speed_rotation)
        self.update_json_entry('rotation_on', is_rotating)
        self.update_json_entry('rotation_direction', rotation_direction)
        self.update_json_entry('desired_tilt', desired_tilt)
        self.update_json_entry('speed_tilt', speed_tilt)
        self.update_json_entry('tilt_on', is_tilting)
        self.update_json_entry('is_auto', is_auto)
        self.update_json_entry('time_auto', auto_time)
        self.update_json_entry('is_akku', is_akku)
        self.update_json_entry('is_reset', is_reset)
        self.update_json_entry('gyro_tilt', gyro_tilt)
        self.update_json_entry('gyro_rotation', gyro_rotate)
        self.update_json_entry('demo_enabled', demo_enabled)

        self.apply_json_updates()

        if ((current_tilt != desired_tilt) and is_tilting and self.tilt_fail == False) or (
                desired_tilt == 0 and is_tilting):
            print("TILT CALL !!!!!!!!!!!!!!!!!!!")
            self.tilt_fail = True
            self.update_movement_from_request(request_data)

        elif (current_rotation != desired_rotation) and is_rotating and not is_auto:
            print("ROTATION call !!!!!!!!!!!!!!!")
            self.update_movement_from_request(request_data)

        if is_reset:
            self.stop_auto_mode()
            shared_resources.stop_event_rotate.set()
            shared_resources.stop_event_tilt.set()
            self.reset_on = True
            if self.control_auto_thread is not None:
                if hasattr(self, 'control_auto_thread') and self.control_auto_thread.is_alive():
                    # Warte auf das Beenden des Auto-Modus-Threads
                    self.control_auto_thread.join()

            self.update_reset_from_request(request_data)

        if is_auto:
            self.update_auto_from_request(request_data)
        elif not is_auto:
            self.stop_auto_mode()

    def update_reset_from_request(self, request_data):
        # Directly call the high-level method for reset logic

        reset_thread = threading.Thread(target=self.control_reset, args=(request_data,))
        reset_thread.start()
        # reset_thread.join()

    def update_movement_from_request(self, request_data):

        movement_thread = threading.Thread(target=self.control_motor_movement, args=(request_data,))
        movement_thread.start()
        # movement_thread.join()

    def update_auto_from_request(self, request_data):
        # self.stop_indefinite_rotation() # für 360 endless reset before auto is called
        # self.continuous_rotation_event.clear()
        if self.continuous_rotation_event.is_set():
            angle = request_data.get('current_rotation', 360)
            if angle != 360:
                request_data['current_rotation'] = 360
            print("stop endless!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            self.stop_continuous_rotation()
            self.motor_control_rotation.stop_rotation()

        # self.motor_control_rotation.run(0, 70, 2)
        self.control_auto_thread = threading.Thread(target=self.control_auto, args=(request_data,))
        if self.auto_running:
            self.stop_auto_mode()
            # control_auto_thread.join()
        elif not self.auto_running:
            # self.update_json_entry('current_rotation', 0)
            # self.update_json_entry('current_tilt', 0)
            # self.apply_json_updates()
            self.stop_event.clear()
            self.auto_running = True
            self.control_auto_thread.start()

    def update_from_request_demo(self, request_data):
        # Extract relevant data from the POST request and update parameters accordingly
        # print(request_data.get('tilt_on', False))

        demo_enabled = request_data.get('demo_enabled', False) == 'true'

        self.update_json_entry('demo_enabled', demo_enabled)

        self.apply_json_updates()

    def stop_indefinite_rotation(self):
        with self.rotation_lock:
            if self.continuous_rotation_event.is_set():
                self.stop_continuous_rotation()
                self.motor_control_rotation.stop_rotation()
                self.continuous_rotation_event.clear()
