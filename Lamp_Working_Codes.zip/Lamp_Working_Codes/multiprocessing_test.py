import multiprocessing
import os

def task_1():
    while True:
        print(f"Task 1 running on PID: {os.getpid()}")

def task_2():
    while True:
        print(f"Task 2 running on PID: {os.getpid()}")

if __name__ == "__main__":
    p1 = multiprocessing.Process(target=task_1)
    p2 = multiprocessing.Process(target=task_2)

    p1.start()
    p2.start()

    p1.join()
    p2.join()
