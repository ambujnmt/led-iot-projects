import threading

import neopixel
import time
import board
from led_programmliste import manager


class Indigo_Cure:
    def __init__(self, touchenabled):

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3 * self.NUM_LEDS_BOTTOM)

        self.PIN = board.D12

        # Belegung ESP32 Platine
        '''
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''

        self.touchenabled = touchenabled

        manager.add_programm(self)

        self.paused = False

        # streifen für Rasberry

        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)

        self.INDIGO_WEB = (75, 0, 130, 0)
        self.INDIGO_SPEKTRAL = (111, 0, 255, 0)

        self.DARK = (0, 0, 0, 0)
        self.indigo_cure_running = False
        self.thread_running = None
        self.TRANSITION_COLORS2 = [(8, 0, 15, 0),
                                   (8, 0, 17, 0),
                                   (9, 0, 19, 0),
                                   (9, 0, 20, 0),
                                   (10, 0, 22, 0),
                                   (10, 0, 23, 0),
                                   (11, 0, 25, 0),
                                   (11, 0, 26, 0),
                                   ]

    def np_top_array(self, position, value):

        self.np[position] = value

    def np_mid_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID - 1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM - 1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (self.NUM_LEDS_BOTTOM * 2) - 1] = value

    def dim_and_switch_colors(self, stop_event, change_timing=True):

        # print("Dimm and Switch Colors ausgeführt")
        # Füge eine Variable hinzu, um die Anzahl der Dimmstufen zu erhöhen
        dim_steps = 100

        # Berechne die Zeit pro Schritt
        step_time = (4.32 / 2) / dim_steps

        # Setze den minimalen Helligkeitsfaktor auf 10%
        min_brightness_factor = 0.1
        brightness_range = 1 - min_brightness_factor

        while True:

            # ist pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            if stop_event.is_set():
                self.stop()
                return

            if change_timing == True:
                time.sleep(0.01)

            for i in range(dim_steps):
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                self.set_color_with_brightness(self.INDIGO_WEB, brightness_factor, stop_event)
                if self.indigo_cure_running == False: return
                # time.sleep(step_time)

            self.sleep_with_conditioncheck(stop_event)  # schläft 4.32 sekunden

            # self.sleep_with_touchcheck()
            if stop_event.is_set():
                self.stop()
                return

            for i in range(dim_steps, 0, -1):
                if stop_event.is_set():
                    self.stop()
                    return

                if self.paused == True:
                    time.sleep(0.010)
                    continue
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                # print(brightness_factor)
                # if brightness_factor == 0.109: print("IndigoWEB minimum wert")
                self.set_color_with_brightness(self.INDIGO_WEB, brightness_factor, stop_event)
                # time.sleep(step_time)
            if stop_event.is_set():
                self.stop()
                return

            if change_timing == True:
                time.sleep(0.01)

            for i in self.TRANSITION_COLORS2:

                # self.checktouchinput()
                if self.paused == True:
                    time.sleep(0.010)
                    continue
                # print("Farbwert wird geschrieben: ", i)
                colorvalue = i
                self.np.fill(colorvalue)
                self.np.show()
                if stop_event.is_set():
                    self.stop()
                    return

            if change_timing == True:
                time.sleep(0.01)

            for i in range(dim_steps):

                if self.paused == True:
                    time.sleep(0.010)
                    continue
                if stop_event.is_set():
                    self.stop()
                    return
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                # if brightness_factor == 0.109: print("IndigoSpektral minimum wert")
                self.set_color_with_brightness(self.INDIGO_SPEKTRAL, brightness_factor, stop_event)
                # time.sleep(step_time)
            if stop_event.is_set():
                self.stop()
                return

            self.sleep_with_conditioncheck(stop_event)  # schläft 4.32 sekunden

            if stop_event.is_set():
                self.stop()
                return
            # self.sleep_with_touchcheck()

            for i in range(dim_steps, 0, -1):

                # self.checktouchinput()
                if self.paused == True:
                    time.sleep(0.010)
                    continue
                if stop_event.is_set():
                    self.stop()
                    return
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                self.set_color_with_brightness(self.INDIGO_SPEKTRAL, brightness_factor, stop_event)

            for i in reversed(self.TRANSITION_COLORS2):

                if self.paused == True:
                    time.sleep(0.010)
                    continue

                if change_timing == True:
                    time.sleep(0.01)

                colorvalue = i
                self.np.fill(colorvalue)
                self.np.show()

            if stop_event.is_set():
                self.stop()
                return

    # @micropython.native
    def writeall(self):
        self.np.show()

    # @micropython.native
    def set_color_with_brightness(self, color, brightness_factor, stop_event):

        if stop_event.is_set():
            self.stop()
            return
        r, g, b, w = color
        new_color = (
        int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor), int(w * brightness_factor))

        if stop_event.is_set():
            self.stop()
            return
        self.np.fill(new_color)

        if stop_event.is_set():
            self.stop()
            return

        self.np.show()

    def start(self, stop_event):
        # time.sleep()
        self.indigo_cure_running = True
        print("Inigo Cure, LED Programm wurde in LED Klasse getriggert!")
        self.dim_and_switch_colors(stop_event)
        # self.thread_running = None

    def stop(self):

        self.indigo_cure_running = False

        self.indigo_cure_off()

    def indigo_cure_off(self):

        self.np.fill((0, 0, 0, 0))
        self.np.show()

    def get_Status(self):
        return self.indigo_cure_running

    def sleep_with_conditioncheck(self, stop_event, timeout=4.32):

        start_time = time.time()

        while time.time() - start_time < timeout:
            if stop_event.is_set():
                self.stop()
                return
            time.sleep(0.05)

        return

stop_event = threading.Event()
indigo_cure = Indigo_Cure(False)
indigo_cure.start(stop_event)
