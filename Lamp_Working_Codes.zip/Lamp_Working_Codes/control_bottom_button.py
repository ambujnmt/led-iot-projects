import json
import multiprocessing
import os
import threading
import time
import board
import digitalio
import requests
from urllib.parse import urlencode


class ButtonHandler:
    def __init__(self, manager=None):
        self.stopevent = multiprocessing.Event()
        self.manager = manager
        self.button = digitalio.DigitalInOut(board.D26)
        self.button.direction = digitalio.Direction.INPUT
        self.button.pull = digitalio.Pull.UP
        self.last_press_time = 0
        self.press_start_time = 0
        self.last_button_state = False
        self.is_long_press_active = False
        self.debounce_time = 0.05  # 50 milliseconds debounce period
        self.double_tap_window = 1  # Time window for detecting double taps
        self.long_press_threshold = 3  # Time threshold in seconds for a long press
        self.repeat_interval = 3  # Interval for repeating gesture_4 call
        self.press_lengths = []  # Track lengths of button presses
        self.pause_on = False
        script_dir = os.path.dirname(os.path.realpath(__file__))
        self.json_filename_lamp = os.path.join(script_dir, 'current_lampmodel.json')

    def checkloop(self, stopevent):
        # data = self.get_data()
        # shared = data.get("isteilenactive", False)

        while True:
            if stopevent.is_set():
                print("Stopevent wurde getriggert")
                self.stopevent.clear()
                self.background_thread = None
                return
            # if shared == False:
            self.update_button()

    def startbackgrounddetection(self):
        self.background_thread = threading.Thread(target=self.checkloop, args=(self.stopevent,))
        self.background_thread.start()

    def update_button(self):
        current_time = time.time()
        current_button_state = self.button.value  # True when pressed
        if current_button_state != self.last_button_state:
            if (current_time - self.last_press_time) > self.debounce_time:
                self.last_press_time = current_time
                self.last_button_state = current_button_state
                if current_button_state:
                    self.press_start_time = current_time
                else:
                    if self.is_long_press_active:
                        self.is_long_press_active = False
                    else:
                        press_length = current_time - self.press_start_time
                        self.press_lengths.append(press_length)
                        self.handle_releases()
        elif current_button_state and (current_time - self.press_start_time) > self.long_press_threshold:
            if not self.is_long_press_active:
                self.is_long_press_active = True
                self.gesture_4_start(current_time)
        time.sleep(0.001)

    def handle_releases(self):
        if len(self.press_lengths) == 1:
            start_wait_time = time.time()
            while time.time() - start_wait_time < self.double_tap_window:
                self.update_button()  # Check for a second press
                if len(self.press_lengths) == 2:
                    break
            self.evaluate_presses()

    def evaluate_presses(self):
        num_presses = len(self.press_lengths)
        if num_presses == 1:
            press_length = self.press_lengths[0]
            if press_length <= 1:
                self.gesture_2()
            elif 1 < press_length <= 3:
                self.gesture_1()
        elif num_presses == 2:
            if all(x <= 1 for x in self.press_lengths):
                self.gesture_3()
        self.press_lengths.clear()

    def gesture_1(self):
        print("Gesture 1 detected: One long tap (1-3 seconds)")
        if self.pause_on:
            self.pause_on = False
            self.unpause()
        elif not self.pause_on:
            self.pause_on = True
            self.pause()

    def gesture_2(self):
        print("Gesture 2 detected: One short tap")
        self.nextprogramm()

    def gesture_3(self):
        print("Gesture 3 detected: Two short taps")
        self.previousprogramm()

    def gesture_4_start(self, start_time):
        print("Gesture 4 started: Long hold (longer than 3 seconds)")
        last_called_time = start_time
        while self.button.value:  # While the button is still being pressed
            current_time = time.time()
            if current_time - last_called_time >= self.repeat_interval:
                self.gesture_4()
                last_called_time = current_time
            time.sleep(0.1)  # Check button state at regular intervals during long press

    def gesture_4(self):
        print("Gesture 4 detected: Long hold (continuously while pressed)")
        self.dimming()

    def nextprogramm(self):
        print("Nextprogramm ausgelöst")
        if self.manager == None:
            return
        self.manager.next_program()

    def previousprogramm(self):
        print("vorheriges programm aufgerufen")
        if self.manager == None:
            return
        self.manager.previous_program()

    def pause(self):
        print("Pause wurde getriggert")
        if self.manager == None:
            return
        self.manager.stop_led_Process()
        print("Pause wurde getriggert")

    def unpause(self):
        print("Fortfahren wurde getriggert")
        if self.manager == None:
            return
        currentprogramm = self.manager.getcurrentprogramm()
        data = self.get_data()
        self.manager.start_named_program(currentprogramm, data)

    def get_data(self):
        with open("current_lampmodel.json", "r") as file:
            current_data = json.load(file)
            return current_data

    def dimming(self):
        if self.manager is None:
            print("manager is None")
            return

        current = self.manager.getcurrentprogramm()
        if current != "Benutzerdefiniert":
            print("Benutzerdefiniert nicht aktiv")
            return

        # Indicate the start of dimming process
        print("Start dimming... (Release button to stop)")

        # Wait a bit to see if the button is being held down
        time.sleep(0.5)

        # If button is still pressed, enter the dimming process
        if self.button.value:
            print("Dimming in progress...")
            # self.wait_for_button_release()  # Wait for the button to be released

            # Load the current settings from the JSON file
            try:
                with open(self.json_filename_lamp, 'r') as file:
                    data = json.load(file)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"Error reading the JSON file: {e}")
                data = {}

            # Assuming you only want to update the dim values for the "Benutzerdefiniert" mode
            dim1 = float(data.get('dimmValue1', "0")) - 10
            dim2 = float(data.get('dimmValue2', "0")) - 10
            dim3 = float(data.get('dimmValue3', "0")) - 10

            if dim1 < 0:
                dim1 = dim1 + 100
            if dim2 < 0:
                dim2 = dim2 + 100
            if dim3 < 0:
                dim3 = dim3 + 100

            # Update the dim values here. Modify these as needed.
            data['dimmValue1'] = str(dim1)  # Update to 10%
            data['dimmValue2'] = str(dim2)  # Update to 20%
            data['dimmValue3'] = str(dim3)  # Update to 30%

            # Makes a POST request to trigger the new dimmValues on our own Webserver webserver_microdot.py
            url = 'http://0.0.0.0:80/updatelamp'
            url_encoded_data = urlencode(data, encoding='utf-8')
            # Make the POST request
            response = requests.post(url, data=url_encoded_data)

            # Check the response
            print(response.text)

            # Write the updated data back to the JSON file
            try:
                with open(self.json_filename_lamp, 'w') as file:
                    json.dump(data, file, indent=4)  # Using indent for pretty printing
            except IOError as e:
                print(f"Error writing to the JSON file: {e}")


        else:
            print("Button was quickly released. No dimming.")

# # Example usage of the class
# if __name__ == "__main__":
#     button_pin = board.D26  # Configure the correct pin
#     button_handler = ButtonHandler(button_pin)
#     try:
#         while True:
#             button_handler.update_button()
#             time.sleep(0.01)  # Reduce CPU usage with a small delay
#     except KeyboardInterrupt:
#         print("Program stopped manually")
