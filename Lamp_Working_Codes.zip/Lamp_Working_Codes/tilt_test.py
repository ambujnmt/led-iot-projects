from manual_rotation import *




while True:
    tilt_test()



