from machine import Pin, I2C, UART
import time
  
SENSOR_POWER_PIN_NUMBER = 2 #pim um Sensor mit Strom zu versorgen.
BRAKE_ENABLE = 27 #Pin um Bremse zu aktivieren
PAN_ENABLE = 14 # PAN bedeutet horizontale drehung das ist der PIN dafür
TILT_ENABLE = 25  #Pin um Tilt zu aktivieren
PAN_TILT_CLOCK = 12 #Pin um Schrittgröße des Steppermotors zu konfigurieren
PAN_TILT_CLOCK_CW_CCW = 26 #Pin um drehrichtung des Steppermotors zu bestimmen
BQ25731_I2C_ADDRESS = 0x6B # Adresse des Ladechips
MC6470_ADDESS = 0x4C  ##Gyroskop 
MAGENTIC_SENSOR_ADDRESS = 0x0C ## Adressen die vom MC6470 benötigt werden


def setup_pin(pin_number, pin_state):
    pin = Pin(pin_number, Pin.OUT)
    pin.value(pin_state)
    return pin




#Abschnitt USB Port Stromversorgung # getestet, funktioniert!

USB_ENABLE_PIN = 32
usb_enable = setup_pin(USB_ENABLE_PIN, 1)
usb_enable.value(1) # strom für USB an

time.sleep(1)

usb_enable.value(0) #strom für USB aus

time.sleep(1)

usb_enable.value(1)

#Abschnittende USB Port Stromversorgung


##Abschnitt Test GPS, funktioniert noch nicht, warum , keine ahnung, eigentlich wird das GPS Modul via UART angesprochen
# laut Schaltplan ist aber UART gestrichen, chatgpt sagt wenn UART gestrichen = Problem

GPS_FORCE_ON_PIN = 13 # ich denke um dies stromversogung für das GPS Modul zu starten
gps_force_on = setup_pin(GPS_FORCE_ON_PIN, 1)
gps_force_on.value(1)


#RegisterAdresse (I2) für GPS Modul, keine ahnung wofür die Registeradresse da ist da normalerweise über UART angesprochen
GPS_MODULE_ADDRESS = 0x3C

#funktion um gga satz welcher vom GPS modul erhalten wird zu formatieren
def parse_gga_sentence(sentence):
    data = sentence.split(',')
    if data[0] == '$GPGGA':
        # Daten extrahieren
        time_utc = data[1]
        latitude = data[2]
        longitude = data[4]
        fix_status = data[6]
        
        print('Time (UTC):', time_utc)
        print('Latitude:', latitude)
        print('Longitude:', longitude)
        print('Fix Status:', fix_status)

#Laut Schaltplan ist GPS TXD Pin 16, und RXD Pin 17
uart = UART(1, baudrate=9600, tx=16, rx=17)  # Wählen Sie die richtigen tx/rx Pins für Ihr Board



## Abschnitt GPS Ende


#Abschnitt I2C Verbindung: Ist eine Schnittstelle womit man daten an bestimmte Registeradressen senden und Empfangen kann

# PIN 22 ist für SCL = Serial Clock (Taktimpuls der Leitung)
# PIN 21 ist für SDA = Serial Data (Tatsächliche übertragung der Daten)
i2c = I2C(1, scl=Pin(22), sda=Pin(21), freq=50000)



BRAKE_ENABLE = setup_pin(BRAKE_ENABLE, 0) # aktiviert bzw deaktiviert die Rotationsbremese, wird dann mit BREAK_ENABLE.value(0 oder 1) 0 deaktiviert 1 aktiviert
PAN_ENABLE = setup_pin(PAN_ENABLE, 0) # aktiviert den horizontalen Rotationsmotor PAN_ENABLE.value(1) = stromversorgung (0) = keine Stromversorgung
TILT_ENABLE = setup_pin(TILT_ENABLE, 0) # aktiviert den vertikalen Motor .value(1) strom .value(0) kein strom
PAN_TILT_CLOCK = setup_pin(PAN_TILT_CLOCK, 0) #start/Stop des Motors
PAN_TILT_CLOCK_CW_CCW = setup_pin(PAN_TILT_CLOCK_CW_CCW, 0) #Bestimmt die drehrichtung der Motoren






def write_register(addr, reg, value):
    i2c.writeto_mem(addr, reg, bytearray([value]))

def read_register(addr, regAddress):
    regValue = i2c.readfrom_mem(addr, regAddress, 1)
    print("Value of register {}: 0x{}".format(hex(regAddress), hex(regValue[0])))
    return regValue[0]

def initMC6470():
    SENSOR_POWER = setup_pin(SENSOR_POWER_PIN_NUMBER, 1)
    if not i2c.scan().count(MAGENTIC_SENSOR_ADDRESS):
        print("MC6470 not connected. Please check wiring.")
        while True:
            pass
    write_register(MAGENTIC_SENSOR_ADDRESS, 0x10, 0x01)
    write_register(MAGENTIC_SENSOR_ADDRESS, 0x07, 0x03)
    write_register(MAGENTIC_SENSOR_ADDRESS, 0x08, 0x00)
    write_register(MAGENTIC_SENSOR_ADDRESS, 0x09, 0x00)
    write_register(MAGENTIC_SENSOR_ADDRESS, 0x10, 0x41)
    time.sleep_ms(100)

initMC6470()

def release_brake_test():
    BRAKE_ENABLE.value(0)
    time.sleep(1)
    print(".")
    PAN_ENABLE.value(1)
    #TILT_ENABLE.value(1)
    time.sleep(1)

def brake_test():
    BRAKE_ENABLE.value(1)
    time.sleep(1)
    print(".")
    BRAKE_ENABLE.value(0)
    time.sleep(1)
    
    
    

def tilt_test():
    
    global status
    BRAKE_ENABLE.value(0)
    time.sleep_ms(100)
    PAN_ENABLE.value(0)  # PAN motor off
    TILT_ENABLE.value(1)  # TILT motor on
    PAN_TILT_CLOCK_CW_CCW.value(0)  # Set direction
    
    for x in range (5):
        PAN_TILT_CLOCK.value(1)  # Step pulse start
        time.sleep_ms(1)
        PAN_TILT_CLOCK.value(0)  # Step pulse end
        time.sleep_ms(1)
    status = not status
    
    



def stepper_test():
    global status
    #BRAKE_ENABLE.value(0)
    time.sleep_ms(100)
    PAN_ENABLE.value(1)
    #TILT_ENABLE.value(0)
    #PAN_TILT_CLOCK_CW_CCW.value(0)
    while True:
        PAN_TILT_CLOCK.value(1)
        time.sleep_ms(1)
        PAN_TILT_CLOCK.value(0)
        time.sleep_ms(1)
    status = not status
  
    
'''   
def stepper_test(steps):
    global status
    PAN_ENABLE.value(1)
    for _ in range(steps):
        PAN_TILT_CLOCK.value(1)
        time.sleep_ms(1)
        PAN_TILT_CLOCK.value(0)
        time.sleep_ms(1)
    #status = not status

'''

def test_charger():
    write_register(BQ25731_I2C_ADDRESS, 0x0E, 0x00)
    write_register(BQ25731_I2C_ADDRESS, 0x0F, 0x01)
    while True:
        pass
    
def read_info_from_MC6470():
    read_register(MAGENTIC_SENSOR_ADDRESS, 0xd)
    read_register(MAGENTIC_SENSOR_ADDRESS, 0xe)
    read_register(MAGENTIC_SENSOR_ADDRESS, 0xf)





#while True:
        #data = uart.readline()
        #print(data)
       # parse_gga_sentence(data)



# Deaktiviere die Bremse vor der Hauptschleife
#BRAKE_ENABLE.value(0)

#while True:
    # Entferne release_brake_test() und rufe stattdessen stepper_test() direkt auf
    #stepper_test(100)  # Führt 100 Schritt
    
release_brake_test()
stepper_test()
#tilt_test()
#read_info_from_MC6470()
    
    
    
