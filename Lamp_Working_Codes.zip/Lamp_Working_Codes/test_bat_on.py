import time
import smbus
from ladestrom_tests import BQ25731

class ControlBattery:
    def __init__(self, i2c_bus=1, chip_address=0x6B):
        self.bus = smbus.SMBus(i2c_bus)
        self.chip_address = chip_address
        self.bq_device = BQ25731()
        # Register addresses
        self.ADCVBUS_REGISTER = 0x27
        self.ADCPSYS_REGISTER = 0x26
        self.ADCDAC_REGISTER = 0x29
        self.ADCDACDIS_REGISTER = 0x28
        self.SENSE_RESISTOR = 0.01
        self.ADCDAC_LSB = 64
        self.ADCIN_REGISTER = 0x2B
        self.CHARGE_CURRENT_MSB_REGISTER = 0x03
        self.CHARGE_CURRENT_LSB_REGISTER = 0x02
        self.WATCHDOG_REGISTER = 0x01
        self.CHARGE_OPTION_0_REGISTER = 0x00#
        self.CHARGE_OPTION_1_REGISTER = 0x01

        # Potential status registers to monitor
        self.STATUS_REGISTERS = [0x20, 0x21, 0x22, 0x23]

        # Enable IIN_DPM_AUTO_DISABLE function
        self.enable_iin_dpm_auto_disable()

    def disable_watchdog(self):
        current_value = self.bus.read_byte_data(self.chip_address, self.WATCHDOG_REGISTER)
        new_value = current_value & 0x1F
        self.bus.write_byte_data(self.chip_address, self.WATCHDOG_REGISTER, new_value)

    def enable_psys(self):
        current_value = self.bus.read_byte_data(self.chip_address, 0x31)
        new_value = 31
        self.bus.write_byte_data(self.chip_address, 0x31, new_value)

    def enable_iin_dpm_auto_disable(self):
        charge_option_1 = self.bus.read_byte_data(self.chip_address, self.CHARGE_OPTION_1_REGISTER)
        charge_option_1 |= 0x10
        self.bus.write_byte_data(self.chip_address, self.CHARGE_OPTION_1_REGISTER, charge_option_1)

    def print_register_bits(self, register_address):
        register_value = self.bus.read_byte_data(self.chip_address, register_address)
        for bit in range(7, -1, -1):
            print(f"Bit {bit}: {1 if (register_value & (1 << bit)) else 0}")

    def set_maximum_charge_current(self):
        self.bq_device.set_charge_current(3)

    def read_voltage(self):
        voltage_raw = self.bus.read_word_data(self.chip_address, self.ADCVBUS_REGISTER)
        voltage = voltage_raw * 1.25
        return voltage

    def get_battery_charge_data(self):
        voltage = self.read_voltage()
        psys = self.bus.read_word_data(self.chip_address, self.ADCPSYS_REGISTER)
        input_current = self.bus.read_word_data(self.chip_address, self.ADCIN_REGISTER)
        charge_current = self.bus.read_word_data(self.chip_address, self.ADCDAC_REGISTER)
        return voltage, psys, input_current, charge_current

    def read_current(self, register):
        return self.bus.read_word_data(self.chip_address, register)

    def calculate_current(self, raw_value, lsb):
        return (raw_value * lsb) / self.SENSE_RESISTOR

    def check_battery_presence(self):
        # Read the ChargeOption0 register
        charge_option_0 = self.bus.read_byte_data(self.chip_address, self.CHARGE_OPTION_0_REGISTER)
        print(f"ChargeOption0 Register Value: {charge_option_0:08b}")

        # Read the ChargeOption1 register for debugging
        charge_option_1 = self.bus.read_byte_data(self.chip_address, self.CHARGE_OPTION_1_REGISTER)
        print(f"ChargeOption1 Register Value: {charge_option_1:08b}")

        # Read and print status registers
        for reg in self.STATUS_REGISTERS:
            status_value = self.bus.read_byte_data(self.chip_address, reg)
            print(f"Status Register {reg:#04x} Value: {status_value:08b}")

        # Check if EN_IIN_DPM bit (bit 1) is set to 0, indicating CELL_BATPRESZ pin is LOW (battery removed)
        battery_present = (charge_option_0 & 0x08) == 0
        return battery_present

def main():
    battery_controller = ControlBattery()
    battery_controller.disable_watchdog()
    count = 0
    battery_controller.enable_psys()

    while True:


        voltage, psys, input_current, charge_current = battery_controller.get_battery_charge_data()
        # print(f"Voltage: {voltage} mV")
        print(f"Charge Current: {charge_current} mA")
        print(f"input Current: {input_current} mA")
        count = count + 1
        time.sleep(10)  # Increase sleep time for easier monitoring

if __name__ == "__main__":
    main()
