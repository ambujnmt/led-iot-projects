import board
import digitalio
import time


class bt_button():
    def __init__(self):
        self.button = digitalio.DigitalInOut(board.D26)  # Ersetzen Sie D17 durch den tatsächlichen Pin, an den Ihr Button angeschlossen ist
        self.button.direction = digitalio.Direction.INPUT
        self.button.pull = digitalio.Pull.DOWN  # Aktiviert den internen Pull-Up-Widerstand
        self.buttonwaspressed = False

    def checkbuttoninput(self):
        duration = 3
        start_time = time.time()
        while True:
            current_time = time.time()
            if self.button.value:  # Wenn der Button gedrückt wird, ist der Wert False, wenn der Pull-Up-Widerstand aktiviert ist
                self.buttonwaspressed = True
                print("Button wurde gedrückt")
                time.sleep(0.1)  # Entprellen
            if current_time - start_time >= duration:
                break



    def getwasbuttonpressed(self):
        return self.buttonwaspressed

button = bt_button()
button.checkbuttoninput()


