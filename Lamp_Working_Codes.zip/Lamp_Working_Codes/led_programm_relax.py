#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time



import random
import gc

class Relax:
    def __init__(self, touchenabled):
            
        manager.add_programm(self)
            
        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12
        
        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)
        
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = board.D12 #18        
        
        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23        
        '''
        #'Belegung ESP32 mehr Ram'
        
        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23
        
        #Belegung ESP32 Platine
        
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''


        # Define the colors
        
        self.ORANGE = [(255, 51, 0, 0)]
        
        self.ORANGE_TO_ZERO = [(10, 2, 0, 0), (15, 3, 0, 0),
                               (20, 4, 0, 0), (25, 5, 0, 0),
                               (30, 6, 0, 0), (35, 7, 0, 0),
                               (40, 8, 0, 0), (45, 9, 0, 0),
                               (50, 10, 0, 0), (55, 11, 0, 0),
                               (60, 12, 0, 0), (65, 13, 0, 0),
                               (70, 14, 0, 0), (75, 15, 0, 0),
                               (80, 16, 0, 0), (85, 17, 0, 0),
                               (90, 18, 0, 0), (95, 19, 0, 0),
                               (100, 20, 0, 0), (105, 21, 0, 0),
                               (110, 22, 0, 0), (115, 23, 0, 0),
                               (120, 24, 0, 0), (125, 25, 0, 0),
                               (130, 26, 0, 0), (135, 27, 0, 0),
                               (140, 28, 0, 0), (145, 29, 0, 0),
                               (150, 30, 0, 0), (155, 31, 0, 0),
                               (160, 32, 0, 0), (165, 33, 0, 0),
                               (170, 34, 0, 0), (175, 35, 0, 0),
                               (180, 36, 0, 0), (185, 37, 0, 0),
                               (190, 38, 0, 0), (195, 39, 0, 0),
                               (200, 40, 0, 0), (205, 41, 0, 0),
                               (210, 42, 0, 0), (215, 43, 0, 0),
                               (220, 44, 0, 0), (225, 45, 0, 0),
                               (230, 46, 0, 0), (235, 47, 0, 0),
                               (240, 48, 0, 0), (245, 49, 0, 0),
                               (250, 50, 0, 0), (255, 51, 0, 0),
                               (255, 51, 0, 0), (250, 50, 0, 0),
                               (245, 49, 0, 0), (240, 48, 0, 0),
                               (235, 47, 0, 0), (230, 46, 0, 0),
                               (225, 45, 0, 0), (220, 44, 0, 0),
                               (215, 43, 0, 0), (210, 42, 0, 0),
                               (205, 41, 0, 0), (200, 40, 0, 0),
                               (195, 39, 0, 0), (190, 38, 0, 0),
                               (185, 37, 0, 0), (180, 36, 0, 0),
                               (175, 35, 0, 0), (170, 34, 0, 0),
                               (165, 33, 0, 0), (160, 32, 0, 0),
                               (155, 31, 0, 0), (150, 30, 0, 0),
                               (145, 29, 0, 0), (140, 28, 0, 0),
                               (135, 27, 0, 0), (130, 26, 0, 0),
                               (125, 25, 0, 0), (120, 24, 0, 0),
                               (115, 23, 0, 0), (110, 22, 0, 0),
                               (105, 21, 0, 0), (100, 20, 0, 0),
                               (95, 19, 0, 0), (90, 18, 0, 0),
                               (85, 17, 0, 0), (80, 16, 0, 0),
                               (75, 15, 0, 0), (70, 14, 0, 0),
                               (65, 13, 0, 0), (60, 12, 0, 0),
                               (55, 11, 0, 0), (50, 10, 0, 0),
                               (45, 9, 0, 0), (40, 8, 0, 0),
                               (35, 7, 0, 0), (30, 6, 0, 0),
                               (25, 5, 0, 0), (20, 4, 0, 0),
                               (15, 3, 0, 0), (10, 2, 0, 0)]
    
    

        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.relax_on = False
        
        print("Relax wurde initialisiert")

        self.thread_mid = None

        self.init = True
        
        time.sleep(0.1)

    def np_top_array(self, position, value):
        
         self.np[position] = value
    
    def np_mid_array(self, position, value):
        
        #print("Position mid array: ", position)
   
        
        self.np[position + self.NUM_LEDS_TOP] = value
    
    def bottom1_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value
    
    def bottom2_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value
        
    def bottom3_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value



    def relax_loop(self, stop_event, diming, change_timing = True):

        if diming:
            #self.ORANGE = [(128, 26, 0, 0)]     50% gedimmt
            #self.ORANGE_TO_ZERO = [
               # (5, 1, 0, 0), (8, 2, 0, 0),
               # (10, 2, 0, 0), (13, 3, 0, 0),
               # (15, 3, 0, 0), (18, 4, 0, 0),
               # (20, 4, 0, 0), (23, 5, 0, 0),
               # (25, 5, 0, 0), (28, 6, 0, 0),
               # (30, 6, 0, 0), (33, 7, 0, 0),
               # (35, 7, 0, 0), (38, 8, 0, 0),
               # (40, 8, 0, 0), (43, 9, 0, 0),
               # (45, 9, 0, 0), (48, 10, 0, 0),
               # (50, 10, 0, 0), (53, 11, 0, 0),
               # (55, 11, 0, 0), (58, 12, 0, 0),
               # (60, 12, 0, 0), (63, 13, 0, 0),
               # (65, 13, 0, 0), (68, 14, 0, 0),
               # (70, 14, 0, 0), (73, 15, 0, 0),
               # (75, 15, 0, 0), (78, 16, 0, 0),
               # (80, 16, 0, 0), (83, 17, 0, 0),
               # (85, 17, 0, 0), (88, 18, 0, 0),
               # (90, 18, 0, 0), (93, 19, 0, 0),
               # (95, 19, 0, 0), (98, 20, 0, 0),
               # (100, 20, 0, 0), (103, 21, 0, 0),
               # (105, 21, 0, 0), (108, 22, 0, 0),
               # (110, 22, 0, 0), (113, 23, 0, 0),
               # (115, 23, 0, 0), (118, 24, 0, 0),
               # (120, 24, 0, 0), (123, 25, 0, 0),
               # (125, 25, 0, 0), (128, 26, 0, 0),
               # (128, 26, 0, 0), (125, 25, 0, 0),
               # (123, 25, 0, 0), (120, 24, 0, 0),
               # (118, 24, 0, 0), (115, 23, 0, 0),
               # (113, 23, 0, 0), (110, 22, 0, 0),
               # (108, 22, 0, 0), (105, 21, 0, 0),
               # (103, 21, 0, 0), (100, 20, 0, 0),
               # (98, 20, 0, 0), (95, 19, 0, 0),
               # (93, 19, 0, 0), (90, 18, 0, 0),
               # (88, 18, 0, 0), (85, 17, 0, 0),
               # (83, 17, 0, 0), (80, 16, 0, 0),
               # (78, 16, 0, 0), (75, 15, 0, 0),
               # (73, 15, 0, 0), (70, 14, 0, 0),
               # (68, 14, 0, 0), (65, 13, 0, 0),
               # (63, 13, 0, 0), (60, 12, 0, 0),
               # (58, 12, 0, 0), (55, 11, 0, 0),
               # (53, 11, 0, 0), (50, 10, 0, 0),
               # (48, 10, 0, 0), (45, 9, 0, 0),
                #(43, 9, 0, 0), (40, 8, 0, 0),
                #(38, 8, 0, 0), (35, 7, 0, 0),
                #(33, 7, 0, 0), (30, 6, 0, 0),
                #(28, 6, 0, 0), (25, 5, 0, 0),
                #(23, 5, 0, 0), (20, 4, 0, 0),
                #(18, 4, 0, 0), (15, 3, 0, 0),
                #(13, 3, 0, 0), (10, 2, 0, 0),
                #(8, 2, 0, 0), (5, 1, 0, 0)]


        # auf 25% gedimmt

          self.ORANGE = [(64, 13, 0, 0)]

          self.ORANGE_TO_ZERO = [
            (3, 1, 0, 0), (4, 1, 0, 0),
            (5, 1, 0, 0), (7, 2, 0, 0),
            (8, 2, 0, 0), (9, 2, 0, 0),
            (10, 2, 0, 0), (12, 3, 0, 0),
            (13, 3, 0, 0), (14, 3, 0, 0),
            (15, 3, 0, 0), (17, 4, 0, 0),
            (18, 4, 0, 0), (19, 4, 0, 0),
            (20, 4, 0, 0), (22, 5, 0, 0),
            (23, 5, 0, 0), (24, 5, 0, 0),
            (25, 5, 0, 0), (27, 6, 0, 0),
            (28, 6, 0, 0), (29, 6, 0, 0),
            (30, 6, 0, 0), (32, 7, 0, 0),
            (33, 7, 0, 0), (34, 7, 0, 0),
            (35, 7, 0, 0), (37, 8, 0, 0),
            (38, 8, 0, 0), (39, 8, 0, 0),
            (40, 8, 0, 0), (42, 9, 0, 0),
            (43, 9, 0, 0), (44, 9, 0, 0),
            (45, 9, 0, 0), (47, 10, 0, 0),
            (48, 10, 0, 0), (49, 10, 0, 0),
            (50, 10, 0, 0), (52, 11, 0, 0),
            (53, 11, 0, 0), (54, 11, 0, 0),
            (55, 11, 0, 0), (57, 12, 0, 0),
            (58, 12, 0, 0), (59, 12, 0, 0),
            (60, 12, 0, 0), (62, 13, 0, 0),
            (63, 13, 0, 0), (64, 13, 0, 0),
            (64, 13, 0, 0), (63, 13, 0, 0),
            (62, 13, 0, 0), (60, 12, 0, 0),
            (59, 12, 0, 0), (58, 12, 0, 0),
            (57, 12, 0, 0), (55, 11, 0, 0),
            (54, 11, 0, 0), (53, 11, 0, 0),
            (52, 11, 0, 0), (50, 10, 0, 0),
            (49, 10, 0, 0), (48, 10, 0, 0),
            (47, 10, 0, 0), (45, 9, 0, 0),
            (44, 9, 0, 0), (43, 9, 0, 0),
            (42, 9, 0, 0), (40, 8, 0, 0),
            (39, 8, 0, 0), (38, 8, 0, 0),
            (37, 8, 0, 0), (35, 7, 0, 0),
            (34, 7, 0, 0), (33, 7, 0, 0),
            (32, 7, 0, 0), (30, 6, 0, 0),
            (29, 6, 0, 0), (28, 6, 0, 0),
            (27, 6, 0, 0), (25, 5, 0, 0),
            (24, 5, 0, 0), (23, 5, 0, 0),
            (22, 5, 0, 0), (20, 4, 0, 0),
            (19, 4, 0, 0), (18, 4, 0, 0),
            (17, 4, 0, 0), (15, 3, 0, 0),
            (14, 3, 0, 0), (13, 3, 0, 0),
            (12, 3, 0, 0), (10, 2, 0, 0)]



        gc.enable()
        '''
        self.relax_running = True
        '''
    
   
        r2 = 0  # wird verwendet um den Farbindex der oberen Schleife zu tracken (soll um 1 erhöht werden jedes mal wenn in TOP LED geschrieben wurde)
        r = 0  # wird verwendet um die oberen LEDs langsamer zu triggern als der Mittlere LED Streifen da sonst (zu schnell)
        j = 0  # wird verwendet um die Anzahl der durchläufe der True Schleife zu zählen
        r3 = 0
        r4 = 0
        
        brightness = 100.0
        
        swtich_brightness = 0
        
        '''
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        '''

        while self.relax_on:
            
            #soll relax beendet werden?
            if stop_event.is_set():
                self.stop()
                return
            
            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''
            
            
            ## DAS MUSS DRINNEN BLEIBEN --> PAuzse muss drinnen bleiben
            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue
            
            if change_timing == True:
                time.sleep(0.01)
           
           
            r4 = r4 + 1
            if(r4 == 1):
                
                if brightness <= 10.0:
                    switch_brightness = 1
            
                if brightness == 100.0:
                    switch_brightness = 0
                
                if switch_brightness == 1:
                    brightness += 1.0
                else:
                    brightness -= 1.0
                

                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return
                
                # TOP - LEDS
                self.np_top_array(0, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(1, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(2, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(3, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(4, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(5, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(6, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(7, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(8, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_top_array(9, self.scale_color(self.ORANGE[0], brightness, stop_event))
                
                
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                    
                if change_timing == True:
                    time.sleep(0.01)
                
                # MID - LEDS
                self.np_mid_array(0, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(1, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(2, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(3, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(4, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(5, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(6, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(7, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(8, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                        self.stop()
                        return
                self.np_mid_array(9, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(10, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(11, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(12, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(13, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(14, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(15, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return               
                self.np_mid_array(16, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(17, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(18, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(19, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(20, self.scale_color(self.ORANGE[0], brightness, stop_event))
                
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                
                self.np_mid_array(21, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(22, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(23, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(24, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(25, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(26, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(27, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(28, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(29, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(30, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                self.np_mid_array(31, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(32, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(33, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(34, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(35, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(36, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(37, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(38, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(39, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(40, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(41, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                self.np_mid_array(42, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(43, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(44, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(45, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(46, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(47, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(48, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(49, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(50, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(51, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(52, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(53, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(54, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(55, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(56, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(57, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                self.np_mid_array(58, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(59, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(60, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(61, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(62, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(63, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(64, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(65, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(66, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(67, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(68, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(69, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(70, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(71, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                self.np_mid_array(72, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(73, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(74, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(75, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(76, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(77, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(78, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(79, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(80, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(81, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(82, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(83, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(84, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(85, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return 
                self.np_mid_array(86, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(87, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(88, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(89, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(90, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(91, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(92, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(93, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(94, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(95, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(96, self.scale_color(self.ORANGE[0], brightness, stop_event))
                self.np_mid_array(97, self.scale_color(self.ORANGE[0], brightness, stop_event))
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return                
                
                if change_timing == True:
                    time.sleep(0.01)                
                
                
                # BOTTOM - LEDS   
                self.bottom1_array(0, self.ORANGE[0])
                self.bottom1_array(1, self.ORANGE[0])
                self.bottom1_array(2, self.ORANGE[0])
                self.bottom1_array(3, self.ORANGE[0])
                self.bottom1_array(4, self.ORANGE[0])
                self.bottom1_array(5, self.ORANGE[0])
                self.bottom1_array(6, self.ORANGE[0])
                self.bottom1_array(7, self.ORANGE[0])
                self.bottom1_array(8, self.ORANGE[0])
                self.bottom1_array(9, self.ORANGE[0])
                self.bottom1_array(10, self.ORANGE[0])
                self.bottom1_array(11, self.ORANGE[0])
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return
                self.bottom2_array(0, self.ORANGE[0])
                self.bottom2_array(1, self.ORANGE[0])
                self.bottom2_array(2, self.ORANGE[0])
                self.bottom2_array(3, self.ORANGE[0])
                self.bottom2_array(4, self.ORANGE[0])
                self.bottom2_array(5, self.ORANGE[0])
                self.bottom2_array(6, self.ORANGE[0])
                self.bottom2_array(7, self.ORANGE[0])
                self.bottom2_array(8, self.ORANGE[0])
                self.bottom2_array(9, self.ORANGE[0])
                self.bottom2_array(10, self.ORANGE[0])
                self.bottom2_array(11, self.ORANGE[0])
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return                
                self.bottom3_array(0, self.ORANGE[0])
                self.bottom3_array(1, self.ORANGE[0])
                self.bottom3_array(2, self.ORANGE[0])
                self.bottom3_array(3, self.ORANGE[0])
                self.bottom3_array(4, self.ORANGE[0])
                self.bottom3_array(5, self.ORANGE[0])
                self.bottom3_array(6, self.ORANGE[0])
                self.bottom3_array(7, self.ORANGE[0])
                self.bottom3_array(8, self.ORANGE[0])
                self.bottom3_array(9, self.ORANGE[0])
                self.bottom3_array(10, self.ORANGE[0])
                self.bottom3_array(11, self.ORANGE[0])
                #soll relax beendet werden?
                if stop_event.is_set():
                    self.stop()
                    return
                
                r4 = 0
                
            #self.checktouchinput()
            '''
            if self.relax_running == False:
                break
            '''
            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()
            
            #print("Relax Leuchtprigramm hat funltionier :)")


    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    def scale_color(self, color_tupel, brightness, stop_event):
        
        #soll relax beendet werden?
        if stop_event.is_set():
            self.stop()
            return       
        
        floatbrightness = float(brightness)
        
        r, g, b, w = color_tupel
        
        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)
        
        floatbrightness = floatbrightness / 100.0
        
        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)
        
        return (r, g, b, w)

    def start(self, stop_event, diming):
        print("start Relax innerhalb Relax Klasse getrigget!")
        self.relax_on = True
        self.relax_loop(stop_event, diming)    
        '''    
        # time.sleep()
        self.relax_running = True
        self.thread_running = None

        try:
            self.thread_running = _thread.start_new_thread(self.relax_on, ())

        except:

            time.sleep_ms(70)
            self.start()

         
        return True
        '''

    def stop(self):
        print("Wurde gestoppt")
        self.relax_on = False
        self.relax_off()
        self.np.deinit()    
        '''
        self.relax_running = False

        # self.thread_mid.exit()

        if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            self.thread_running.exit()

        self.relax_off()
        '''

    def relax_off(self):

        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.relax_on
        
        


#relax = Relax(False)
#stop_event = multiprocessing.Event()
#diming = True
#relax.start(stop_event, diming)

