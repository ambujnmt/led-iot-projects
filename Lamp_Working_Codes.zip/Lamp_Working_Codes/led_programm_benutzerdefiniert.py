# import machine
import board
import neopixel
import time
# import uasyncio
# import _thread
import multiprocessing
import random
import gc
# from micropython import const
from led_programmliste import manager


# from machine import TouchPad


class Benutzerdefiniert:
    def __init__(self, touchenabled):
        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        manager.add_programm(self)

        # Belegung Raspi

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3 * self.NUM_LEDS_BOTTOM)
        self.PIN = board.D12  # 18

        # neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)

        # Erstelle das Neopixel-Objekt
        # alte belegung

        '''
        self.np_top = neopixel.NeoPixel(machine.Pin(self.PIN), self.NUM_LEDS_TOP, bpp=4)
        self.np_mid = neopixel.NeoPixel(machine.Pin(self.PIN_MID), self.NUM_LEDS_MID, bpp=4)  # Use bpp=4 to indicate RGBW LEDs
        self.np_bottom_first = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_FIRST), self.NUM_LEDS_BOTTOM, bpp=4)
        self.np_bottom_second = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_SECOND), self.NUM_LEDS_BOTTOM, bpp=4)
        self.np_bottom_third = neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_THIRD), self.NUM_LEDS_BOTTOM, bpp=4)
        '''

        # Define the colors
        self.RED = (255, 0, 0, 0)
        self.ORANGE_RED = (255, 128, 0, 0)
        self.YELLOW1 = (255, 255, 0, 0)
        self.LIGHTGREEN = (128, 255, 0, 0)
        self.GREEN = (0, 255, 0, 0)
        self.ORANGE = (255, 63, 0, 0)
        self.YELLOW = (255, 255, 0, 0)
        self.BLUE = (0, 0, 255, 0)
        self.PURPLE = (148, 0, 211, 0)
        self.PINK = (255, 20, 147, 0)
        self.DARKPURPLE = (148, 0, 211, 0)
        self.TUERKIS = (64, 224, 208, 0)
        self.WHITE = (0, 0, 0, 0)
        self.DARK_BLUE = (0, 0, 132, 81)
        self.LIGHT_BLUE = (0, 0, 0, 0)

        self.ONLY_BLUE = [(0, 0, 255, 0), (0, 0, 240, 0), (0, 0, 225, 0), (0, 0, 210, 0), (0, 0, 195, 0),
                          (0, 0, 180, 0), (0, 0, 165, 0), (0, 0, 150, 0), (0, 0, 135, 0), (0, 0, 120, 0),
                          (0, 0, 105, 0), (0, 0, 90, 0), (0, 0, 75, 0), (0, 0, 60, 0), (0, 0, 45, 0), (0, 0, 30, 0),
                          (0, 0, 15, 0), (0, 0, 0, 0), (0, 0, 0, 0), (0, 0, 0, 0)]

        self.DARK = (0, 0, 0, 0)
        self.benutzerdefiniert_running = False
        self.thread_running = None

        self.Color_Top = (0, 0, 0, 0)
        self.Color_Mid = (0, 0, 0, 0)
        self.Color_Bot = (0, 0, 0, 0)

        # mit touch initialisieren?
        self.touchenabled = touchenabled

        # manager mit led programm füttern, muss gemacht werden um zirkuläre importe zu vermeiden

        self.paused = False

    def np_top_array(self, position, value):

        self.np[position] = value

    def np_mid_array(self, position, value):

        # print("Position mid array: ", position)

        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID - 1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM - 1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (self.NUM_LEDS_BOTTOM * 2) - 1] = value

    def np_top_array_fill(self, value):
        # print("Debugging Benutzerdefiniert np top fill: ", value)
        for i in range(self.NUM_LEDS_TOP):
            self.np[i] = value

    def np_mid_array_fill(self, value):
        for i in range(self.NUM_LEDS_TOP, self.NUM_LEDS_TOP + self.NUM_LEDS_MID):
            self.np[i] = value

    def bottom1_array_fill(self, value):
        for i in range(self.NUM_LEDS_TOP + self.NUM_LEDS_MID,
                       self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM):
            self.np[i] = value

    def bottom2_array_fill(self, value):
        for i in range(self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM,
                       self.NUM_LEDS_TOP + self.NUM_LEDS_MID + 2 * self.NUM_LEDS_BOTTOM):
            self.np[i] = value

    def bottom3_array_fill(self, value):
        for i in range(self.NUM_LEDS_TOP + self.NUM_LEDS_MID + 2 * self.NUM_LEDS_BOTTOM,
                       self.NUM_LEDS_TOP + self.NUM_LEDS_MID + 3 * self.NUM_LEDS_BOTTOM):
            self.np[i] = value

    def scale_color(self, color_tupel, brightness):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        # w = int(w * brightness)

        return (r, g, b, w)

        # Funktioniert, aber falsche Farbwert

    def hex_to_rgbw(self, hex_color):

        print('hextoRGB Value ist vor bearbeitung: ', hex_color)

        # Entfernen Sie "Color(" und die schließende Klammer ")"
        stripped_string = hex_color[6:-1]

        # Überprüfen Sie, ob der resultierende String 8 Zeichen lang ist
        if len(stripped_string) == 10:
            # Entfernen Sie die ersten zwei Zeichen (Alpha-Kanal)
            final_string = stripped_string[4:]
        elif len(stripped_string) == 8:
            final_string = stripped_string[2:]

        else:
            final_string = stripped_string

        print('String nach der bearbeitung: ', final_string)

        r, g, b = tuple(int(final_string[i:i + 2], 16) for i in (0, 2, 4))

        print(r, g, b)

        # return self.rgbw_color(r,g,b)

        # return (r,g,b,w)

        w = 0
        # r = r - w
        # g = g - w
        # b = b - w

        return (r, g, b, w)

    def update_Color(self, color1, color2, color3, brightness1, brightness2, brightness3):

        color1 = self.hex_to_rgbw(color1)
        color1 = self.scale_color(color1, brightness1)

        if color1 != self.Color_Top:
            self.Color_Top = color1

        color2 = self.hex_to_rgbw(color2)
        color2 = self.Color_Mid = self.scale_color(color2, brightness2)

        if color2 != self.Color_Mid:
            self.Color_Mid = color2

        color3 = self.hex_to_rgbw(color3)
        color3 = self.scale_color(color3, brightness3)

        if color3 != self.Color_Bot:
            self.Color_Bot = color3

    def rgbw_color(self, Ri, Gi, Bi):
        # Get the maximum between R, G, and B
        tM = max(Ri, max(Gi, Bi))

        # If the maximum value is 0, immediately return pure black.
        if tM == 0:
            return (0, 0, 0, 0)

        # This section serves to figure out what the color with 100% hue is
        multiplier = 255.0 / tM
        hR = Ri * multiplier
        hG = Gi * multiplier
        hB = Bi * multiplier

        # This calculates the Whiteness (not strictly speaking Luminance) of the color
        M = max(hR, max(hG, hB))
        m = min(hR, min(hG, hB))
        Luminance = ((M + m) / 2.0 - 127.5) * (255.0 / 127.5) / multiplier

        # Calculate the output values
        Wo = int(Luminance)
        Bo = int(Bi - Luminance)
        Ro = int(Ri - Luminance)
        Go = int(Gi - Luminance)

        # Trim them so that they are all between 0 and 255
        Wo = max(min(Wo, 255), 0)
        Bo = max(min(Bo, 255), 0)
        Ro = max(min(Ro, 255), 0)
        Go = max(min(Go, 255), 0)

        return (Ro, Go, Bo, Wo)

    ###########################################################################################

    def benutzerdefiniert_on(self, stop_event, color1, color2, color3, brightness1, brightness2, brightness3):

        gc.enable()

        print(color1)
        print(color2)
        print(color3)

        self.Color_Top = self.hex_to_rgbw(color1)
        self.Color_Mid = self.hex_to_rgbw(color2)
        self.Color_Bot = self.hex_to_rgbw(color3)

        ###Dimmung berücksichtigen:

        self.Color_Top = self.scale_color(self.Color_Top, brightness1)
        self.Color_Mid = self.scale_color(self.Color_Mid, brightness2)
        self.Color_Bot = self.scale_color(self.Color_Bot, brightness3)
        '''
        
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
            
        '''

        while self.benutzerdefiniert_running:

            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            if stop_event.is_set():
                self.stop()
                return

            self.np_top_array_fill(self.Color_Top)
            self.np_mid_array_fill(self.Color_Mid)
            # Iterate through each LED
            if stop_event.is_set():
                self.stop()
                return

            self.bottom1_array_fill(self.Color_Bot)
            self.bottom2_array_fill(self.Color_Bot)
            self.bottom3_array_fill(self.Color_Bot)
            if stop_event.is_set():
                self.stop()
                return

            self.np.write()

            if stop_event.is_set():
                self.stop()
                return

            # print("Benutzerdefiniert get_Status innerhalb der Klasse: ", self.get_Status())

    def start(self, stop_event, color1, color2, color3, brightness1, brightness2, brightness3):
        # time.sleep()

        self.benutzerdefiniert_running = True

        self.benutzerdefiniert_on(stop_event, color1, color2, color3, brightness1, brightness2, brightness3)

        return True

    def stop(self):

        self.benutzerdefiniert_running = False
        self.benutzerdefiniert_off()

    def benutzerdefiniert_off(self):

        self.np.fill((0, 0, 0, 0))

        self.np.show()

    def get_Status(self):
        return self.benutzerdefiniert_running

    # ________________Tochinputfunktion__________________________________

    def pause(self):
        self.paused = True
        self.benutzerdefiniert_off()
        print("Pause wurde auf true gesetzt", self.paused)

    def unpause(self):
        self.paused = False
        print("Pause wurde auf False gesetzt", self.paused)
