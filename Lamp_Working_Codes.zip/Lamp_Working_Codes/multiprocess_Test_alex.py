import multiprocessing
import schedule



def funktion1():
    while True:
        print("Running 1")

def funktion2():
    while True:
        print("Running 2")


schedule.every().day.at("18:52").do(funktion1, )
schedule.every().day.at("18:53").do(funktion2,)

while True:
    print(schedule.get_jobs())
    schedule.run_pending()

