import subprocess

def run_command(command):
    subprocess.run(command, shell=True, check=True)



run_command("sudo pip3 install bluezero")



