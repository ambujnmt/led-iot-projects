import time
import math
import board
import busio
from adafruit_bus_device.i2c_device import I2CDevice




class MagneticSensor:
    I2C_ADDR = 0x0C
    MAGNETIC_SENSOR_POWER_MODE_REGISTER = 0x1B
    MAGNETIC_POWER_MODE_VALUE = 0x01
    MAGNETIC_SENSOR_X_LSB = 0x10
    MAGNETIC_SENSOR_X_MSB = 0x11
    MAGNETIC_SENSOR_Y_LSB = 0x12
    MAGNETIC_SENSOR_Y_MSB = 0x13
    MAGNETIC_SENSOR_Z_LSB = 0x14
    MAGNETIC_SENSOR_Z_MSB = 0x15


class Magnetometer:
    ACCL_DATA_REG_ADDR = 0x10
    SR_REG_ADDR = 0x1D
    MODE_REG_ADDR = 0x1B
    RANGE_REG_ADDR = 0x1E
    SENSITIVITY = 0.05
    I2C_ADDR = 0x0C
    RANGE = 0x10  # E_M_DRV_MC6700_RANGE_15BIT

    def __init__(self, i2c: busio.I2C):
        self.i2c_device = I2CDevice(i2c, self.I2C_ADDR)
        self.init_sensor()

    def init_sensor(self):
        self.set_SR()
        self.set_dynamic_range()
        self.set_cont_mode()

    def write_to_device(self, register: int, data: bytearray):
        with self.i2c_device as i2c:
            i2c.write(bytes([register] + list(data)))

    def read_from_device(self, register: int, num_bytes: int):
        data = bytearray(num_bytes)
        with self.i2c_device as i2c:
            i2c.write_then_readinto(bytearray([register]), data)
        return data

    def set_SR(self):
        self.write_to_device(self.SR_REG_ADDR, bytearray([0x80]))
        self.write_to_device(self.SR_REG_ADDR, bytearray([0x80]))

    def set_cont_mode(self):
        self.write_to_device(self.MODE_REG_ADDR, bytearray([0x80 | 0x18]))
        self.write_to_device(self.MODE_REG_ADDR, bytearray([0x80 | 0x18]))

    def set_dynamic_range(self):
        self.write_to_device(self.RANGE_REG_ADDR, bytearray([0x80 | self.RANGE]))
        self.write_to_device(self.RANGE_REG_ADDR, bytearray([0x80 | self.RANGE]))

    def read_magnetic_field(self):
        data = self.read_from_device(self.ACCL_DATA_REG_ADDR, 6)
        x = ((data[1] << 8) | data[0])
        y = (data[3] << 8) | data[2]
        z = (data[5] << 8) | data[4]

        x = x if x < 32768 else x - 65536
        y = y if y < 32768 else y - 65536
        z = z if z < 32768 else z - 65536

        return [x * self.SENSITIVITY, y * self.SENSITIVITY, z * self.SENSITIVITY]

    def get_heading(self, x, y):
        angle = math.atan2(y, x)
        heading = math.degrees(angle)

        if heading < 0:
            heading += 360

        return heading

    # def get_north(self, stop_event):
    #     i2c = busio.I2C(board.SCL, board.SDA)
    #     magnetometer = Magnetometer(i2c)
    #     interpreter = MotorInterpreter()
    #     motor = Rotation_MotorControl(board.D10, board.D24, board.D11)
    #     angle = 0
    #     try:
    #         try:
    #             while True:
    #                 x, y, z = magnetometer.read_magnetic_field()
    #                 heading = magnetometer.get_heading(x, y)
    #
    #                 print(f"Magnetische Feldstärken: X={x}, Y={y}, Z={z}")
    #                 print(f"Himmelsrichtung: {heading} Grad")
    #                 if stop_event.is_set():
    #                     break
    #
    #                 if 89 <= heading < 91:
    #                     print(heading, "tilt toward north")
    #                     interpreter.update_json_entry('current_rotation', 0)
    #                     interpreter.apply_json_updates()
    #                     break
    #
    #                 motor.run(angle, 50)
    #                 angle = angle + 1
    #         except KeyboardInterrupt:
    #             print("Programm durch Benutzerunterbrechung beendet.")
    #             return
    #     except KeyboardInterrupt:
    #         print("Programm durch Benutzerunterbrechung beendet.")
    #         return
    #     except Exception as e:
    #         print(f"Fehler aufgetreten: {e}")
#
#
# # Hauptprogramm
# def set_north():
#     i2c = busio.I2C(board.SCL, board.SDA)
#     magnetometer = Magnetometer(i2c)
#
#     try:
#         magnetometer.get_north()
#     except KeyboardInterrupt:
#         print("Programm durch Benutzerunterbrechung beendet.")
#         return
#     except Exception as e:
#         print(f"Fehler aufgetreten: {e}")


def set_heading():
    i2c = busio.I2C(board.SCL, board.SDA)
    magnetometer = Magnetometer(i2c)

    try:
        time.sleep(0.02)
        x, y, z = magnetometer.read_magnetic_field()
        time.sleep(0.02)
        heading = magnetometer.get_heading(x, y)
        return heading
    except KeyboardInterrupt:
        return
    except Exception as e:
        print(f"Fehler aufgetreten: {e}")

