import json
import threading
import time

import Kompass_Accelerometer
from tilt_motor_control import Tilt_MotorControl
from rotation_motor_control import Rotation_MotorControl
import board
from control_motor_interpreter import MotorInterpreter


class Motormovement_Demo:

    def __init__(self):

        self.isrunning = False
        # Create a MotorControl instance
        self.motor_control_tilt = Tilt_MotorControl(board.D13, board.D7, board.D6)
        self.motor_control_rotation = Rotation_MotorControl(board.D10, board.D24, board.D11)  # Assign correct pins here
        self.i2c_bus = board.I2C()
        self.kompass = Kompass_Accelerometer.Kompass(self.i2c_bus)

    def test_reset(self):
        fail_save = 0
        while True:
            tilt_reset_value = int(self.kompass.get_tilt())
            print(tilt_reset_value, "reset_value--------------------")

            self.motor_control_tilt.run(tilt_reset_value * -1, 20)

            fail_save += 1
            print(fail_save)
            if 1 > tilt_reset_value > -1 or fail_save == 5:
                break

    def stop_demo(self):
        self.isrunning = False
        self.test_reset()
        return

    def rotate_thread(self, angle, speed):
        print(f"Rotating {angle} degrees")
        self.motor_control_rotation.run(angle, speed)
        print(f"END Rotation - {angle} degrees")

    def tilt_thread(self, angle, speed):
        print(f"Tilting {angle} degrees")
        self.motor_control_tilt.run(angle, speed)
        print(f"END Tilt - {angle} degrees")

    def start_demo(self, stop_event):
        self.isrunning = True
        default_speed = 30
        with open('current_motor_status.json', 'r') as file:
            data = json.load(file)  # This directly converts JSON content into a Python dictionary
        check_auto = data.get('is_auto')
        # Check if 'is_auto' is False in the JSON data

        if check_auto == False:
            while self.isrunning:
                # Reset before Start
                # self.test_reset()
                MotorInterpreter().reset_on_start()
                time.sleep(1)

                # Step 1: 180° counterclockwise rotation and back to 0°
                self.rotate_thread(-90, 60)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
                self.rotate_thread(-180, 60)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break

                self.rotate_thread(-90, 60)
                print("END Demo Step 1")
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
                self.rotate_thread(0, 60)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break

                time.sleep(1)
                # Step 2: Tilt 20° forward and then back to -20°
                self.tilt_thread(20, 15)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
                self.tilt_thread(-40, 15)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
                self.test_reset()
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break

                print("END Demo Step 2")
                time.sleep(1)
                # Step 3: Simultaneous rotation and tilt
                rotation_thread = threading.Thread(target=self.rotate_thread,
                                                   args=(180, 38))  # change speed for timing of
                tilt_thread = threading.Thread(target=self.tilt_thread, args=(20, 2))  # rotate and tilt

                rotation_thread.start()
                tilt_thread.start()

                rotation_thread.join()
                tilt_thread.join()

                time.sleep(1)
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break

                rotation_thread = threading.Thread(target=self.rotate_thread,
                                                   args=(0, 38))  # change speed for timing of
                tilt_thread = threading.Thread(target=self.tilt_thread, args=(-40, 4))  # rotate and tilt

                rotation_thread.start()
                tilt_thread.start()

                rotation_thread.join()
                tilt_thread.join()

                time.sleep(1)
                print("END Demo Step 3")
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break

                # Step 4: Reset tilt to 0°
                self.test_reset()
                print("END Demo Step 4")
                # Step 5: Pause for 33 seconds

                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
                print("Pause for 33 seconds...")
                time.sleep(33)
                print("END Demo Step 5")
                if stop_event.is_set():
                    self.stop_demo()
                    print("Stop event received for motor")
                    break
        else:
            print("Auto-Modus aktiviert")
            self.stop_demo()
