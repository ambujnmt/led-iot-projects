# import machine
# import _thread
import board
import neopixel
import time
import multiprocessing
# import network
# from machine import TouchPad
from led_programmliste import manager
import time

import random
import gc


class Earth:
    def __init__(self, touchenabled):

        manager.add_programm(self)


        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3 * self.NUM_LEDS_BOTTOM)

        # 'Belegung ESP32 mehr Ram'

        self.PIN = board.D12  # 18

        # neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)

        # Define the colors
        self.WHITE = [(230, 230, 230, 0)]

        self.LIGHT_BLUE = [(0, 0, 240, 0)]
        self.DARK_BLUE = [(0, 0, 60, 0)]

        self.GREEN = [(0, 100, 0, 0)]
        self.TURQUOISE = [(0, 230, 230, 0)]

        self.earth_running = False
        self.thread_running = None

        brightness_bottom1 = 0.0
        is_brightness_bottom1 = True

        brightness_bottom2 = 100
        is_brightness_bottom2 = True

        # mit touch initialisieren?
        self.touchenabled = touchenabled

        self.earth_on = False

        print("Earth wurde initialisiert")

        self.paused = False

        self.init = True

    def np_top_array(self, position, value):

        self.np[position] = value

    def np_mid_array(self, position, value):

        # print("Position mid array: ", position)

        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID - 1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM - 1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (self.NUM_LEDS_BOTTOM * 2) - 1] = value

    def earth_loop(self, stop_event, diming, change_timing=True):
        
        if diming:
            #self.WHITE = [(115, 115, 115, 0)] 50% gedimmt
            #self.LIGHT_BLUE = [(0, 0, 120, 0)]
            #self. DARK_BLUE = [(0, 0, 30, 0)]
            #self.GREEN = [(0, 50, 0, 0)]
            #self.TURQUOISE = [(0, 115, 115, 0)]

        # auf 25% gedimmt
            self.WHITE = [(58, 58, 58, 0)]
            self.LIGHT_BLUE = [(0, 0, 60, 0)]
            self.DARK_BLUE = [(0, 0, 15, 0)]
            self.GREEN = [(0, 25, 0, 0)]
            self.TURQUOISE = [(0, 58, 58, 0)]

        gc.enable()

        r4 = 0
        r_mid = 0

        brightness_bottom1 = 0.0
        is_brightness_bottom1 = True

        brightness_bottom2 = 100.0
        is_brightness_bottom2 = False

        current_led = 0

        stop_second = False
        seconds = 0

        index0 = 0
        index1 = 1
        index2 = 2
        index3 = 3
        index4 = 4
        index5 = 5
        index6 = 6
        index7 = 7
        index8 = 8
        index9 = 9
        index10 = 10
        index11 = 11
        index12 = 12
        index13 = 13
        index14 = 14
        index15 = 15
        index16 = 16
        index17 = 17
        index18 = 18
        index19 = 19
        index20 = 20
        index21 = 21
        index22 = 22
        index23 = 23
        index24 = 24
        index25 = 25
        index26 = 26
        index27 = 27
        index28 = 28
        index29 = 29
        index30 = 30
        index31 = 31
        index32 = 32
        index33 = 33
        index34 = 34
        index35 = 35
        index36 = 36
        index37 = 37
        index38 = 38
        index39 = 39
        index40 = 40
        index41 = 41
        index42 = 42
        index43 = 43
        index44 = 44
        index45 = 45
        index46 = 46
        index47 = 47
        index48 = 48
        index49 = 49
        index50 = 50
        index51 = 51
        index52 = 52
        index53 = 53
        index54 = 54
        index55 = 55
        index56 = 56
        index57 = 57
        index58 = 58
        index59 = 59
        index60 = 60
        index61 = 61
        index62 = 62
        index63 = 63
        index64 = 64
        index65 = 65
        index66 = 66
        index67 = 67
        index68 = 68
        index69 = 69
        index70 = 70
        index71 = 71
        index72 = 72
        index73 = 73
        index74 = 74
        index75 = 75
        index76 = 76
        index77 = 77
        index78 = 78
        index79 = 79
        index80 = 80
        index81 = 81
        index82 = 82
        index83 = 83
        index84 = 84
        index85 = 85
        index86 = 86
        index87 = 87
        index88 = 88
        index89 = 89
        index90 = 90
        index91 = 91
        index92 = 92
        index93 = 93
        index94 = 94
        index95 = 95
        index96 = 96
        index97 = 97
        index98 = 98

        bottom_time_speed = 0
        bottom_color_step = 1
        color_number = 0

        while self.earth_on:
            # self.np_mid.fill((0, 0, 0, 0))  # Clear all LEDs

            if self.earth_on == False:
                return

            # soll relax beendet werden?
            if stop_event.is_set():
                self.stop()
                return

            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            r4 = r4 + 1
            bottom_time_speed += 1
            if (r4 == 1):

                # ______________________________________TOP START_______________________________________________

                if stop_second == True:
                    seconds += 1
                    if seconds == 100:
                        stop_second = False

                else:

                    if is_brightness_bottom1 == True:
                        brightness_bottom1 += 1.0
                        if brightness_bottom1 >= 100.0:
                            is_brightness_bottom1 = False

                    else:
                        brightness_bottom1 -= 1.0
                        if brightness_bottom1 <= 0.0:
                            is_brightness_bottom1 = True

                    if is_brightness_bottom2 == True:
                        brightness_bottom2 += 1.0
                        if brightness_bottom2 >= 100.0:
                            is_brightness_bottom2 = False

                    else:
                        brightness_bottom2 -= 1.0
                        if brightness_bottom2 <= 0.0:
                            is_brightness_bottom2 = True

                    if brightness_bottom1 >= 100.0:
                        stop_second = True
                        seconds = 0

                    if brightness_bottom1 <= 0.0:
                        stop_second = True
                        seconds = 0

                self.np_top_array(0, self.scale_color(self.WHITE[0], brightness_bottom2))
                self.np_top_array(1, self.scale_color(self.WHITE[0], brightness_bottom1))
                self.np_top_array(2, self.scale_color(self.WHITE[0], brightness_bottom2))
                self.np_top_array(3, self.scale_color(self.WHITE[0], brightness_bottom1))
                self.np_top_array(4, self.scale_color(self.WHITE[0], brightness_bottom2))
                self.np_top_array(5, self.scale_color(self.WHITE[0], brightness_bottom1))
                self.np_top_array(6, self.scale_color(self.WHITE[0], brightness_bottom2))
                self.np_top_array(7, self.scale_color(self.WHITE[0], brightness_bottom1))
                self.np_top_array(8, self.scale_color(self.WHITE[0], brightness_bottom2))
                self.np_top_array(9, self.scale_color(self.WHITE[0], brightness_bottom1))
                # _____________________________________TOP ENDE________________________________________________

                # _____________________________________MID START_______________________________________________

                r_mid += 1
                if r_mid == 50:
                    self.np_mid_array(index0, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 6))
                    index0 = (index0 + 1) % 98

                    self.np_mid_array(index1, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 7))
                    index1 = (index1 + 1) % 98

                    self.np_mid_array(index2, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 8))
                    index2 = (index2 + 1) % 98

                    self.np_mid_array(index3, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 9))
                    index3 = (index3 + 1) % 98

                    self.np_mid_array(index4, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 10))
                    index4 = (index4 + 1) % 98

                    self.np_mid_array(index5, self.GREEN[0])
                    index5 = (index5 + 1) % 98

                    self.np_mid_array(index6, self.GREEN[0])
                    index6 = (index6 + 1) % 98

                    self.np_mid_array(index7, self.GREEN[0])
                    index7 = (index7 + 1) % 98

                    self.np_mid_array(index8, self.GREEN[0])
                    index8 = (index8 + 1) % 98

                    self.np_mid_array(index9, self.GREEN[0])
                    index9 = (index9 + 1) % 98

                    self.np_mid_array(index10, self.GREEN[0])
                    index10 = (index10 + 1) % 98

                    self.np_mid_array(index11, self.GREEN[0])
                    index11 = (index11 + 1) % 98

                    self.np_mid_array(index12, self.GREEN[0])
                    index12 = (index12 + 1) % 98

                    self.np_mid_array(index13, self.GREEN[0])
                    index13 = (index13 + 1) % 98

                    self.np_mid_array(index14, self.GREEN[0])
                    index14 = (index14 + 1) % 98

                    self.np_mid_array(index15, self.GREEN[0])
                    index15 = (index15 + 1) % 98

                    self.np_mid_array(index16, self.GREEN[0])
                    index16 = (index16 + 1) % 98

                    self.np_mid_array(index17, self.GREEN[0])
                    index17 = (index17 + 1) % 98

                    self.np_mid_array(index18, self.GREEN[0])
                    index18 = (index18 + 1) % 98

                    self.np_mid_array(index19, self.GREEN[0])
                    index19 = (index19 + 1) % 98

                    self.np_mid_array(index20, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 1))
                    index20 = (index20 + 1) % 98

                    self.np_mid_array(index21, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 2))
                    index21 = (index21 + 1) % 98

                    self.np_mid_array(index22, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 3))
                    index22 = (index22 + 1) % 98

                    self.np_mid_array(index23, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 4))
                    index23 = (index23 + 1) % 98

                    self.np_mid_array(index24, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 5))
                    index24 = (index24 + 1) % 98

                    self.np_mid_array(index25, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 6))
                    index25 = (index25 + 1) % 98

                    self.np_mid_array(index26, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 7))
                    index26 = (index26 + 1) % 98

                    self.np_mid_array(index27, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 8))
                    index27 = (index27 + 1) % 98

                    self.np_mid_array(index28, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 9))
                    index28 = (index28 + 1) % 98

                    self.np_mid_array(index29, self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, 10))
                    index29 = (index29 + 1) % 98

                    self.np_mid_array(index30, self.TURQUOISE[0])
                    index30 = (index30 + 1) % 98

                    self.np_mid_array(index31, self.TURQUOISE[0])
                    index31 = (index31 + 1) % 98

                    self.np_mid_array(index32, self.TURQUOISE[0])
                    index32 = (index32 + 1) % 98

                    self.np_mid_array(index33, self.TURQUOISE[0])
                    index33 = (index33 + 1) % 98

                    self.np_mid_array(index34, self.TURQUOISE[0])
                    index34 = (index34 + 1) % 98

                    self.np_mid_array(index35, self.TURQUOISE[0])
                    index35 = (index35 + 1) % 98

                    self.np_mid_array(index36, self.TURQUOISE[0])
                    index36 = (index36 + 1) % 98

                    self.np_mid_array(index37, self.TURQUOISE[0])
                    index37 = (index37 + 1) % 98

                    self.np_mid_array(index38, self.TURQUOISE[0])
                    index38 = (index38 + 1) % 98

                    self.np_mid_array(index39, self.TURQUOISE[0])
                    index39 = (index39 + 1) % 98

                    self.np_mid_array(index40, self.TURQUOISE[0])
                    index40 = (index40 + 1) % 98

                    self.np_mid_array(index41, self.TURQUOISE[0])
                    index41 = (index41 + 1) % 98

                    self.np_mid_array(index42, self.TURQUOISE[0])
                    index42 = (index42 + 1) % 98

                    self.np_mid_array(index43, self.TURQUOISE[0])
                    index43 = (index43 + 1) % 98

                    self.np_mid_array(index44,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 1))
                    index44 = (index44 + 1) % 98

                    self.np_mid_array(index45,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 2))
                    index45 = (index45 + 1) % 98

                    self.np_mid_array(index46,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 3))
                    index46 = (index46 + 1) % 98

                    self.np_mid_array(index47,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 4))
                    index47 = (index47 + 1) % 98

                    self.np_mid_array(index48,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 5))
                    index48 = (index48 + 1) % 98

                    self.np_mid_array(index49,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 6))
                    index49 = (index49 + 1) % 98

                    self.np_mid_array(index50,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 7))
                    index50 = (index50 + 1) % 98

                    self.np_mid_array(index51,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 8))
                    index51 = (index51 + 1) % 98

                    self.np_mid_array(index52,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 9))
                    index52 = (index52 + 1) % 98

                    self.np_mid_array(index53,
                                      self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, 10))
                    index53 = (index53 + 1) % 98

                    self.np_mid_array(index54, self.LIGHT_BLUE[0])
                    index54 = (index54 + 1) % 98

                    self.np_mid_array(index55, self.LIGHT_BLUE[0])
                    index55 = (index55 + 1) % 98

                    self.np_mid_array(index56, self.LIGHT_BLUE[0])
                    index56 = (index56 + 1) % 98

                    self.np_mid_array(index57, self.LIGHT_BLUE[0])
                    index57 = (index57 + 1) % 98

                    self.np_mid_array(index58, self.LIGHT_BLUE[0])
                    index58 = (index58 + 1) % 98

                    self.np_mid_array(index59, self.LIGHT_BLUE[0])
                    index59 = (index59 + 1) % 98

                    self.np_mid_array(index60, self.LIGHT_BLUE[0])
                    index60 = (index60 + 1) % 98

                    self.np_mid_array(index61, self.LIGHT_BLUE[0])
                    index61 = (index61 + 1) % 98

                    self.np_mid_array(index62, self.LIGHT_BLUE[0])
                    index62 = (index62 + 1) % 98

                    self.np_mid_array(index63, self.LIGHT_BLUE[0])
                    index63 = (index63 + 1) % 98

                    self.np_mid_array(index64, self.LIGHT_BLUE[0])
                    index64 = (index64 + 1) % 98

                    self.np_mid_array(index65, self.LIGHT_BLUE[0])
                    index65 = (index65 + 1) % 98

                    self.np_mid_array(index66, self.LIGHT_BLUE[0])
                    index66 = (index66 + 1) % 98

                    self.np_mid_array(index67, self.LIGHT_BLUE[0])
                    index67 = (index67 + 1) % 98

                    self.np_mid_array(index68, self.LIGHT_BLUE[0])
                    index68 = (index68 + 1) % 98

                    self.np_mid_array(index69, self.LIGHT_BLUE[0])
                    index69 = (index69 + 1) % 98

                    self.np_mid_array(index70, self.LIGHT_BLUE[0])
                    index70 = (index70 + 1) % 98

                    self.np_mid_array(index71, self.LIGHT_BLUE[0])
                    index71 = (index71 + 1) % 98

                    self.np_mid_array(index72,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 1))
                    index72 = (index72 + 1) % 98

                    self.np_mid_array(index73,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 2))
                    index73 = (index73 + 1) % 98

                    self.np_mid_array(index74,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 3))
                    index74 = (index74 + 1) % 98

                    self.np_mid_array(index75,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 4))
                    index75 = (index75 + 1) % 98

                    self.np_mid_array(index76,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 5))
                    index76 = (index76 + 1) % 98

                    self.np_mid_array(index77,
                                      self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 6, 6))
                    index77 = (index77 + 1) % 98

                    self.np_mid_array(index78, self.DARK_BLUE[0])
                    index78 = (index78 + 1) % 98

                    self.np_mid_array(index79, self.DARK_BLUE[0])
                    index79 = (index79 + 1) % 98

                    self.np_mid_array(index80, self.DARK_BLUE[0])
                    index80 = (index80 + 1) % 98

                    self.np_mid_array(index81, self.DARK_BLUE[0])
                    index81 = (index81 + 1) % 98

                    self.np_mid_array(index82, self.DARK_BLUE[0])
                    index82 = (index82 + 1) % 98

                    self.np_mid_array(index83, self.DARK_BLUE[0])
                    index83 = (index83 + 1) % 98

                    self.np_mid_array(index84, self.DARK_BLUE[0])
                    index84 = (index84 + 1) % 98

                    self.np_mid_array(index85, self.DARK_BLUE[0])
                    index85 = (index85 + 1) % 98

                    self.np_mid_array(index86, self.DARK_BLUE[0])
                    index86 = (index86 + 1) % 98

                    self.np_mid_array(index87, self.DARK_BLUE[0])
                    index87 = (index87 + 1) % 98

                    self.np_mid_array(index88, self.DARK_BLUE[0])
                    index88 = (index88 + 1) % 98

                    self.np_mid_array(index89, self.DARK_BLUE[0])
                    index89 = (index89 + 1) % 98

                    self.np_mid_array(index90, self.DARK_BLUE[0])
                    index90 = (index90 + 1) % 98

                    self.np_mid_array(index91, self.DARK_BLUE[0])
                    index91 = (index91 + 1) % 98

                    self.np_mid_array(index92, self.DARK_BLUE[0])
                    index92 = (index92 + 1) % 98

                    self.np_mid_array(index93, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 1))
                    index93 = (index93 + 1) % 98

                    self.np_mid_array(index94, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 2))
                    index94 = (index94 + 1) % 98

                    self.np_mid_array(index95, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 3))
                    index95 = (index95 + 1) % 98

                    self.np_mid_array(index96, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 4))
                    index96 = (index96 + 1) % 98

                    self.np_mid_array(index97, self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, 5))
                    index97 = (index97 + 1) % 98

                    r_mid = 0

                # _____________________________________MID ENDE_______________________________________________


                if bottom_time_speed == 10:
                    # print("Farbe: ", color_number, ", STEPS: ", bottom_color_step)
                    if color_number == 0:
                        current_color = self.GREEN[0]
                    elif color_number == 1:
                        current_color = self.smooth_color_transition(self.GREEN[0], self.TURQUOISE[0], 10, bottom_color_step)
                    elif color_number == 2:
                        current_color = self.TURQUOISE[0]
                    elif color_number == 3:
                        current_color = self.smooth_color_transition(self.TURQUOISE[0], self.LIGHT_BLUE[0], 10, bottom_color_step)
                    elif color_number == 4:
                        current_color = self.LIGHT_BLUE[0]
                    elif color_number == 5:
                        current_color = self.smooth_color_transition(self.LIGHT_BLUE[0], self.DARK_BLUE[0], 10, bottom_color_step)
                    elif color_number == 6:
                        current_color = self.DARK_BLUE[0]
                    elif color_number == 7:
                        current_color = self.smooth_color_transition(self.DARK_BLUE[0], self.GREEN[0], 10, bottom_color_step)

                    if bottom_color_step < 10:
                        bottom_color_step += 1
                    else:
                        bottom_color_step = 1
                        if color_number < 7:
                            color_number += 1
                        else:
                            color_number = 1

                    bottom_time_speed = 0


                    # BOTTOM - LEDS
                    self.bottom1_array(0, current_color)
                    self.bottom1_array(1, current_color)
                    self.bottom1_array(2, current_color)
                    self.bottom1_array(3, current_color)
                    self.bottom1_array(4, current_color)
                    self.bottom1_array(5, current_color)
                    self.bottom1_array(6, current_color)
                    self.bottom1_array(7, current_color)
                    self.bottom1_array(8, current_color)
                    self.bottom1_array(9, current_color)
                    self.bottom1_array(10, current_color)
                    self.bottom1_array(11, current_color)

                    self.bottom2_array(0, current_color)
                    self.bottom2_array(1, current_color)
                    self.bottom2_array(2, current_color)
                    self.bottom2_array(3, current_color)
                    self.bottom2_array(4, current_color)
                    self.bottom2_array(5, current_color)
                    self.bottom2_array(6, current_color)
                    self.bottom2_array(7, current_color)
                    self.bottom2_array(8, current_color)
                    self.bottom2_array(9, current_color)
                    self.bottom2_array(10, current_color)
                    self.bottom2_array(11, current_color)

                    self.bottom3_array(0, current_color)
                    self.bottom3_array(1, current_color)
                    self.bottom3_array(2, current_color)
                    self.bottom3_array(3, current_color)
                    self.bottom3_array(4, current_color)
                    self.bottom3_array(5, current_color)
                    self.bottom3_array(6, current_color)
                    self.bottom3_array(7, current_color)
                    self.bottom3_array(8, current_color)
                    self.bottom3_array(9, current_color)
                    self.bottom3_array(10, current_color)
                    self.bottom3_array(11, current_color)

                # _____________________________________BOTTOM START_______________________________________________

                # _____________________________________BOTTOM ENDE_______________________________________________

                r4 = 0

            # self.checktouchinput()

            if self.earth_on == False:
                return
            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()

            #             # Update the current LED index
            #             current_led += 1
            #             if current_led > 97:
            #                 current_led = 0

            current_led = (current_led + 1) % 90

    # Die Methode gibt dir einene gegebene Farbwert zurck, welche durch die "brightness" eingestellt wurde
    # @micropython.native
    def scale_color(self, color_tupel, brightness):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)

        return (r, g, b, w)

    # @micropython.native
    def smooth_color_transition(self, start_color, end_color, num_steps, current_step):
        """
        Performs a smooth color transition from start_color to end_color over 4 LEDs based on the current step.

        Arguments:
        start_color (tuple): RGBW values of the start color.
        end_color (tuple): RGBW values of the end color.
        num_steps (int): Total number of steps in the transition.
        current_step (int): Current step in the transition.

        Returns:
        tuple: RGBW values of the color at the current step.
        """
        # Calculate the step size for each channel
        color_step = [(end_color[i] - start_color[i]) / num_steps for i in range(4)]

        # Calculate the current color based on the current step
        current_color = [int(start_color[i] + color_step[i] * current_step) for i in range(4)]

        return tuple(current_color)

    def start(self, stop_event, diming):
        self.earth_on = True
        self.earth_loop(stop_event, diming)

    def stop(self):
        self.earth_on = False
        self.earth_off()
        self.np.deinit()

    def earth_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.earth_on


#earth = Earth(False)
#stop_event = multiprocessing.Event()
#diming  = True
#earth.start(stop_event, diming)
