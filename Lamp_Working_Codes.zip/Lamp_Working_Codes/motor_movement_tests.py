from tilt_motor_control import *
from rotation_motor_control import *
import board

if __name__ == '__main__':
    # Create a MotorControl instance
    #motor_control_tilt = Tilt_MotorControl(board.D23, board.D25)  # assign correct pins here
    motor_control_rotation = Rotation_MotorControl(board.D23, board.D25) #assign correct pins here

    while True:
        try:

            # Get the desired angle from the user
            user_input = int(input("Enter desired angle in degrees (0 to exit): "))
            user_input_speed = int(input("enter speed: 1-100 "))

            if 1 <= user_input_speed <= 100:
                # motor_control_tilt.run(user_input, user_input_speed)
                motor_control_rotation.run(user_input, user_input_speed)
            else:
                print("Invalid input. Please enter a valid speed between 1 and 100.")



        except ValueError:
            print("Invalid input. Please enter a valid angle in degrees.")

        except KeyboardInterrupt:
            print("Exiting the program.")
            break
