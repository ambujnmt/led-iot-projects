import time
import board
import busio
import adafruit_mpr121
import json

# Zeitkonstanten
# SHORT_TAP_TIME = 0.2
# DOUBLE_TAP_INTERVAL = 1.0
# HOLD_TIME = 1.0
# GESTURE_COOLDOWN_TIME = 0.25

# Zustandsvariablen
#last_tap_time = [0] * 12
#last_touch_state = [False] * 12
#hold_started_time = [0] * 12
#double_tapped = [False] * 12
#last_gesture_time = [0] * 12

# Erstelle I2C bus und MPR121 Objekt
#i2c = busio.I2C(board.SCL, board.SDA)
#mpr121 = adafruit_mpr121.MPR121(i2c)





class Touchsteuerung:
    def __init__(self):
        
        from led_programmliste import manager
        # Initialisierung des MPR121 und weiterer Variablen
        self.i2c = busio.I2C(board.SCL, board.SDA)
        self.mpr121 = adafruit_mpr121.MPR121(self.i2c)
        self.touch_threshold = 20
        self.touch_pin = 0  # Oder ein anderer Pin, den Sie verwenden möchten
        self.manager = manager
        #mpr121[i].threshold = 40 
        print("threshold init: ",self.mpr121[0].threshold)
        self.mpr121[0].threshold = 4
    
    def checktouchinput(self):
        if self.confirmtouch():
            print("touch erkannt")
            print("checktouchinput gestartet")
            print("prüfe ob gehalten wird")

            if not self.checkhold():
                print("checkhold ist false")
                
                print("prüfe ob 2 kurzer touch ankommt")
                
                if self.checksecondtouch():
                    print("doppelter kurzer Tap erkannt")
                    self.previousprogramm()
                    
                    time.sleep(0.02)
                else:
                    print("nur einfacher kurzer tap erkannt")
                    self.nextprogramm()
                    
                    time.sleep(0.02)
            else:
                print("nur 1 langes halten erkannt")
                #TODO led_programm_manager pause und unpause funktion implementieren (Ausschalten einschalten)
            
            time.sleep(0.02)
            print("threshold init: ",self.mpr121[0].threshold)
            # Hier müssen Sie eine Methode implementieren, um den touch_threshold neu zu kalibrieren
        else:
            return

    
    
    def confirmtouch(self):
        counter = 0
        checkvalue = 0
        last_touch_state = False

        while True:
            touch_state = self.mpr121[0].value
            #print("Confirm Touch Funktion touch state: " , touch_state)
            if touch_state and not last_touch_state:
                #print("checkvalue erhöht")
                checkvalue += 1

        

            counter += 1
            if counter == 2:
                break
            

        if checkvalue > 1:
            print("Touch erkannt")
            return True
        else:
            print("Kein Touch erkannt")
            return False
        
    
    def checkhold(self):
        print("checkhold gestartet")
        counter = 0
        holdcounter = 0
        #holdvalue = 20  # Setzen Sie dies auf einen geeigneten Wert, um einen "hold" Zustand zu erkennen
        last_touch_state = False

        while True:
            touch_state = self.mpr121[0].value
            if touch_state and not last_touch_state:
                holdcounter = holdcounter + 1

            if counter == 40:
                break

            if holdcounter > 25:
                print("Hold Detected")
                # if self.paused == False:
                    # self.pause()
                time.sleep(1)
                # else:
                    # self.unpause()
                break
            counter = counter + 1


            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep(0.003)

        if holdcounter > 25:
            return True
        else:
            return False
        
        
        
    def checksecondtouch(self):
        print("checksecondtouch gestartet")
        counter = 0
        holdcounter = 0

        while True:
            touch_state = self.mpr121[0].value
            if touch_state:  # Wenn der Pin berührt wird
                holdcounter = holdcounter + 1

            if counter == 40:
                break

            if holdcounter > 25:
                print("Hold after short touch Detected")
                break
            counter = counter + 1

            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep(0.003)

        if holdcounter > 25:
            print("2. Hold erkannt, wird nur für Benutzerdefiniert anderst interpretiert")
            return True
        elif holdcounter > 4:
            print("kurzer 2. Tap erkannt")
            return True
        else:
            print("kein 2. Touch erkannt")
            return False
            
    '''Abschnitt LED Programm manager steuerung'''
    
    def pause(self):
        #self.paused = True
        #self.rainbow_off()
        print("Pause wurde auf true gesetzt")

    def unpause(self):
        #self.paused = False
        #print("Pause wurde auf False gesetzt", self.paused)
        print("Pause wurde beendet")
        
        
        
    def nextprogramm(self):
        
        print("Nextprogramm ausgelöst!")
        #data = None
        

        #with open("current_lampmodel.json", "r") as f:
            #data = json.load(f)
            
        #time.sleep(1)
        
        
        #print("nächstes programm aufgerufen")
        #sleep funktion auskommentieren nur f+r testing
        #time.sleep(3)
        #self.stop()
        #self.manager.next_program(data)
        
    def previousprogramm(self):
        
        
        print("vorheriges programm aufgerufen")
                
        #data = None
        
        
        #with open("current_lampmodel.json", "r") as f:
            #data = json.load(f)
            

        #time.sleep(1)
        #self.stop()
        #self.manager.previous_program(data)

        
        
      
        
        

        
        
        
'''
touchsteuerung = Touchsteuerung()

from led_programm_rainbow import RainbowLED
from led_programm_indigo_cure import Indigo_Cure

indigo = Indigo_Cure(True)
rainbow = RainbowLED(True)


while True:
    if touchsteuerung.mpr121[0].value == True:
        touchsteuerung.checktouchinput()
    
    time.sleep(0.01)
'''
    
        

# Um die Methode zu verwenden, rufen Sie sie wie folgt auf:
# result = self.checkhold(0)  # Überprüfen Sie, ob Pin 0 gehalten wird




''' ChatGpt Version'''

'''
while True:
    current_time = time.time()

    if mpr121[0].value:
        if not last_touch_state[0]:
            # Prüfe auf Doppeltippen
            if current_time - last_tap_time[0] <= DOUBLE_TAP_INTERVAL and current_time - last_gesture_time[0] > GESTURE_COOLDOWN_TIME:
                print(f"Input 0 double tapped!")
                double_tapped[0] = True
                last_gesture_time[0] = current_time
            else:
                # Starte die Haltezeitmessung
                hold_started_time[0] = current_time
                double_tapped[0] = False
            
            last_tap_time[0] = current_time
            last_touch_state[0] = True
        else:
            # Prüfe auf Halten, wenn nicht doppelt getippt
            if not double_tapped[0] and current_time - hold_started_time[0] >= HOLD_TIME and current_time - last_gesture_time[0] > GESTURE_COOLDOWN_TIME:
                print(f"Input 0 held!")
                hold_started_time[0] = current_time  # Zurücksetzen des Halte-Timers nach der Erkennung
                last_gesture_time[0] = current_time
    else:
        if last_touch_state[0]:
            # Prüfe auf kurzes Tippen
            if current_time - last_tap_time[0] <= SHORT_TAP_TIME and current_time - last_gesture_time[0] > GESTURE_COOLDOWN_TIME:
                print(f"Input 0 short tapped!")
                last_gesture_time[0] = current_time
            last_touch_state[0] = False
            hold_started_time[0] = 0  # Zurücksetzen des Halte-Timers, wenn die Berührung aufhört
            double_tapped[0] = False  # Zurücksetzen des Doppeltipp-Flags, wenn die Berührung aufhört

    time.sleep(0.01)
'''
    
'''Alte Touchinputfunktion aus LED Programm:
 def checktouchinput(self):
        
        

            
        if self.confirmtouch() == True:
            print("touch erkannt")
                
            print("checktouchinput gestartet")
            print("prüfe ob gehalten wird")

            if self.checkhold(self.touch_threshold) == False:
                print("checkhold ist false")
                #sprich hier haben wir bereits den ersten kurzen touch erkannt, nun müssen wir prüfen ob ein 2. kurzer touch erkannt wird
                #um zwischen 1 kurzen tap und 2 kruze taps und ggf 1 kurzer tap und hold zu differenzieren
                
                print("prüfe ob 2 kurzer touch ankommt")
                
                if self.checksecondtouch(self.touch_threshold) == True:
                    print("doppelter kurzer Tap erkannt")
                    self.previousprogramm()
                    
                    
                    
                    #hier funktion für vorheriges programm einfügen
                    
                    
                    time.sleep(3)
                
                else:
                    print("nur einfacher kurzer tap erkannt")
                    self.nextprogramm()
                    
                    time.sleep(3)
                    
                    #hier funktion für nächstes programm einfügen
                 
            else:
                print("nur 1 langes halten erkannt")
                
            time.sleep(3)
            #touchwert ohne berührung neu kalibrieren
            self.touch_threshold = self.touch_pin.read()
            
        
        else:
            return
            
            
            
            
    def confirmtouch(self):
        counter = 0
        checkvalue = 0
        while True:
            touchvalue = self.touch_pin.read()
            if touchvalue < self.touch_threshold -20 or touchvalue > self.touch_threshold +20:
                checkvalue = checkvalue +1
            
            counter = counter +1
            if counter == 3:
                break
        
        if checkvalue > 2:
            return True
        
        else:
            return False
            
                
            
        
                
    def checkhold(self, holdvalue):
        print("checkhold gestartet")
        counter = 0
        holdcounter = 0

        while True:
            x = self.touch_pin.read()
            if x > holdvalue + 20 or x < holdvalue-20:
                holdcounter = holdcounter + 1
                
            if counter == 20:
                break

            if holdcounter > 15:
                print("Hold Detected")
                if self.paused == False:
                    self.pause()
                else:
                    self.unpause()
                break
            counter = counter + 1
            
            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep(0.003)

        if holdcounter > 15:
            return True
        else:
            return False       
            
    def checksecondtouch(self, touchvalue):
        
        print("checksecondtouch gestartet")
        counter = 0
        holdcounter = 0
        while True:
            x = self.touch_pin.read()
            if x > touchvalue + 20 or x < touchvalue-20:
                holdcounter = holdcounter + 1
                
            if counter == 40:
                break

            if holdcounter > 25:
                print("Hold after short touch Detected")
                break
            counter = counter + 1
            
            print("Schleifendurchlauf checkhold")
            print("countervalue: ", counter)
            time.sleep(0.003)

        if holdcounter > 25:
            print("2. Hold erkannt, wird nur für Benutzerdefiniert anderst interpretiert")
            return True
        elif holdcounter > 4:   
            print("kurzer 2. Tap erkannt")
            return True
        else:
            print("kein 2. Touch erkannt")
            return False
        
    def pause(self):
        self.paused = True
        self.rainbow_off()
        print("Pause wurde auf true gesetzt", self.paused)

    def unpause(self):
        self.paused = False
        print("Pause wurde auf False gesetzt", self.paused)
        
        
        
    def nextprogramm(self):
        
        print("nächstes programm aufgerufen")
        #sleep funktion auskommentieren nur f+r testing
        #time.sleep(3)
        self.stop()
        manager.next_program(self)
        
    def previousprogramm(self):
        
        print("vorheriges programm aufgerufen")
        time.sleep(3)
        self.stop()
        manager.previous_program(self)
'''
