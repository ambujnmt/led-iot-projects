import smbus
import struct

# Create an instance of the I2C bus
# DATASHEET S.23
i2c_bus = smbus.SMBus(1)

# IC's I2C address and register address
DEVICE_ADDRESS = 0x36  # Replace with your device's I2C address
REGISTER_ADDRESS = 0x0B  # Replace with the current register's address

# Define your sense resistor value (in ohms)
SENSE_RESISTOR = 0.005  # Replace with your actual sense resistor value in ohms

# Define the current resolution (in μA) based on the sense resistor value
CURRENT_RESOLUTION = 312.5  # Replace with your actual current resolution from the datasheet

def read_register(address):
    # Reads a 16-bit register value from the IC
    raw_data = i2c_bus.read_i2c_block_data(DEVICE_ADDRESS, address, 2)
    # Combine the two bytes and interpret as a signed 16-bit value
    register_value = struct.unpack('<h', bytes(raw_data))[0]
    return register_value

def calculate_current(raw_value, current_resolution):
    # Convert raw register value to current (in Amperes) using the current resolution
    current_micro_amps = raw_value * current_resolution
    current_amps = current_micro_amps / 1_000_000.0  # Convert from μA to A
    return current_amps

def get_ladestaerke():
    try:
        # Read the value of the register
        register_value = read_register(REGISTER_ADDRESS)
        print(f"Raw register value: {register_value}")

        # Calculate the current in Amperes
        current = calculate_current(register_value, CURRENT_RESOLUTION)
        print(f"Calculated current: {current} A")
        return current
    except Exception as e:
        print(f"An error occurred: {e}")
        return 0
    # finally:
    #     # Close the I2C bus when done
    #     i2c_bus.close()


# def main():
#     try:
#         # Read the value of the register
#         register_value = read_register(REGISTER_ADDRESS)
#         print(f"Raw register value: {register_value}")
#
#         # Calculate the current in Amperes
#         current = calculate_current(register_value, CURRENT_RESOLUTION)
#         print(f"Calculated current: {current} A")
#     except Exception as e:
#         print(f"An error occurred: {e}")
#     finally:
#         # Close the I2C bus when done
#         i2c_bus.close()
#
# if __name__ == "__main__":
#     main()
