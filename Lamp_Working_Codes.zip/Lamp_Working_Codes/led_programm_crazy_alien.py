#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time


import random
import gc



class Crazy_alien:
    def __init__(self, touchenabled):

        manager.add_programm(self)

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)

        #'Belegung ESP32 mehr Ram'

        self.PIN = board.D12 #18

        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23
        '''
        #'Belegung ESP32 mehr Ram'

        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23

        #Belegung ESP32 Platine

        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''


        # Define the colors

        self.DARK = [(0, 0, 0, 0)]
        self.GREEN = [(0, 150, 0, 0)]

        self.crazy_alien_running = False
        self.thread_running = None

        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.crazy_alien_on = False

        print("Crazy Alien wurde initialisiert")

        self.init = True

        time.sleep(0.1)

    def np_top_array(self, position, value):

         self.np[position] = value

    def np_mid_array(self, position, value):

        #print("Position mid array: ", position)


        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value




    def crazy_alien_loop(self, stop_event, diming, change_timing = True):

        if diming:
            #self.DARK = (0,0,0,0)  50% gedimmt
            #self.GREEN = (0,75,0,0)

            
            # auf 25% gedimmt
            self.DARK = [(0, 0, 0, 0)]
            self.GREEN = [(0, 38, 0, 0)]
        gc.enable()



        r4 = 0                   # Dient dazu, eine 0,5 Sekundenpause pro neugestaltetem Led durchzuführen
        led_top_break = 20        # Dient dazu, eine 5 Sekunden-Pause einzuführen, wenn die Top Leds eine Runde (jeweils 180°) durchlaufen sind

        led_top_first_count = 0
        led_top_second_count = 5

        led_mid_first_count = 0
        led_mid_second_count = 48

        led_mid_first_round = 0
        led_mid_second_round = 0

        led_bottom_count = 2

        color = self.GREEN[0]
        '''
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        '''
        #print("Crazy Alien: starte programm")


        while self.crazy_alien_on:

            #print("Crazy Alien: starte while Schleife")

            '''
             #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''
            if stop_event.is_set():
                self.stop()
                return
            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            if stop_event.is_set():
                self.stop()
                return

            r4 += 1



            if(r4 == 40):

                if led_top_break <= 19:
                    led_top_break += 1

                #______________________________________TOP START_______________________________________________
                if led_top_break == 20:
                    # TOP - LEDS
                    self.np_top_array(0, self.DARK[0])
                    self.np_top_array(1, self.DARK[0])
                    self.np_top_array(2, self.DARK[0])
                    self.np_top_array(3, self.DARK[0])
                    self.np_top_array(4, self.DARK[0])
                    self.np_top_array(5, self.DARK[0])
                    self.np_top_array(6, self.DARK[0])
                    self.np_top_array(7, self.DARK[0])
                    self.np_top_array(8, self.DARK[0])
                    self.np_top_array(9, self.DARK[0])

                    # Top - Led
                    # Erste Seite 180° Drehnung
                    self.np_top_array(led_top_first_count, self.GREEN[0])
                    led_top_first_count += 1

                    # Top - Led
                    # Zweite Seite 180° Drehnung
                    if led_top_second_count < 9:
                        self.np_top_array(led_top_second_count, self.GREEN[0])
                    led_top_second_count += 1

                    if led_top_first_count == 5 and led_top_second_count == 10:
                        led_top_first_count = 0
                        led_top_break = 0
                        led_top_second_count = 5
                        self.np_top_array(0, self.DARK[0])
                        self.np_top_array(1, self.DARK[0])
                        self.np_top_array(2, self.DARK[0])
                        self.np_top_array(3, self.DARK[0])
                        self.np_top_array(4, self.DARK[0])
                        self.np_top_array(5, self.DARK[0])
                        self.np_top_array(6, self.DARK[0])
                        self.np_top_array(7, self.DARK[0])
                        self.np_top_array(8, self.DARK[0])
                        self.np_top_array(9, self.DARK[0])
                #_____________________________________TOP ENDE________________________________________________

                if stop_event.is_set():
                    self.stop()
                    return

                #_____________________________________MID START_______________________________________________
                # Mid - Led
                # Erste Seite 180° Drehung
                if led_mid_first_round < 7:
                    self.np_mid_array(led_mid_first_count, self.GREEN[0])
                    led_mid_first_count += 1
                    if led_mid_first_count >= 6:
                        self.np_mid_array(led_mid_first_count-7, self.DARK[0])


                if led_mid_first_round == 0:
                    if led_mid_first_count == 49:
                        led_mid_first_count = 0
                        led_mid_first_round = 1

                elif led_mid_first_round == 1:
                    if led_mid_first_count == 42:
                        self.np_mid_array(42, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 2

                elif led_mid_first_round == 2:
                    if led_mid_first_count == 35:
                        self.np_mid_array(35, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 3

                elif led_mid_first_round == 3:
                    if led_mid_first_count == 28:
                        self.np_mid_array(28, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 4

                elif led_mid_first_round == 4:
                    if led_mid_first_count == 22:
                        self.np_mid_array(22, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 5

                elif led_mid_first_round == 5:
                    if led_mid_first_count == 14:
                        self.np_mid_array(14, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 6

                elif led_mid_first_round == 6:
                    if led_mid_first_count == 7:
                        self.np_mid_array(7, self.GREEN[0])
                        led_mid_first_count = 0
                        led_mid_first_round = 7
                        self.np_mid_array(0, self.GREEN[0])

                elif led_mid_first_round == 7:
                    print('Ende 1')
#                     led_mid_first_count = 0
#                     led_mid_first_round = 0
#                     self.mid_led_off()

#                 elif led_mid_first_round == 8:
#                     if led_mid_first_count == 1:
#                         led_mid_first_count = 0
#                         led_mid_first_round = 9
#
#                 elif led_mid_first_round == 9:
#                     self.mid_led_off()
#                     led_mid_first_round = 0
#                     led_mid_first_count = 0

                # Mid - Led
                # Zweite Seite 180° Drehung
                if led_mid_second_round < 7:
                    self.np_mid_array(led_mid_second_count, self.GREEN[0])
                    led_mid_second_count += 1
                    if led_mid_second_count >= 54:
                        self.np_mid_array(led_mid_second_count-7, self.DARK[0])

                if led_mid_second_round == 0:
                    if led_mid_second_count == 98:
                        self.np_mid_array(97, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 1

                elif led_mid_second_round == 1:
                    if led_mid_second_count == 91:
                        self.np_mid_array(91, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 2

                elif led_mid_second_round == 2:
                    if led_mid_second_count == 84:
                        self.np_mid_array(84, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 3

                elif led_mid_second_round == 3:
                    if led_mid_second_count == 77:
                        self.np_mid_array(77, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 4

                elif led_mid_second_round == 4:
                    if led_mid_second_count == 70:
                        self.np_mid_array(70, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 5

                elif led_mid_second_round == 5:
                    if led_mid_second_count == 63:
                        self.np_mid_array(63, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 6

                elif led_mid_second_round == 6:
                    if led_mid_second_count == 56:
                        self.np_mid_array(56, self.GREEN[0])
                        self.np_mid_array(51, self.GREEN[0])
                        led_mid_second_count = 49
                        led_mid_second_round = 7

                elif led_mid_second_round == 7:
                    print('Ende 1')
#                         led_mid_second_round = 0
#                         led_mid_second_count = 49


#                 elif led_mid_second_round == 8:
#                     if led_mid_second_count == 51:
#                         led_mid_second_count = 49
#                         led_mid_second_round = 9
#
#                 elif led_mid_second_round == 9:
#                     self.mid_led_off()
#                     led_mid_second_round = 0
#                     led_mid_second_count = 49

                if led_mid_second_round == 7 and led_mid_first_round == 7:
                    #print('NEUSTART Mid - LED')
                    led_mid_first_count = 0
                    led_mid_first_round = 0

                    led_mid_second_round = 0
                    led_mid_second_count = 49

                    self.mid_led_off()

                    if stop_event.is_set():
                        self.stop()
                        return
                #_____________________________________MID ENDE_______________________________________________

                if stop_event.is_set():
                    self.stop()
                    return
                #_____________________________________BOTTOM START_______________________________________________
#                 if led_top_break < 20:
#                     if led_top_break == 0:
#                         led_bottom_count += 1
#                     self.start_bottom(led_bottom_count, true)
#
#                 else:
#                     self.start_bottom(led_bottom_count, false)
#                 color = self.GREEN[0]
#                 start = true

                if led_top_break < 20:
                    if led_top_break == 0:
                        led_bottom_count -= 1
                        if led_bottom_count < 0:
                            led_bottom_count = 2
                    color = self.GREEN[0]

                else:
                    color = self.DARK[0]

                # BOTTOM - LEDS
                if led_bottom_count == 0:
                    self.bottom1_array(0, color)
                    self.bottom1_array(1, color)
                    self.bottom1_array(2, color)
                    self.bottom1_array(3, color)
                    self.bottom1_array(4, color)
                    self.bottom1_array(5, color)
#                     self.np_bottom_first[(6)] = color
#                     self.np_bottom_first[(7)] = color
#                     self.np_bottom_first[(8)] = color
#                     self.np_bottom_first[(9)] = color
#                     self.np_bottom_first[(10)] = color
#                     self.np_bottom_first[(11)] = color

                if led_bottom_count == 1:
                    self.bottom2_array(0, color)
                    self.bottom2_array(1, color)
                    self.bottom2_array(2, color)
                    self.bottom2_array(3, color)
                    self.bottom2_array(4, color)
                    self.bottom2_array(5, color)
#                     self.np_bottom_second[(6)] = color
#                     self.np_bottom_second[(7)] = color
#                     self.np_bottom_second[(8)] = color
#                     self.np_bottom_second[(9)] = color
#                     self.np_bottom_second[(10)] = color
#                     self.np_bottom_second[(11)] = color

                if led_bottom_count == 2:
                    self.bottom3_array(0, color)
                    self.bottom3_array(1, color)
                    self.bottom3_array(2, color)
                    self.bottom3_array(3, color)
                    self.bottom3_array(4, color)
                    self.bottom3_array(5, color)
#                     self.np_bottom_third[(6)] = color
#                     self.np_bottom_third[(7)] = color
#                     self.np_bottom_third[(8)] = color
#                     self.np_bottom_third[(9)] = color
#                     self.np_bottom_third[(10)] = color
#                     self.np_bottom_third[(11)] = color
                #_____________________________________BOTTOM ENDE_______________________________________________
                if stop_event.is_set():
                    self.stop()
                    return

                r4 = 0

            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()

            if self.crazy_alien_running == False:
                return
            '''
            if stop_event.is_set():
                self.stop()
                return


            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()

            #print("Grazy Alien Leuchtprogramm hat funktioniert :)")

    #@micropython.native
    def mid_led_off(self):
        self.np_mid_array(1, self.DARK[0])
        self.np_mid_array(2, self.DARK[0])
        self.np_mid_array(3, self.DARK[0])
        self.np_mid_array(4, self.DARK[0])
        self.np_mid_array(5, self.DARK[0])
        self.np_mid_array(6, self.DARK[0])
        self.np_mid_array(7, self.DARK[0])
        self.np_mid_array(8, self.DARK[0])
        self.np_mid_array(9, self.DARK[0])
        self.np_mid_array(10, self.DARK[0])
        self.np_mid_array(11, self.DARK[0])
        self.np_mid_array(12, self.DARK[0])
        self.np_mid_array(13, self.DARK[0])
        self.np_mid_array(14, self.DARK[0])
        self.np_mid_array(15, self.DARK[0])
        self.np_mid_array(16, self.DARK[0])
        self.np_mid_array(17, self.DARK[0])
        self.np_mid_array(18, self.DARK[0])
        self.np_mid_array(19, self.DARK[0])
        self.np_mid_array(20, self.DARK[0])
        self.np_mid_array(21, self.DARK[0])
        self.np_mid_array(22, self.DARK[0])
        self.np_mid_array(23, self.DARK[0])
        self.np_mid_array(24, self.DARK[0])
        self.np_mid_array(25, self.DARK[0])
        self.np_mid_array(26, self.DARK[0])
        self.np_mid_array(27, self.DARK[0])
        self.np_mid_array(28, self.DARK[0])
        self.np_mid_array(29, self.DARK[0])
        self.np_mid_array(30, self.DARK[0])
        self.np_mid_array(31, self.DARK[0])
        self.np_mid_array(32, self.DARK[0])
        self.np_mid_array(33, self.DARK[0])
        self.np_mid_array(34, self.DARK[0])
        self.np_mid_array(35, self.DARK[0])
        self.np_mid_array(36, self.DARK[0])
        self.np_mid_array(37, self.DARK[0])
        self.np_mid_array(38, self.DARK[0])
        self.np_mid_array(39, self.DARK[0])
        self.np_mid_array(40, self.DARK[0])
        self.np_mid_array(41, self.DARK[0])
        self.np_mid_array(42, self.DARK[0])
        self.np_mid_array(43, self.DARK[0])
        self.np_mid_array(44, self.DARK[0])
        self.np_mid_array(45, self.DARK[0])
        self.np_mid_array(46, self.DARK[0])
        self.np_mid_array(47, self.DARK[0])
        self.np_mid_array(48, self.DARK[0])
        self.np_mid_array(49, self.DARK[0])
        self.np_mid_array(50, self.DARK[0])
        self.np_mid_array(51, self.DARK[0])
        self.np_mid_array(52, self.DARK[0])
        self.np_mid_array(53, self.DARK[0])
        self.np_mid_array(54, self.DARK[0])
        self.np_mid_array(55, self.DARK[0])
        self.np_mid_array(56, self.DARK[0])
        self.np_mid_array(57, self.DARK[0])
        self.np_mid_array(58, self.DARK[0])
        self.np_mid_array(59, self.DARK[0])
        self.np_mid_array(60, self.DARK[0])
        self.np_mid_array(61, self.DARK[0])
        self.np_mid_array(62, self.DARK[0])
        self.np_mid_array(63, self.DARK[0])
        self.np_mid_array(64, self.DARK[0])
        self.np_mid_array(65, self.DARK[0])
        self.np_mid_array(66, self.DARK[0])
        self.np_mid_array(67, self.DARK[0])
        self.np_mid_array(68, self.DARK[0])
        self.np_mid_array(69, self.DARK[0])
        self.np_mid_array(70, self.DARK[0])
        self.np_mid_array(71, self.DARK[0])
        self.np_mid_array(72, self.DARK[0])
        self.np_mid_array(73, self.DARK[0])
        self.np_mid_array(74, self.DARK[0])
        self.np_mid_array(75, self.DARK[0])
        self.np_mid_array(76, self.DARK[0])
        self.np_mid_array(77, self.DARK[0])
        self.np_mid_array(78, self.DARK[0])
        self.np_mid_array(79, self.DARK[0])
        self.np_mid_array(80, self.DARK[0])
        self.np_mid_array(81, self.DARK[0])
        self.np_mid_array(82, self.DARK[0])
        self.np_mid_array(83, self.DARK[0])
        self.np_mid_array(84, self.DARK[0])
        self.np_mid_array(85, self.DARK[0])
        self.np_mid_array(86, self.DARK[0])
        self.np_mid_array(87, self.DARK[0])
        self.np_mid_array(88, self.DARK[0])
        self.np_mid_array(89, self.DARK[0])
        self.np_mid_array(90, self.DARK[0])
        self.np_mid_array(91, self.DARK[0])
        self.np_mid_array(92, self.DARK[0])
        self.np_mid_array(93, self.DARK[0])
        self.np_mid_array(94, self.DARK[0])
        self.np_mid_array(95, self.DARK[0])
        self.np_mid_array(96, self.DARK[0])
        self.np_mid_array(97, self.DARK[0])

    #@micropython.native
    def start_bottom(self, bottom_number, start):

        color = self.GREEN[0]

        if start == True:
            color = color = self.GREEN[0]
        else:
            color = self.DARK[0]

        # BOTTOM - LEDS
        if bottom_number == 0:
            self.bottom1_array(0, color)
            self.bottom1_array(1, color)
            self.bottom1_array(2, color)
            self.bottom1_array(3, color)
            self.bottom1_array(4, color)
            self.bottom1_array(5, color)
            self.bottom1_array(6, color)
            self.bottom1_array(7, color)
            self.bottom1_array(8, color)
            self.bottom1_array(9, color)
            self.bottom1_array(10, color)
            self.bottom1_array(11, color)

        if bottom_number == 1:
            self.bottom2_array(0, color)
            self.bottom2_array(1, color)
            self.bottom2_array(2, color)
            self.bottom2_array(3, color)
            self.bottom2_array(4, color)
            self.bottom2_array(5, color)
            self.bottom2_array(6, color)
            self.bottom2_array(7, color)
            self.bottom2_array(8, color)
            self.bottom2_array(9, color)
            self.bottom2_array(10, color)
            self.bottom2_array(11, color)

        if bottom_number == 2:
            self.bottom3_array(0, color)
            self.bottom3_array(1, color)
            self.bottom3_array(2, color)
            self.bottom3_array(3, color)
            self.bottom3_array(4, color)
            self.bottom3_array(5, color)
            self.bottom3_array(6, color)
            self.bottom3_array(7, color)
            self.bottom3_array(8, color)
            self.bottom3_array(9, color)
            self.bottom3_array(10, color)
            self.bottom3_array(11, color)

    def start(self, stop_event, diming):

        self.crazy_alien_on = True
        self.crazy_alien_loop(stop_event, diming)
        '''
        print("Start CRAZY ALIEBBNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")
        # time.sleep()
        self.crazy_alien_running = True
        self.thread_running = None

        try:
            self.thread_running = _thread.start_new_thread(self.crazy_alien_on, ())

        except:

            time.sleep_ms(70)
            self.start()


        return True
        '''

    def stop(self):
        self.crazy_alien_on = False
        self.crazy_alien_off()
        self.np.deinit()
        '''
        self.crazy_alien_running = False

        # self.thread_mid.exit()

        try:
            _thread.exit()
        except:
            pass

        if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            self.thread_running.exit()

        self.crazy_alien_off()
        '''
    def crazy_alien_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.crazy_alien_on


#crazy_alien = Crazy_alien(False)
#stop_event = multiprocessing.Event()
#diming  = True
#crazy_alien.start(stop_event, diming)

#time.sleep(1)
# funktioniert
