import threading
import time

class MyClass:
    # Klassenattribut
    class_attr = 0

    def update_class_attr(self):
        for _ in range(5):
            # Lock verwenden, um auf das Klassenattribut zuzugreifen und es zu aktualisieren
            with MyClass.lock:
                MyClass.class_attr += 1
            time.sleep(1)

# Erstellen Sie ein Lock, um den Zugriff auf das Klassenattribut zu synchronisieren
MyClass.lock = threading.Lock()

# Erstellen Sie eine Instanz der Klasse
my_instance = MyClass()

# Thread, um das Klassenattribut zu aktualisieren
update_thread = threading.Thread(target=my_instance.update_class_attr)

# Starten Sie den Thread
update_thread.start()

# Warten Sie auf den Abschluss des Threads
update_thread.join()

# Drucken Sie den aktualisierten Wert des Klassenattributs
print("Aktualisierter Wert des Klassenattributs:", MyClass.class_attr)