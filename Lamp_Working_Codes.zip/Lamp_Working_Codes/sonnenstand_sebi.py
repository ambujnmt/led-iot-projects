# todo set azimuth and elevation -- done
# todo everything in class

import board
import ephem
from datetime import datetime, timedelta
import pytz  # Importiere pytz
import busio
from adafruit_bus_device.i2c_device import I2CDevice

from compass_test_sebi import Magnetometer, set_heading
from rotation_motor_control import Rotation_MotorControl



def get_solar_position(latitude, longitude, date_time):
    observer = ephem.Observer()
    observer.lat = str(latitude)
    observer.lon = str(longitude)

    # Setze Datum und Uhrzeit in der Zeitzone UTC
    observer.date = date_time

    # Berechne die Position der Sonne
    sun = ephem.Sun(observer)
    azimuth = sun.az * 180 / ephem.pi  # Konvertiere Azimut von Radiant zu Grad
    elevation = sun.alt * 180 / ephem.pi  # Konvertiere Elevation von Radiant zu Grad

    return azimuth, elevation

def increase_by_one_minute(date_time):
    # Erhöhe die Zeit um 1 Minute
    new_time = date_time + timedelta(minutes=1)

    return new_time


def set_azimuth_elevation():
    latitude = 48.37384  # Beispiel: Breitengrad von GPS auslesen
    longitude = 10.89207  # Beispiel: Längengrad von GPS auslesen
    current_datetime = datetime.now()
    azimuth, elevation = get_solar_position(latitude, longitude, current_datetime)
    return azimuth, elevation


def main():
    # lampe auf Norden stellen
    # set_north()
    # Aktuelle Position und Uhrzeit
    # benötige Kompass, um Norden zu bestimmen
    # wenn Elevation < 0, dann Nacht -> Tracking aus und LEDs an

    motor = Rotation_MotorControl(board.D10, board.D24, board.D11)
    heading = set_heading()


    latitude = 48.37384  # Beispiel: Breitengrad von GPS auslesen
    longitude = 10.89207  # Beispiel: Längengrad von GPS auslesen

    # Setze die Zeitzone auf UTC+1
    timezone = pytz.timezone('Europe/Berlin')

    # Aktuelle Zeit in UTC
    current_datetime_utc = datetime.utcnow()

    # Konvertiere die Zeit in die gewünschte Zeitzone
    current_datetime = current_datetime_utc.replace(tzinfo=pytz.utc).astimezone(timezone)

    # Azimut und Elevation berechnen
    azimuth, elevation = get_solar_position(latitude, longitude, current_datetime)

    angle = 0
    azimuth_dif = azimuth
    azi_count = 1
    motor.run(int(azimuth), 50)

    while elevation > 0:
        current_datetime = increase_by_one_minute(current_datetime)
        azimuth, elevation = get_solar_position(latitude, longitude, current_datetime)
        azimuth_onoff = azimuth - azimuth_dif
        print("Azi_onoff  ", azimuth_onoff)
        print("Azimuth:  ", azimuth)
        print(current_datetime.strftime('%Y/%m/%d %H:%M:%S %Z'))
        if azimuth_onoff >= azi_count:
            # motor.run(angle + 1, 50)
            angle = angle + 1
            azi_count = azi_count + 1
            print("Angle:  ", angle)
            print("azi_count:   ", azi_count)
    # while elevation > 0:
    #     current_datetime = increase_by_one_minute(current_datetime)
    #     azimuth, elevation = get_solar_position(latitude, longitude, current_datetime)
    #     print(current_datetime.strftime('%Y/%m/%d %H:%M:%S %Z'))  # Gib die Zeit in der gewünschten Zeitzone aus
    #     # Hier kannst du weitere Aktionen durchführen, solange die Elevation größer als 0 ist
    #
    #
    #     print(f"Der Azimut der Sonne beträgt {azimuth:.2f} Grad.")
    #     print(f"Die Elevation der Sonne beträgt {elevation:.2f} Grad.")
    print(f"Sonnenuntergang um  {current_datetime.strftime('%Y/%m/%d %H:%M:%S %Z')} Uhr.")

if __name__ == "__main__":
    main()
