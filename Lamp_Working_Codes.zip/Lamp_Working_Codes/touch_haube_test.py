import board
import busio
import digitalio
import time
from i2c_devices_new.at42qt.odt_at42qt1050 import AT42QT1070
# Initialize I2C and sensor
# Initialize I2C and sensor
i2c = busio.I2C(board.SCL, board.SDA)
qtouch = AT42QT1070(i2c, address=0x41)

# Setup for CHANGE pin (adapt to your pin setup)
CHANGE_PIN = 20
touch = digitalio.DigitalInOut(board.D20)
touch.direction = digitalio.Direction.INPUT
touch.pull = digitalio.Pull.DOWN

# Variables for touch detection logic
last_touch_time = 0
touch_sequence = []
debounce_time = 0.3  # Adjust debounce time as needed
min_touch_duration = 0.3  # Minimum duration for a touch to be considered valid
long_press_threshold = 2.0  # Adjust based on how you define a long press
double_touch_max_interval = 0.5  # Maximum interval between touches for a double touch

def process_touch_sequence(touch_sequence):
    # This function processes the sequence of touches to determine the action
    if len(touch_sequence) == 1:
        touch_type = touch_sequence[0]
        if touch_type == 'long':
            print("long")
            # Handle long press here (toggle LED on/off)
            pass
        elif touch_type == 'short':
            print("short")
            # Handle single short press here (next program)
            pass
    elif len(touch_sequence) == 2:
        first_touch, second_touch = touch_sequence
        if first_touch in ['short', 'long'] and second_touch in ['short', 'long']:
            print("double")
            # Handle double touch here (previous program, dimming)
            # This now only triggers for combinations of short+short, short+long, or long+long
            pass
    # Reset touch sequence after processing
    touch_sequence.clear()

while True:
    if qtouch.this_key_touched(0):
        current_time = time.time()
        if not last_touch_time or current_time - last_touch_time > debounce_time:
            touch_start = current_time
            while qtouch.this_key_touched(0):  # Wait for the touch to end
                time.sleep(0.01)
            touch_duration = time.time() - touch_start
            if touch_duration >= long_press_threshold:
                touch_sequence.append('long')
            elif touch_duration >= min_touch_duration:
                touch_sequence.append('short')
            last_touch_time = current_time

    # Check for sequence processing
    if touch_sequence and (time.time() - last_touch_time > double_touch_max_interval):
        process_touch_sequence(touch_sequence)

    time.sleep(0.1)
