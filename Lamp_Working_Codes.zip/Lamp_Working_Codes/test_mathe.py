
print(-9 - -21)
