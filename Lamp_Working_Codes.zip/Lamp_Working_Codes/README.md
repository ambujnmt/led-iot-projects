## To do: etwas doku
 1. paar Funktionen zusammenfassen etc