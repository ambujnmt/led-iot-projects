import json
import multiprocessing
import threading
import time

import schedule
from datetime import datetime
from led_programmliste import manager


# from led_programm_rainbow import RainbowLED
# testrainbow = RainbowLED(False)


class LaufzeitenScheduler():
    def __init__(self):
        self.whichlaufzeitrunning = 0

        self.triggerthread = None

        self.laufzeit1startjob = None
        self.laufzeit1startzeit = None
        self.laufzeit1endjob = None
        self.laufzeit1endzeit = None
        self.laufzeit1modus = None

        self.laufzeit2startjob = None
        self.laufzeit2startzeit = None
        self.laufzeit2endjob = None
        self.laufzeit2endzeit = None
        self.laufzeit2modus = None

        self.laufzeit3startjob = None
        self.laufzeit3startzeit = None
        self.laufzeit3endjob = None
        self.laufzeit3endzeit = None
        self.laufzeit3modus = None

        self.laufzeit4startjob = None
        self.laufzeit4startzeit = None
        self.laufzeit4endjob = None
        self.laufzeit4endzeit = None
        self.laufzeit4modus = None

        print("laufzeitscheduler wurde initialisiert")
        self.get_laufzeitenfromjson(True)

        self.set_scheduling()

    def start_programm(self, name, data):
        # loop = multiprocessing.Process(target=self.startschdulercheckloop)
        # loop.start()

        manager.start_named_program(name, data)

    def stop_programm(self):
        print("stop Programm aufgerufen!")
        time.sleep(1)
        # loop = multiprocessing.Process(target=self.startschdulercheckloop)
        # loop.start()
        manager.stop_demo()
        manager.stop_led_Process()

    def get_laufzeitenfromjson(self, startup=False, json_file="current_lampmodel.json", shared=0):
        if shared == 1:
            json_file="current_lampmodel_shared.json"
        print("get_laufzeitenfromjson getriggert")
        with open(json_file, "r") as f:
            data = json.load(f)

            self.laufzeit1startzeit = data["laufzeit1start"]
            self.laufzeit2startzeit = data["laufzeit2start"]
            self.laufzeit3startzeit = data["laufzeit3start"]
            self.laufzeit4startzeit = data["laufzeit4start"]

            self.laufzeit1endzeit = data["laufzeit1ende"]
            self.laufzeit2endzeit = data["laufzeit2ende"]
            self.laufzeit3endzeit = data["laufzeit3ende"]
            self.laufzeit4endzeit = data["laufzeit4ende"]

            self.laufzeit1modus = data["moduslaufzeit1"]
            self.laufzeit2modus = data["moduslaufzeit2"]
            self.laufzeit3modus = data["moduslaufzeit3"]
            self.laufzeit4modus = data["moduslaufzeit4"]
            print(
                "Laufzeit1: ",
                self.laufzeit1startzeit,
                self.laufzeit1endzeit,
                self.laufzeit1modus,
                "Lautzeit2: ",
                self.laufzeit2startzeit,
                self.laufzeit2endzeit,
                self.laufzeit2modus,
                "Laufzeit3: ",
                self.laufzeit3startzeit,
                self.laufzeit3endzeit,
                self.laufzeit3modus,
                "Laufzeit4: ",
                self.laufzeit4startzeit,
                self.laufzeit4endzeit,
                self.laufzeit4modus,
            )

        if startup == True:
            shouldstartup1 = self.is_time_between(self.laufzeit1startzeit, self.laufzeit1endzeit)
            shouldstartup2 = self.is_time_between(self.laufzeit2startzeit, self.laufzeit2endzeit)
            shouldstartup3 = self.is_time_between(self.laufzeit3startzeit, self.laufzeit3endzeit)
            shouldstartup4 = self.is_time_between(self.laufzeit4startzeit, self.laufzeit4endzeit)

            if shouldstartup1:
                print("Laufzeit1 sollte gestartet werden")
                manager.start_named_program(self.laufzeit1modus, data)
                self.whichlaufzeitrunning = 1
            if shouldstartup2:
                print("Laufzeit2 sollte gestartet werden")
                manager.start_named_program(self.laufzeit2modus, data)
                self.whichlaufzeitrunning = 2
            if shouldstartup3:
                print("Laufzeit3 sollte gestartet werden")
                manager.start_named_program(self.laufzeit3modus, data)
                self.whichlaufzeitrunning = 3
            if shouldstartup4:
                print("Laufzeit4 sollte gestartet werden")
                manager.start_named_program(self.laufzeit4modus, data)
                self.whichlaufzeitrunning = 4

    # checkt ob ein LED Programm bereits laufen soll und returned entsprechend True oder False
    def is_time_between(self, start_time: str, end_time: str) -> bool:
        if start_time == "--:--" or end_time == "--:--":
            return False
        # Konvertiert die String-Zeiten in datetime.time Objekte
        start_time_obj = datetime.strptime(start_time, "%H:%M").time()
        end_time_obj = datetime.strptime(end_time, "%H:%M").time()
        current_time = datetime.now().time()
        # Wenn die Endzeit kleiner ist als die Startzeit, geht der Zeitraum über Mitternacht
        if end_time_obj < start_time_obj:
            return current_time >= start_time_obj or current_time <= end_time_obj
        else:
            return start_time_obj <= current_time <= end_time_obj

    def set_scheduling(self, shared=0):
        self.get_laufzeitenfromjson(shared=shared)
        json_path = "current_lampmodel.json"
        if shared == 1:
            json_path = "current_lampmodel_shared.json"

        alljobs = self.getallJobList()

        for job in alljobs:
            print("Job gefunden: ", job)
            if type(job) == schedule.Job:
                print("Jobs zum deinitialiseren gefunden: ", job)
                schedule.cancel_job(job)

        print("scheduler set scheduling getriggert!")
        time.sleep(0.1)
        with open(json_path, "r") as data:
            print("laufzeit1 bedingung zum setzen erreicht")
            if self.laufzeit1startzeit != "--:--" and self.laufzeit1endzeit != "--:--" and self.laufzeit1modus != "-":
                print("laufzeit1 bedingung zum setzen erfüllt")
                print(self.laufzeit1startzeit)
                self.laufzeit1startjob = schedule.every().day.at(self.laufzeit1startzeit).do(self.start_programm,
                                                                                             self.laufzeit1modus, data)
                self.laufzeit1endjob = schedule.every().day.at(self.laufzeit1endzeit).do(self.stop_programm)
            else:
                if self.laufzeit1startjob is not None:
                    schedule.cancel_job(self.laufzeit1startjob)
                if self.laufzeit1endjob is not None:
                    schedule.cancel_job(self.laufzeit1endjob)

            if self.laufzeit2startzeit != "--:--" and self.laufzeit2endzeit != "--:--" and self.laufzeit2modus != "-":
                self.laufzeit2startjob = schedule.every().day.at(self.laufzeit2startzeit).do(
                    manager.start_named_program, self.laufzeit2modus, data)
                self.laufzeit2endjob = schedule.every().day.at(self.laufzeit2endzeit).do(manager.stop_led_Process)
            else:
                if self.laufzeit2startjob is not None:
                    schedule.cancel_job(self.laufzeit2startjob)
                if self.laufzeit2endjob is not None:
                    schedule.cancel_job(self.laufzeit2endjob)

            if self.laufzeit3startzeit != "--:--" and self.laufzeit3endzeit != "--:--" and self.laufzeit3modus != "-":
                self.laufzeit3startjob = schedule.every().day.at(self.laufzeit3startzeit).do(
                    manager.start_named_program, self.laufzeit3modus, data)
                print("laufzeit3 endzeit: ", self.laufzeit3endzeit)
                self.laufzeit3endjob = schedule.every().day.at(self.laufzeit3endzeit).do(manager.stop_led_Process)
            else:
                if self.laufzeit3startjob is not None:
                    schedule.cancel_job(self.laufzeit3startjob)
                if self.laufzeit2endjob is not None:
                    schedule.cancel_job(self.laufzeit3endjob)

            if self.laufzeit4startzeit != "--:--" and self.laufzeit4endzeit != "--:--" and self.laufzeit4modus != "-":
                self.laufzeit4startjob = schedule.every().day.at(self.laufzeit4startzeit).do(
                    manager.start_named_program, self.laufzeit4modus, data)
                self.laufzeit4endjob = schedule.every().day.at(self.laufzeit4endzeit).do(manager.stop_led_Process)
            else:
                if self.laufzeit4startjob is not None:
                    schedule.cancel_job(self.laufzeit4startjob)
                if self.laufzeit4endjob is not None:
                    schedule.cancel_job(self.laufzeit4endjob)

    print("Aktuelle Uhrzeit: ", datetime.now())

    def showallscheduledjobs(self):
        for job in schedule.get_jobs():
            print("Job: ", job)

    def startschdulercheckloop(self):
        while True:
            try:
                # print("Testwert laufzeit1job: " , self.laufzeit1startjob)
                # print("check loop scheduler running")
                schedule.run_pending()
                # self.showallscheduledjobs()
                time.sleep(1)
            except Exception as e:
                print("exception abgefangen: ", e)

    def getallJobList(self):
        return [
            self.laufzeit1startjob,
            self.laufzeit1endjob,
            self.laufzeit2startjob,
            self.laufzeit2endjob,
            self.laufzeit3startjob,
            self.laufzeit3endjob,
            self.laufzeit4startjob,
            self.laufzeit4endjob,
        ]
