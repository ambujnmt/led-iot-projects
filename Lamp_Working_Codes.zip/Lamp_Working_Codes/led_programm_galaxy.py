#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time

import random
import gc


class Galaxy:
    def __init__(self, touchenabled):

        manager.add_programm(self)

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)

        #'Belegung ESP32 mehr Ram'

        self.PIN = board.D12 #18

        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23
        '''
        #'Belegung ESP32 mehr Ram'

        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23

        #Belegung ESP32 Platine

        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''

        # Define the colors
        self.DARKBLUELILA = [(80, 0, 250, 0)]

        self.ORANGE = [(255, 51, 0, 0)]
        self.NONE_COLOR = [(0, 0, 0, 0,)]




        self.galaxy_running = False
        self.thread_running = None

        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.galaxy_on = False

        print("Galaxy wurde initialisiert")

        self.init = True

        time.sleep(0.1)

    def np_top_array(self, position, value):

         self.np[position] = value

    def np_mid_array(self, position, value):

        #print("Position mid array: ", position)


        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value




    def galaxy_loop(self, stop_event, diming, change_timing = True):

        if diming:
           # self.DARKBLUELILA = [(40, 0, 125, 0)] 50% gedimmt
            #self.ORANGE  = [(128, 26, 0, 0)]
            #self.NONE_COLOR = [(0, 0, 0, 0)]

            # auf 25% gedimmt
            self.DARKBLUELILA = [(20, 0, 63, 0)]
            self.ORANGE = [(64, 13, 0, 0)]
            self.NONE_COLOR = (0, 0, 0, 0)

        gc.enable()

        if stop_event.is_set():
            self.stop()
            return


        r4 = 0
        r_bottom = 0
        star2 = 0
        star3 = 0
        star4 = 0
        star5 = 0

        brightness = 0.0
        brightness2 = 0.0
        brightness3 = 0.0
        brightness4 = 0.0
        brightness5 = 0.0




        switch_brightness = 0
        switch_brightness2 = 0
        switch_brightness3 = 0
        switch_brightness4 = 0
        switch_brightness5 = 0



        number1 = 0 # erstem Wassertropfen eine zufällige Zahl geben
        number2 = 1 # zweiten Wassertropfen eine zufällige Zahl geben
        number3 = 2 # drittem Wassertropfen eine zufällige Zahl geben
        number4 = 8
        number5 = 6
        number6 = 3

        array = [number1, number2, number3, number4, number5, number6]

        roundStar = 0
        roundStar2 = 0
        roundStar3 = 0
        roundStar4 = 0
        roundStar5 = 0


        star_two_running = False
        star_three_running = False
        star_four_running = False
        star_five_running = False



        count_number = 0

        '''
        if self.touchenabled:

             self.touch_threshold = self.touch_pin.read()
        '''

        self.paused = False


        while self.galaxy_on:



            '''
             #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''

            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue


            if change_timing == True:
                time.sleep(0.01)

            r4 = r4 + 1
            star2 = star2 + 1
            star3 = star3 + 1
            star4 = star4 + 1
            star5 = star5 + 1
            r_bottom = r_bottom + 1
            if(r4 == 1):


#                 # Activate other Stars:
#                 if brightness < 20.0:
#                     star_two_running = True
#                 if brightness < 40.0:
#                     star_three_running = True


                # STERN 1
                if brightness <= 0.0:
                    if roundStar == 2:
                        number1 = self.remove_and_replace_number(number1, array)
                        roundStar = 0

                    roundStar += 1
                    switch_brightness = 1

                if brightness == 100.0:
                    roundStar += 1
                    switch_brightness = 0

                if switch_brightness == 1:
                    brightness += 5.0
                else:
                    brightness -= 5.0


                # STERN 2
                if star2 == 20:
                    star_two_running = True
                if star_two_running == True:
                    if brightness2 <= 0.0:
                        if roundStar2 == 2:
                            number2 = self.remove_and_replace_number(number2, array)
                            roundStar2 = 0

                        roundStar2 += 1

                        switch_brightness2 = 1


                    if brightness2 == 100.0:
                        roundStar2 += 1
                        switch_brightness2 = 0

                    if switch_brightness2 == 1:
                        brightness2 += 5.0
                    else:
                        brightness2 -= 5.0

                        if brightness2 <= 0:
                            star2 = 0
                            star_two_running = False

                # STERN 3
                if star3 == 10:
                    star_three_running = True
                if star_three_running == True:
                    if brightness3 <= 0.0:
                        if roundStar3 == 2:
                            number3 = self.remove_and_replace_number(number3, array)
                            roundStar3 = 0

                        roundStar3 += 1
                        switch_brightness3 = 1


                    if brightness3 == 100.0:
                        roundStar3 += 1
                        switch_brightness3 = 0

                    if switch_brightness3 == 1:
                        brightness3 += 5.0
                    else:
                        brightness3 -= 5.0
                        if brightness3 <= 0:
                            star3 = 0
                            star_three_running = False

                # STERN 4
                if star4 == 25:
                    star_four_running = True
                if star_four_running == True:
                    if brightness4 <= 0.0:
                        if roundStar4 == 2:
                            number4 = self.remove_and_replace_number(number4, array)
                            roundStar4 = 0

                        roundStar4 += 1
                        switch_brightness4 = 1


                    if brightness4 == 100.0:
                        roundStar4 += 1
                        switch_brightness4 = 0

                    if switch_brightness4 == 1:
                        brightness4 += 2.0
                    else:
                        brightness4 -= 2.0

                        if brightness4 <= 0:
                            star4 = 0
                            star_four_running = False



                # STERN 5
                if star5 == 35:
                    star_five_running = True
                if star_five_running == True:
                    if brightness5 <= 0.0:
                        if roundStar5 == 2:
                            number5 = self.remove_and_replace_number(number5, array)
                            roundStar5 = 0

                        roundStar5 += 1

                        switch_brightness5 = 1


                    if brightness5 == 100.0:
                        roundStar5 += 1
                        switch_brightness5 = 0

                    if switch_brightness5 == 1:
                        brightness5 += 2.0
                    else:
                        brightness5 -= 2.0

                        if brightness5 <= 0:
                            star5 = 0
                            star_five_running = False


                if stop_event.is_set():
                    self.stop()
                    return

                if change_timing == True:
                    time.sleep(0.01)
                # TOP - LEDS
                self.np_top_array(0, self.DARKBLUELILA[0])
                self.np_top_array(1, self.DARKBLUELILA[0])
                self.np_top_array(2, self.DARKBLUELILA[0])
                self.np_top_array(3, self.DARKBLUELILA[0])
                self.np_top_array(4, self.DARKBLUELILA[0])
                self.np_top_array(5, self.DARKBLUELILA[0])
                self.np_top_array(6, self.DARKBLUELILA[0])
                self.np_top_array(7, self.DARKBLUELILA[0])
                self.np_top_array(8, self.DARKBLUELILA[0])
                self.np_top_array(9, self.DARKBLUELILA[0])


                # MID - LEDS
                self.np_mid_array(1, self.DARKBLUELILA[0])
                self.np_mid_array(2, self.DARKBLUELILA[0])
                self.np_mid_array(3, self.DARKBLUELILA[0])
                self.np_mid_array(4, self.DARKBLUELILA[0])
                self.np_mid_array(5, self.DARKBLUELILA[0])
                self.np_mid_array(6, self.DARKBLUELILA[0])
                self.np_mid_array(7, self.DARKBLUELILA[0])
                self.np_mid_array(8, self.DARKBLUELILA[0])
                self.np_mid_array(9, self.DARKBLUELILA[0])
                self.np_mid_array(10, self.DARKBLUELILA[0])
                self.np_mid_array(11, self.DARKBLUELILA[0])
                self.np_mid_array(12, self.DARKBLUELILA[0])
                self.np_mid_array(13, self.DARKBLUELILA[0])
                self.np_mid_array(14, self.DARKBLUELILA[0])
                self.np_mid_array(15, self.DARKBLUELILA[0])
                self.np_mid_array(16, self.DARKBLUELILA[0])
                self.np_mid_array(17, self.DARKBLUELILA[0])
                self.np_mid_array(18, self.DARKBLUELILA[0])
                self.np_mid_array(19, self.DARKBLUELILA[0])
                self.np_mid_array(20, self.DARKBLUELILA[0])
                self.np_mid_array(21, self.DARKBLUELILA[0])
                self.np_mid_array(22, self.DARKBLUELILA[0])
                self.np_mid_array(23, self.DARKBLUELILA[0])
                self.np_mid_array(24, self.DARKBLUELILA[0])
                self.np_mid_array(25, self.DARKBLUELILA[0])
                self.np_mid_array(26, self.DARKBLUELILA[0])
                self.np_mid_array(27, self.DARKBLUELILA[0])
                self.np_mid_array(28, self.DARKBLUELILA[0])
                self.np_mid_array(29, self.DARKBLUELILA[0])
                self.np_mid_array(30, self.DARKBLUELILA[0])
                self.np_mid_array(31, self.DARKBLUELILA[0])
                self.np_mid_array(32, self.DARKBLUELILA[0])
                self.np_mid_array(33, self.DARKBLUELILA[0])
                self.np_mid_array(34, self.DARKBLUELILA[0])
                self.np_mid_array(35, self.DARKBLUELILA[0])
                self.np_mid_array(36, self.DARKBLUELILA[0])
                self.np_mid_array(37, self.DARKBLUELILA[0])
                self.np_mid_array(38, self.DARKBLUELILA[0])
                self.np_mid_array(39, self.DARKBLUELILA[0])
                self.np_mid_array(40, self.DARKBLUELILA[0])
                self.np_mid_array(41, self.DARKBLUELILA[0])
                self.np_mid_array(42, self.DARKBLUELILA[0])
                self.np_mid_array(43, self.DARKBLUELILA[0])
                self.np_mid_array(44, self.DARKBLUELILA[0])
                self.np_mid_array(45, self.DARKBLUELILA[0])
                self.np_mid_array(46, self.DARKBLUELILA[0])
                self.np_mid_array(47, self.DARKBLUELILA[0])
                self.np_mid_array(48, self.DARKBLUELILA[0])
                self.np_mid_array(49, self.DARKBLUELILA[0])
                self.np_mid_array(50, self.DARKBLUELILA[0])
                self.np_mid_array(51, self.DARKBLUELILA[0])
                self.np_mid_array(52, self.DARKBLUELILA[0])
                self.np_mid_array(53, self.DARKBLUELILA[0])
                self.np_mid_array(54, self.DARKBLUELILA[0])
                self.np_mid_array(55, self.DARKBLUELILA[0])
                self.np_mid_array(56, self.DARKBLUELILA[0])
                self.np_mid_array(57, self.DARKBLUELILA[0])
                self.np_mid_array(58, self.DARKBLUELILA[0])
                self.np_mid_array(59, self.DARKBLUELILA[0])
                self.np_mid_array(60, self.DARKBLUELILA[0])
                self.np_mid_array(61, self.DARKBLUELILA[0])
                self.np_mid_array(62, self.DARKBLUELILA[0])
                self.np_mid_array(63, self.DARKBLUELILA[0])
                self.np_mid_array(64, self.DARKBLUELILA[0])
                self.np_mid_array(65, self.DARKBLUELILA[0])
                self.np_mid_array(66, self.DARKBLUELILA[0])
                self.np_mid_array(67, self.DARKBLUELILA[0])
                self.np_mid_array(68, self.DARKBLUELILA[0])
                self.np_mid_array(69, self.DARKBLUELILA[0])
                self.np_mid_array(70, self.DARKBLUELILA[0])
                self.np_mid_array(71, self.DARKBLUELILA[0])
                self.np_mid_array(72, self.DARKBLUELILA[0])
                self.np_mid_array(73, self.DARKBLUELILA[0])
                self.np_mid_array(74, self.DARKBLUELILA[0])
                self.np_mid_array(75, self.DARKBLUELILA[0])
                self.np_mid_array(76, self.DARKBLUELILA[0])
                self.np_mid_array(77, self.DARKBLUELILA[0])
                self.np_mid_array(78, self.DARKBLUELILA[0])
                self.np_mid_array(79, self.DARKBLUELILA[0])
                self.np_mid_array(80, self.DARKBLUELILA[0])
                self.np_mid_array(81, self.DARKBLUELILA[0])
                self.np_mid_array(82, self.DARKBLUELILA[0])
                self.np_mid_array(83, self.DARKBLUELILA[0])
                self.np_mid_array(84, self.DARKBLUELILA[0])
                self.np_mid_array(85, self.DARKBLUELILA[0])
                self.np_mid_array(86, self.DARKBLUELILA[0])
                self.np_mid_array(87, self.DARKBLUELILA[0])
                self.np_mid_array(88, self.DARKBLUELILA[0])
                self.np_mid_array(89, self.DARKBLUELILA[0])
                self.np_mid_array(90, self.DARKBLUELILA[0])
                self.np_mid_array(91, self.DARKBLUELILA[0])
                self.np_mid_array(92, self.DARKBLUELILA[0])
                self.np_mid_array(93, self.DARKBLUELILA[0])
                self.np_mid_array(94, self.DARKBLUELILA[0])
                self.np_mid_array(95, self.DARKBLUELILA[0])
                self.np_mid_array(96, self.DARKBLUELILA[0])
                self.np_mid_array(97, self.DARKBLUELILA[0])



                # erzeugt einen Stern, falls dieser mit z.b. "star_number_running" auf True gesetzt wurde
                self.mid_leds_on(number1, brightness,stop_event)
                if star_two_running == True:
                    self.mid_leds_on(number2, brightness2,stop_event)
                if star_three_running == True:
                    self.mid_leds_on(number3, brightness3,stop_event)
                if star_four_running == True:
                    self.mid_leds_on(number4, brightness4,stop_event)
                if star_five_running == True:
                    self.mid_leds_on(number5, brightness5,stop_event)


                if stop_event.is_set():
                    self.stop()
                    return


                if r_bottom == 5:
                    # Activate
                    self.bottom1_array(count_number, self.DARKBLUELILA[0])
                    self.bottom2_array(count_number, self.DARKBLUELILA[0])
                    self.bottom3_array(count_number, self.DARKBLUELILA[0])

                    # Deactivate
                    self.bottom_off_first(count_number)
                    self.bottom_off_second(count_number)
                    self.bottom_off_third(count_number)

                    count_number = count_number + 1
                    r_bottom = 0

                if count_number == 12:
                    self.bottom_off_first(11)
                    self.bottom_off_second(11)
                    self.bottom_off_third(11)
                    count_number = 0


                r4 = 0

            #self.checktouchinput()
            if stop_event.is_set():
                self.stop()
                return

            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()

            #print("Galaxy Leuchtprogramm hat funltionier :)")


    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    #@micropython.native
    def scale_color(self, color_tupel, brightness, stop_event):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)

        return (r, g, b, w)

    #@micropython.native
    def bottom_off_first(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom1_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom1_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom1_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom1_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom1_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom1_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom1_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom1_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom1_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom1_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom1_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom1_array(10, self.NONE_COLOR[0])


    #@micropython.native
    def bottom_off_second(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom2_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom2_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom2_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom2_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom2_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom2_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom2_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom2_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom2_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom2_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom2_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom2_array(10, self.NONE_COLOR[0])


    #@micropython.native
    def bottom_off_third(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom3_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom3_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom3_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom3_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom3_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom3_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom3_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom3_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom3_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom3_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom3_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom3_array(10, self.NONE_COLOR[0])





    def generateNewStart(self, brightness, switch_brightness, roundStar, number, array):
        if brightness <= 0.0:
            if roundStar == 2:
                number1 = self.remove_and_replace_number(number1, array)
                roundStar = 0
            roundStar += 1
            switch_brightness = 1

        if brightness == 100.0:
            roundStar += 1
            switch_brightness = 0

        if switch_brightness == 1:
            brightness += 2.0
        else:
            brightness -= 2.0


    #@micropython.native
    def remove_and_replace_number(self, number, array):
        # Prüfe, ob die Zahl im Array vorhanden ist
        if number in array:
            # Falls ja, entferne die Zahl aus dem Array
            array.remove(number)

        # Wähle eine neue Zahl zwischen 0 und 8, die nicht im Array vorhanden ist
        new_number = random.choice([i for i in range(9) if i not in array])
        array.append(new_number)

        # Gib die neue Zahl zurück
        return new_number

    #@micropython.native
    def mid_leds_on(self, number1, brightness, stop_event):
        if(number1 == 0):
            #self.np_mid[(96)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(97, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(0, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(1, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(2)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 1):
            #self.np_mid[(7)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(8, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(9, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(10, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(11)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 2):
            #self.np_mid[(17)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(18, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(19, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(20, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(21)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 3):
            #self.np_mid[(26)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(27, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(28, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(29, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(30)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 4):
            #self.np_mid[(37)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(38, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(39, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(40, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(41)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 5):
            #self.np_mid[(47)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(48, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(49, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(50, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(51)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 6):
            #self.np_mid[(57)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(58, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(59, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(60, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(61)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 7):
            #self.np_mid[(67)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(68, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(69, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(70, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(71)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 8):
            #self.np_mid[(78)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(79, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(80, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(81, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(82)] = self.scale_color(self.ORANGE[0], brightness)

        if(number1 == 9):
            #self.np_mid[(88)] = self.scale_color(self.ORANGE[0], brightness)
            self.np_mid_array(89, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(90, self.scale_color(self.ORANGE[0], brightness, stop_event))
            self.np_mid_array(91, self.scale_color(self.ORANGE[0], brightness, stop_event))
            #self.np_mid[(92)] = self.scale_color(self.ORANGE[0], brightness)

    def start(self, stop_event, diming):

        print("start Galaxy innerhalb Galaxy Klasse getrigget!")
        self.galaxy_on = True
        self.galaxy_loop(stop_event, diming)

        '''
        # time.sleep()
        self.galaxy_running = True
        self.thread_running = None

        try:
            self.thread_running = _thread.start_new_thread(self.galaxy_on, ())

        except:

            time.sleep_ms(70)
            self.start()


        return True
        '''

    def stop(self):
        self.galaxy_on = False
        self.galaxy_off()
        self.np.deinit()
        '''
        self.galaxy_running = False

        # self.thread_mid.exit()

        if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            self.thread_running.exit()

        self.galaxy_off()
        '''

    def galaxy_off(self):

        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.galaxy_on





#galaxy = Galaxy(False)
#stop_event = multiprocessing.Event()
#diming = True
#galaxy.start(stop_event, diming)
