from datetime import datetime
import suncalc
import numpy as np

# Beispielkoordinaten und aktuelle Zeit
lng, lat = 48.37384, 10.89207
date = datetime.now()


# Berechnung der Sonnenposition
position = suncalc.get_position(date, lng, lat)

# Umwandlung von Radiant in Grad
azimuth_degrees = position['azimuth'] * (180 / np.pi)
azimuth_degrees = azimuth_degrees % 360  # Anpassung auf 0-360 Grad

# Ausgabe
print("Azimuth in Grad:", azimuth_degrees)
print(date)
