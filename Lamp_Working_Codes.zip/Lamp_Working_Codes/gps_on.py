import RPi.GPIO as GPIO
import time

# GPIO-Pin festlegen
gps_power_pin = 21

# GPIO-Modus auf BCM setzen
GPIO.setmode(GPIO.BCM)

# GPIO-Pin als Ausgang konfigurieren
GPIO.setup(gps_power_pin, GPIO.OUT)

# GPS einschalten (Pin auf HIGH setzen)
GPIO.output(gps_power_pin, GPIO.HIGH)

# Wartezeit (in Sekunden), während das GPS einschaltet
time.sleep(1)

# Status des GPIO-Pins überprüfen
power_status = GPIO.input(gps_power_pin)

if power_status == GPIO.HIGH:
    print("GPS-Modul ist eingeschaltet (powered).")
else:
    print("GPS-Modul konnte nicht eingeschaltet werden.")

# Hier kannst du weitere Abfragen für dein GPS durchführen

# GPIO-Pin freigeben
GPIO.cleanup()
