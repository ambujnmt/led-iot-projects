import json

import multiprocessing
import threading
import time

from control_motor_interpreter import MotorInterpreter
from led_programm_pulsar import Pulsar
# from adafruit_mpr121_touch_sensor import Touchsteuerung
# from machine import TouchPad, Pin
from led_programm_rainy_days import RainyDays
from led_programm_rainbow import RainbowLED
from led_programm_benutzerdefiniert import Benutzerdefiniert
from led_programm_indigo_cure import Indigo_Cure
from led_programm_galaxy import Galaxy
from led_programm_sleeping_motion import SleepingMotion
from led_programm_xmas import Xmas
from led_programm_relax import Relax
from led_programm_earth import Earth
from led_programm_pulsar import Pulsar
from led_programm_crazy_alien import Crazy_alien

# from manual_rotation import stepper_motor
from led_programmliste import manager
from led_laufzeiten_scheduler import LaufzeitenScheduler

from SW_Button import SWButton

import gc

from shared_ressources import shared_resources

from control_bottom_button import ButtonHandler

from led_disable_on_day import Daylight_LED

from control_top_button import TouchHandler

gc.enable()


class LampConfig:
    def __init__(self, json_file, shouldtouchenable):

        self.motor_interpreter = MotorInterpreter()

        self.tracking_on = False

        self.stop_event = threading.Event()

        self.istrackingactive = None
        self.manager = manager

        self.touchenabled = False
        self.shouldtouchenable = shouldtouchenable
        self.stoptouch = False

        #### dieser wert wird benötigt um in der microdot heartbeat adresse zu informieren ob das aktuelle json file an die app zurück gesendet werden soll (z.b. bei lokaler steuerung der lampe)
        self.ischanged = False

        self.lampNumber = None
        self.lampName = None
        self.isRegistered = None

        self.modus = None
        self.ladestaerke = None
        self.isSolarPowered = None
        self.isGlowShowing = None
        self.isGlowAll = None
        self.isGlow1 = None
        self.isGlow2 = None
        self.isGlow3 = None
        self.dimmValue1 = None
        self.dimmValue2 = None
        self.dimmValue3 = None
        self.laufzeit1start = None
        self.laufzeit1ende = None
        self.laufzeit2start = None
        self.laufzeit2ende = None
        self.laufzeit3start = None
        self.laufzeit3ende = None
        self.laufzeit4start = None
        self.laufzeit4ende = None
        self.moduslaufzeit1 = None
        self.moduslaufzeit2 = None
        self.moduslaufzeit3 = None
        self.moduslaufzeit4 = None
        self.rotationSliderValue = None

        self.color1 = None
        self.color2 = None
        self.color3 = None

        # wie sollen die LED Programme initialisiert werden (mit aktivierter touchaube oder ohne?)
        if self.shouldtouchenable == True:
            # self.touchsteuerung = Touchsteuerung()
            self.benutzerdefiniert = Benutzerdefiniert(True)
            self.rainbow = RainbowLED(True)
            self.pulsar = Pulsar(True)
            self.crazy_alien = Crazy_alien(True)
            self.sleeping_motion = SleepingMotion(True)
            self.rainy_days = RainyDays(True)
            self.indigo_cure = Indigo_Cure(True)
            self.earth = Earth(True)
            self.relax = Relax(True)
            self.galaxy = Galaxy(True)
            self.xmas = Xmas(True)


        if self.shouldtouchenable == False:
            self.benutzerdefiniert = Benutzerdefiniert(False)
            self.rainbow = RainbowLED(False)
            self.pulsar = Pulsar(False)
            self.crazy_alien = Crazy_alien(False)
            self.sleeping_motion = SleepingMotion(False)
            self.rainy_days = RainyDays(False)
            self.indigo_cure = Indigo_Cure(False)
            self.earth = Earth(False)
            self.relax = Relax(False)
            self.galaxy = Galaxy(False)
            self.xmas = Xmas(False)

        # self.load_json_file(json_file)
        self.sw_button = SWButton(self.manager)
        self.button_controller = ButtonHandler(self.manager)
        self.touch_controller = TouchHandler(self.manager)
        self.scheduler = LaufzeitenScheduler()
        self.scheduler_thread = threading.Thread(target=self.scheduler.startschdulercheckloop)
        self.scheduler_thread.start()

        self.disable_by_daylight = Daylight_LED(self.manager)

        # self.sw_button.startbackgrounddetection()
        self.button_controller.startbackgrounddetection()
        # self.touch_controller.startbackgrounddetection() #deactivated for the moment because of bad hardware
        self.disable_by_daylight.start_background_check()
        # self.sw_button.startbackgroundbluetooth()
        # self.scheduler_multiprocess = multiprocessing.Process(target=self.scheduler.startschdulercheckloop)
        # self.scheduler_multiprocess.daemon(False)
        # self.scheduler_multiprocess.start()

    def is_changed(self):
        return self.ischanged

    def set_changed_back_to_false(self):
        self.ischanged = False

    def try_start_modus(self, modus, data):
        try:
            self.manager.start_named_program(modus, data)
        except Exception as e:
            print(e)

    def stop_led_Process(self):

        manager.stop_led_Process()

    def load_json_data(self, data, shared=0):

        self.stoptouch = True

        # sonderfall da benutzerdefiniert neu ausgeführt werden muss wenn sich dimmvalue oder Colorvalue ändern auch wenn
        # Benutzerdefiniert bereits ausgewählt ist

        # 1. Fall Modus wurde in der App gewchselt und Leuchten ist aktiv:
        if self.modus == data["modus"] == "Demo" and data["isGlowShowing"] == "false":
            manager.stop_demo()
            print("load_json_data triggered stop demo im manager")

        elif self.modus != data["modus"] and data["isGlowShowing"] == "true":

            print("Moduswechsel getriggert!")

            # erstmal checken ob andere Modies laufen und diese beenden
            # self.try_stop_all_other_modes(data["modus"])

            # aktuell laufenden LED multiprocess beenden wenn dieser läuft
            self.stop_led_Process()
            manager.stop_demo()

            self.try_start_modus(data["modus"], data)




        # Fall 2 Modus wurde nicht geändert aber das anschalten getriggert:

        elif data["isGlowShowing"] == "true":

            print("Anschalten getriggert!")

            self.try_start_modus(data["modus"], data)

            # self.stoptouch = True


        # Fall 3 Modus wurde nicht geändert aber das ausschalten getriggert

        elif data["isGlowShowing"] == "false" and data["istrackingactive"] == "false":
            print("Ausschalten getriggert!")
            self.stop_led_Process()
            # self.try_stop_all_other_modes("")

            # TODO hier ensteht ein fehler sodas das ganze programm abstützt kp warum!

        # Tracking aktivieren
        if data["istrackingactive"] == "true":
            if not self.motor_interpreter.tracking_on:
                shared_resources.stop_event.clear()
                self.motor_interpreter.load_settings()
                self.motor_interpreter.start_sun_tracking()
            if data["isGlowShowing"] == "false":
                self.stop_led_Process()

            # print("-------------------------------------")
            # print("-------------------------------------")
            # print("--------DEBUG TRACKING ON------------")
            # print("-------------------------------------")
            # print("-------------------------------------")

        # Tracking deaktivieren
        elif data["istrackingactive"] == "false":
            self.motor_interpreter.stop_sun_tracking()
            self.motor_interpreter.tracking_on = False
            # print("-------------------------------------")
            # print("-------------------------------------")
            # print("--------DEBUG TRACKING OFF-----------")
            # print("-------------------------------------")
            # print("-------------------------------------")

        # plathalter um funktion hier einzufügen

        self.lampNumber = data["lampNumber"]
        self.lampName = data["lampName"]
        self.isRegistered = data["isRegistered"]

        self.modus = data["modus"]
        self.ladestaerke = data["ladestaerke"]
        self.isSolarPowered = data["isSolarPowered"]
        self.isGlowShowing = data["isGlowShowing"]
        self.isGlowAll = data["isGlowAll"]
        self.isGlow1 = data["isGlow1"]
        self.isGlow2 = data["isGlow2"]
        self.isGlow3 = data["isGlow3"]
        self.dimmValue1 = data["dimmValue1"]
        self.dimmValue2 = data["dimmValue2"]
        self.dimmValue3 = data["dimmValue3"]
        self.laufzeit1start = data["laufzeit1start"]
        self.laufzeit1ende = data["laufzeit1ende"]
        self.laufzeit2start = data["laufzeit2start"]
        self.laufzeit2ende = data["laufzeit2ende"]
        self.laufzeit3start = data["laufzeit3start"]
        self.laufzeit3ende = data["laufzeit3ende"]
        self.laufzeit4start = data["laufzeit4start"]
        self.laufzeit4ende = data["laufzeit4ende"]
        self.moduslaufzeit1 = data["moduslaufzeit1"]
        self.moduslaufzeit2 = data["moduslaufzeit2"]
        self.moduslaufzeit3 = data["moduslaufzeit3"]
        self.moduslaufzeit4 = data["moduslaufzeit4"]
        self.rotationSliderValue = data["rotationSliderValue"]
        self.istrackingactive = data["istrackingactive"]

        self.color1 = data["color1"]
        self.color2 = data["color2"]
        self.color3 = data["color3"]

        print(self.isGlowShowing)
        print(self.modus)

        gc.collect()

        # self.save_json_file(data)
        # time.sleep(1)
        if shared == 1:
            self.scheduler.set_scheduling(shared=shared)
        else:
            self.scheduler.set_scheduling()

    # Diese methode wird beim hochfahren der Lampe verwendet um den letzten zustand wiederherzustellen
    def load_json_file(self, filename):

        data = None

        gc.collect()
        with open(filename, "r") as f:
            data = json.load(f)

            # sonderfall da benutzerdefiniert neu ausgeführt werden muss wenn sich dimmvalue oder Colorvalue ändern auch wenn
        # Benutzerdefiniert bereits ausgewählt ist

        gc.collect()

        # sonderfall da benutzerdefiniert neu ausgeführt werden muss wenn sich dimmvalue oder Colorvalue ändern auch wenn
        # Benutzerdefiniert bereits ausgewählt ist

        # 1. Fall Modus wurde in der App gewchselt und Leuchten ist aktiv:
        '''

        if self.modus != data["modus"] and data["isGlowShowing"] == "true":

            print("Moduswechsel getriggert!")

            # erstmal checken ob andere Modies laufen und diese beenden
            self.try_stop_all_other_modes(data["modus"])

            self.try_start_modus(data["modus"], data)


        # Fall 2 Modus wurde nicht geändert aber das anschalten getriggert:

        elif data["isGlowShowing"] == "true":

            print("Anschalten getriggert!")

        #sonderfall benutzerdefiniert da der modus neu getriggert werden soll wenn sich auch der Farbwert ändert oder dimm value
            if self.modus == "Benutzerdefiniert":
                self.update_benutzerdefiniert(data)

            else:

                self.try_start_modus(data["modus"], data)


        # Fall 3 Modus wurde nicht geändert aber das ausschalten getriggert

        elif data["isGlowShowing"] == "false":
            print("Ausschalten getriggert!")
            self.try_stop_all_other_modes("")
        '''

        # Rotation wird aktiviert/deaktiviert

        '''
        if data["rotationSliderValue"] != "0.0":
            try:
                if not stepper_motor.get_is_running():
                    stepper_motor.start(float(data["rotationSliderValue"]))

                else:
                    stepper_motor.update(float(data["rotationSliderValue"]))
            except:pass


        elif data["rotationSliderValue"] == "0.0":

            try:stepper_motor.stop()
            except:pass
        '''

        self.lampNumber = data["lampNumber"]
        self.lampName = data["lampName"]
        self.isRegistered = data["isRegistered"]

        self.modus = data["modus"]
        self.ladestaerke = data["ladestaerke"]
        self.isSolarPowered = data["isSolarPowered"]
        self.isGlowShowing = data["isGlowShowing"]
        self.isGlowAll = "false"
        self.isGlow1 = "false"
        self.isGlow2 = "false"
        self.isGlow3 = "false"
        self.dimmValue1 = data["dimmValue1"]
        self.dimmValue2 = data["dimmValue2"]
        self.dimmValue3 = data["dimmValue3"]
        self.laufzeit1start = data["laufzeit1start"]
        self.laufzeit1ende = data["laufzeit1ende"]
        self.laufzeit2start = data["laufzeit2start"]
        self.laufzeit2ende = data["laufzeit2ende"]
        self.laufzeit3start = data["laufzeit3start"]
        self.laufzeit3ende = data["laufzeit3ende"]
        self.laufzeit4start = data["laufzeit4start"]
        self.laufzeit4ende = data["laufzeit4ende"]
        self.moduslaufzeit1 = data["moduslaufzeit1"]
        self.moduslaufzeit2 = data["moduslaufzeit2"]
        self.moduslaufzeit3 = data["moduslaufzeit3"]
        self.moduslaufzeit4 = data["moduslaufzeit4"]
        self.rotationSliderValue = data["rotationSliderValue"]

        self.color1 = data["color1"]
        self.color2 = data["color2"]
        self.color3 = data["color3"]

        print(self.isGlowShowing)
        print(self.modus)

        # self.save_json_file()

        if self.shouldtouchenable == True:
            while self.touchenabled == False:

                try:
                    print("Versuche touchdetection im lampmodelinterpreter zu starten....")

                    _thread.start_new_thread(self.simple_touch_detection, (data,))
                    print("checktouch im interpreter wird ausgeführt")
                    time.sleep_ms(100)

                except Exception as e:
                    print("Fehler konnte Touchdetectionthread nicht starten, Exception: ", e)
                    pass

    def save_json_file(self, data):

        '''
        data = {
            "lampNumber": self.lampNumber,
            "lampName": self.lampName,
            "isRegistered": self.isRegistered,
            "modus": self.modus,
            "ladestaerke": self.ladestaerke,
            "isSolarPowered": self.isSolarPowered,
            "isGlowShowing": self.isGlowShowing,
            "isGlowAll": self.isGlowAll,
            "isGlow1": self.isGlow1,
            "isGlow2": self.isGlow2,
            "isGlow3": self.isGlow3,
            "dimmValue1": self.dimmValue1,
            "dimmValue2": self.dimmValue2,
            "dimmValue3": self.dimmValue3,
            "laufzeit1start": self.laufzeit1start,
            "laufzeit1ende": self.laufzeit1ende,
            "laufzeit2start": self.laufzeit2start,
            "laufzeit2ende": self.laufzeit2ende,
            "laufzeit3start": self.laufzeit3start,
            "laufzeit3ende": self.laufzeit3ende,
            "laufzeit4start": self.laufzeit4start,
            "laufzeit4ende": self.laufzeit4ende,
            "moduslaufzeit1": self.moduslaufzeit1,
            "moduslaufzeit2": self.moduslaufzeit2,
            "moduslaufzeit3": self.moduslaufzeit3,
            "moduslaufzeit4": self.moduslaufzeit4,
            "rotationSliderValue": self.rotationSliderValue,
            "color1": self.color1,
            "color2": self.color2,
            "color3": self.color3,
        }
        '''

        with open("current_lampmodel.json", "w") as f:
            json.dump(data, f, indent=4)

    def simple_touch_detection(self, data):

        self.touchenabled = True

        print("wert für self.touchenabled: ", self.touchenabled)

        while self.touchenabled:

            self.checktouch()

            if self.stoptouch == True:
                self.touchenabled = False
                return

        time.sleep_ms(200)

        if self.touchenabled == False:

            try:
                print("Versuche Modus durch touch im interpreter zu starten: ", data["modus"])
                self.try_start_modus(data["modus"], data)

            except Exception as e:

                print("Fehler in Touchklasse try_start_modus: ", e)
                print(data["modus"])

            time.sleep(0.020)
            try:
                _thread.exit()

            except Exception as e:
                print("Touchdetectionthread im interpreter konnte nicht beendet werden: ", e)
                pass

            print("Touchdetectionthread im interpreter sollte sauber beendet worden sein")

            return

    def checktouch(self):

        touchvalue = self.touch.read()

        if touchvalue < self.touch_threshold - 20 or touchvalue > self.touch_threshold + 20:

            counter = 0
            touchcounter = 0

            while counter < 15:

                touchvalue = self.touch.read()
                if touchvalue < self.touch_threshold - 20 or touchvalue > self.touch_threshold + 20:
                    touchcounter = touchcounter + 1

                counter = counter + 1

                time.sleep_ms(20)

            if touchcounter > 12:
                print("touch erkannt, deaktiviere touchinput da LED Programm touch übernimmt")
                self.touchenabled = False

                print("Touch in Lampmodel interpreter erkannt")
                self.touchenabled = False



            else:
                print("Kein Sauberen Touch erkannt, nichts soll passieren!")


gc.enable()

'''
# Testen, ob die Variablen korrekt zugewiesen wurden
print("lampNumber:", lamp_config.lampNumber)
print("lampName:", lamp_config.lampName)
print("isRegistered:", lamp_config.isRegistered)
print("Color1", lamp_config.color1)
print("Color2", lamp_config.color2)
print("Color3", lamp_config.color3)
# Fügen Sie weitere print-Anweisungen für andere Variablen hinzu

'''
