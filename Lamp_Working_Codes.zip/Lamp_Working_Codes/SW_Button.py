import gc
import json
import multiprocessing
import os

import board
import digitalio
import time

# from led_programme_lukas_timing_angepasst.led_programm_crazy_alien import Crazy_alien
# # from led_programme_lukas_timing_angepasst.led_programm_earth import Earth
# from led_programme_lukas_timing_angepasst.led_programm_galaxy import Galaxy
# from led_programme_lukas_timing_angepasst.led_programm_indigo_cure import Indigo_Cure
# from led_programme_lukas_timing_angepasst.led_programm_rainbow import RainbowLED
# from led_programme_lukas_timing_angepasst.led_programm_rainy_days import RainyDays
# from led_programme_lukas_timing_angepasst.led_programm_relax import Relax
# from led_programme_lukas_timing_angepasst.led_programm_sleeping_motion import SleepingMotion
# from led_programme_lukas_timing_angepasst.led_programm_xmas import Xmas

'''
from led_programm_crazy_alien import Crazy_alien
from led_programm_rainbow import RainbowLED
from led_programm_xmas import Xmas

'''


class SWButton:

    def __init__(self, manager=None):

        self.manager = manager
        self.button = digitalio.DigitalInOut(
            board.D26)  # Ersetzen Sie D17 durch den tatsächlichen Pin, an den Ihr Button angeschlossen ist
        self.button.direction = digitalio.Direction.INPUT
        self.button.pull = digitalio.Pull.UP  # Aktiviert den internen Pull-Up-Widerstand
        self.buttonwaspressed = False

        script_dir = os.path.dirname(os.path.realpath(__file__))
        self.json_filename_lamp = os.path.join(script_dir, 'current_lampmodel.json')

        # led im button

        self.led = digitalio.DigitalInOut(board.D16)
        self.led.direction = digitalio.Direction.OUTPUT

        self.led.value = 1

        # Neue Variablen
        self.debounce_time = 0.01  # Entprellzeit in Sekunden
        self.threshold = 1  # Anzahl der benötigten aufeinanderfolgenden Erkennungen
        self.counter = 0  # Zählt, wie oft der Button gedrückt wurde
        self.totalcounter = 0
        self.zerocounter = 0
        self.zerocounterthreshold = 2

        # benötigt um non blocking schleife zu ermöglichen
        self.multiprocess = None
        self.stopevent = multiprocessing.Event()

        # benötigt um zu tracken, ob ein led programm vorher pausiert wurde
        # um entsprechnd start bei Wiedeholung zu triggern
        self.waspaused = False

        self.btbuttonwaspressed = False

    def startbackgrounddetection(self):
        self.multiprocess = multiprocessing.Process(target=self.checkloop, args=(self.stopevent,))
        self.multiprocess.start()

    def stopbackgrounddetection(self):
        self.stopevent.set()


    # Basismethode um Buttonpress zu interpretieren
    def checkbuttoninput(self):

        if self.button.value != 0:
            # print("Buttonerkannt")# Wenn der Button gedrückt wird
            self.counter += 1
            # print("Buttonvalue ist 1")

            if self.counter >= self.threshold:
                self.buttonwaspressed = True
                self.totalcounter += 1
                # print("Button wurde gedrückt, counter:", self.totalcounter)
                self.counter = 0  # Counter zurücksetzen
                time.sleep(self.debounce_time)  # Entprellen
                return True

        elif self.button.value == 1:
            self.zerocounter += 1

        if self.zerocounter >= self.zerocounterthreshold:
            self.counter = 0
            self.zerocounter = 0

    # Funktion um verschiedene Touch-Gestiken zu erkennnen
    def gesturedetection(self):

        if self.checkbuttoninput():
            print("Touch erkannt")
            print("prüfe ob gehalten wird")

            # Kein Langes halten erkannt
            if not self.checkhold():
                # print("checkhold1 ist false")
                # print("Prüfe ob 2 kurzer touch ankommt")

                secondgesture = self.checksecondtouch()
                if secondgesture == 'hold':
                    print("Debugging, 2. touch hold erkannt OLD")
                    # self.dimming()
                    # time.sleep(0.01)
                elif secondgesture == 'short':
                    print("Debugging, 2. kurzer Tap erkannt OLD")
                    # self.previousprogramm()
                    # time.sleep(0.01)
                elif secondgesture == 'none':
                    print("Debugging, kein 2. Tap erkannt, einfacherer Tap OLD")
                    # self.nextprogramm()
                    # time.sleep(0.01)

                # wenn kein langes halten bei erster berührung dann prüfen ob ein
                # 2. mal berührt wird um ein doppelten tap zu erkennen



            # Langes halten erkannt led programm pausieren/starten (an/ausschalten)
            else:
                # print("Langes halten erkannt, pause/start implementieren/triggern")
                if self.waspaused == True:
                    self.waspaused = False
                    # self.unpause()
                elif self.waspaused == False:
                    self.waspaused = True
                    # self.pause()
                time.sleep(0.4)

    # Funktion um zu prüfen ob der button gehalten wird (hold)
    def checkhold(self):
        # print("checkhold gestartet")
        counter = 0
        holdcounter = 0
        counterfinish = 1000
        expandedtimes = 0

        while True:
            if self.checkbuttoninput():
                holdcounter = holdcounter + 1
                # print("Debugging checkhold holdcounter ist: ", holdcounter)
            if holdcounter >= 1 and holdcounter < 20 and expandedtimes < 4:
                counterfinish += 5000
                expandedtimes += 1

                # print("ist es hold, erhöhe abtastzeit?")
                # if self.paused == False:
                # self.pause()
            if holdcounter >= 20:
                # print("hold detected")
                return True
            counter = counter + 1
            if counter == counterfinish:
                return False

    def checksecondtouch(self):

        # print("checksecondtouch gestartet")
        counter = 0
        holdcounter = 0

        while True:
            if self.checkbuttoninput():
                # print("checksecondtouch buttoninout erkannt")
                holdcounter = holdcounter + 1
                time.sleep(0.001)
                if holdcounter < 20:
                    continue

            else:
                if holdcounter >= 20:
                    # print("2. Hold erkannt")
                    return "hold"

            counter = counter + 1
            if counter >= 60000 and holdcounter < 1:
                # print("kein 2. Touch erkannt, simpler touch")
                return 'none'
            elif counter < 60000 and holdcounter >= 1 and holdcounter < 20:
                # print("kurzer 2. Touch erkannt")
                return 'short'

    def checkloop(self, stopevent):
        while True:
            if stopevent.is_set():
                print("Stopevent wurde getriggert")
                self.stopevent.clear()
                self.multiprocess = None
                return
            self.gesturedetection()

    '''Funktionen für Led Programm manager'''

    def pause(self):
        # TODO led Programm manager stop current led program testen
        print("Pause wurde getriggert OLD")
        if self.manager == None:
            return
        self.manager.stop_led_Process()
        print("Pause wurde getriggert OLD")

    def unpause(self):
        # TODO led Programm maneger start current led Programm testen
        print("Fortfahren wurde getriggert OLD")
        if self.manager == None:
            return
        currentprogramm = self.manager.getcurrentprogramm()
        data = self.getData()
        self.manager.start_named_program(currentprogramm, data)

    def nextprogramm(self):
        # TODO led Programm manager next programm testen
        print("Nextprogramm ausgelöst OLD")
        if self.manager == None:
            return
        self.manager.next_program()

    def previousprogramm(self):
        # TODO led Programm manager previus programm testen
        print("vorheriges programm aufgerufen OLD")
        if self.manager == None:
            return
        self.manager.previous_program()

    def wait_for_button_release(self):
        """Waits until the button is released."""
        while not self.button.value:
            time.sleep(0.01)  # Short delay to avoid busy waiting

    def dimming(self):

        return

    # diese funktion wird benötigt um den LED-Programm manager daten aus dem Json File zuzusenden
    def getData(self):
        with open("current_lampmodel.json", "r") as file:
            current_data = json.load(file)
            return current_data

    # Check if Bluetooth should be enbaled

    def check_bluetooth_enable(self):
        duration = 5
        count = 0
        start_time = time.time()
        while True:
            current_time = time.time()
            if self.checkbuttoninput():  # Wenn der Button gedrückt wird, ist der Wert False, wenn der Pull-Up-Widerstand aktiviert ist
                self.btbuttonwaspressed = True
                count += 1
                print("Button wurde gedrückt ", count)

            if current_time - start_time >= duration:
                break

    def get_bt_button_was_pressed(self):
        return self.btbuttonwaspressed
