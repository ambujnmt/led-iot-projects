import json
import os
import subprocess


def setHostname(newhostname):
    with open('/etc/hosts', 'r') as file:
        # read a list of lines into data
        data = file.readlines()

        # the host name is on the 6th line following the IP address
        # so this replaces that line with the new hostname
    data[5] = '127.0.1.1       ' + newhostname

    # save the file temporarily because /etc/hosts is protected
    with open('temp.txt', 'w') as file:
        file.writelines(data)

    # use sudo command to overwrite the protected file
    os.system('sudo mv temp.txt /etc/hosts')

    # repeat process with other file
    with open('/etc/hostname', 'r') as file:
        data = file.readlines()
    data[0] = newhostname

    with open('temp.txt', 'w') as file:
        file.writelines(data)

    os.system('sudo mv temp.txt /etc/hostname')


def getHostname():
    hostname = os.uname()[1]
    print("der Hostname lautet: ", hostname)
    return hostname


def reset_lampmodel():
    # Pfad zur JSON-Datei
    json_file_path = "current_lampmodel.json"

    # Die JSON-Datei einlesen
    try:
        with open(json_file_path, 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        print(f"Datei {json_file_path} nicht gefunden.")
        return
    except json.JSONDecodeError:
        print(f"Fehler beim Lesen der JSON-Datei {json_file_path}.")
        return

    # Die gewünschten Werte auf Standardwerte setzen
    data['lampNumber'] = ''  # Oder eine andere Standardnummer
    data['lampName'] = ''
    data['isRegistered'] = False
    data['ipadress'] = ''
    data['currentlaufzeitnummer'] = ""
    data['currentlaufzeitstart'] = "--:--"
    data['currentlaufzeitende'] = "--:--"
    data['currentlaufzeitmodus'] = "--:--"
    data['currentlaufzeitisactive'] = False
    data['modus'] = ""
    data['laufzeit1start'] = "--:--"
    data['laufzeit1ende'] = "--:--"
    data['laufzeit2start'] = "--:--"
    data['laufzeit2ende'] = "--:--"
    data['laufzeit3start'] = "--:--"
    data['laufzeit3ende'] = "--:--"
    data['laufzeit4start'] = "--:--"
    data['laufzeit4ende'] = "--:--"
    data['moduslaufzeit1'] = "-"
    data['moduslaufzeit2'] = "-"
    data['moduslaufzeit3'] = "-"
    data['moduslaufzeit4'] = "-"







    # Die aktualisierten Daten zurück in die JSON-Datei schreiben
    try:
        with open(json_file_path, 'w') as file:
            json.dump(data, file)
        print("Lampenmodell wurde zurückgesetzt.")
    except IOError:
        print(f"Fehler beim Schreiben in die Datei {json_file_path}.")



def checkIfDefaultHostNameAndChange():
    from WIFI_Manager import Wifi_Connection
    current_hostname = getHostname()
    mac_address = Wifi_Connection.get_mac_address()
    mac_address = mac_address.replace(":", "")
    needed_hostname = "solarlampe" + mac_address
    print(needed_hostname, "needed hostname-------------------")
    print(current_hostname, "current hostname------------------")
    if current_hostname == "solarlampe":
        print("Default Hostname ist noch gesetzt, muss geändert werden...")
        print("MAC-Adresse des Gerätes lautet: ", mac_address)
        newhostname = needed_hostname
        print("Hostname wird auf ", newhostname, " geändert....")
        import time
        setHostname(newhostname)
        time.sleep(3)
        print("Hostname wurde gesetzt, starte System neu um Namensänderung wirksam zu machen")
        # reset_lampmodel()
        time.sleep(1)


        # Wifi_Connection.delete_all_wifi_credentials()
        # time.sleep(2)
        # subprocess.run(['sudo', 'systemctl', 'restart', 'NetworkManager'], check=True)
        # time.sleep(2)

        os.system("sudo reboot")
        # os.system("sudo systemctl restart systemd-hostnamed")
    else:
        print("Default Hostname wurde bereits geändert")
        return

# checkIfDefaultHostNameAndChange()
# Then call the def
# setHostname('solarlampe')
# print("job done")
# getHostname()
