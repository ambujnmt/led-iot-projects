#import machine
#import _thread
import board
import neopixel
import time
import multiprocessing
#import network
#from machine import TouchPad
from led_programmliste import manager
import time


import random
import gc



class Xmas:
    def __init__(self, touchenabled):

        manager.add_programm(self)

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)

        #'Belegung ESP32 mehr Ram'

        self.PIN = board.D12 #18

        #neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)
#         self.PIN_MID = board.D19 #19  # Change the pin number to match your hardware setup
#         self.PIN_BOTTOM_FIRST = board.D21#21
#         self.PIN_BOTTOM_SECOND = board.D22#22
#         self.PIN_BOTTOM_THIRD = board.D23#23
        '''
        #'Belegung ESP32 mehr Ram'

        self.PIN = 18
        self.PIN_MID = 19  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 21
        self.PIN_BOTTOM_SECOND = 22
        self.PIN_BOTTOM_THIRD = 23

        #Belegung ESP32 Platine

        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''

        # Define the colors
        self.ORANGE = [(255, 51, 0, 0)]
        self.NONE_COLOR = [(0, 0, 0, 0,)]

        self.GREEN = [(0, 100, 0, 0)]
        self.RED = [(100, 0, 0, 0)]


        self.xmas_running = False
        self.thread_running = None


        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.xmas_on = False

        print("Xmas wurde initialisiert")

        self.init = True

        time.sleep(0.1)

    def np_top_array(self, position, value):

         self.np[position] = value

    def np_mid_array(self, position, value):

        #print("Position mid array: ", position)


        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value




    def xmas_loop(self, stop_event, diming, change_timing = True):

        if diming:
            #self.ORANGE = [(128, 26)] 50% gedimmt
            #self.NONE_COLOR = [(0, 0, 0, 0)]
            #self.GREEN  = [(0, 50, 0, 0)]
            #self.RED = [(50, 0, 0, 0)]
            
            # auf 25% gedimmt
            self.ORANGE = [(64, 13, 0, 0)]
            self.NONE_COLOR = [(0, 0, 0, 0)]
            self.GREEN = [(0, 25, 0, 0)]
            self.RED = [(25, 0, 0, 0)]

        gc.enable()

        r4 = 0
        r_bottom = 0
        star2 = 0

        brightness = 0.0
        brightness2 = 0.0

        switch_brightness = 0
        switch_brightness2 = 0

        number1 = 0 # erstem Wassertropfen eine zufällige Zahl geben
        number2 = 1 # zweiten Wassertropfen eine zufällige Zahl geben
        number3 = 2 # drittem Wassertropfen eine zufällige Zahl geben
        number4 = 8
        number5 = 6
        number6 = 3

        array = [number1, number2, number3, number4, number5, number6]

        roundStar = 0
        roundStar2 = 0
        roundStar3 = 0
        roundStar4 = 0
        roundStar5 = 0


        star_two_running = False

        count_number = 0

        color_1_switch = False
        color_2_switch = False

        color1 = self.RED[0]
        color2 = self.ORANGE[0]


        brightness_bottom1 = 0.0
        is_brightness_bottom1 = True

        brightness_bottom2 = 30.0
        is_brightness_bottom2 = True

        brightness_bottom3 = 90.0
        is_brightness_bottom3 = True

        '''
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        '''

        while self.xmas_on:


            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''
            if stop_event.is_set():
                self.stop()
                return

            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            if change_timing == True:
                time.sleep(0.01)


            r4 = r4 + 1
            star2 = star2 + 1
            r_bottom = r_bottom + 1
            if(r4 == 1):

                # STERN 1
                if brightness <= 0.0:
                    if roundStar == 2:
                        roundStar = 0

                    roundStar += 1
                    switch_brightness = 1

                if brightness == 100.0:
                    roundStar += 1
                    switch_brightness = 0

                if switch_brightness == 1:
                    brightness += 5.0
                else:
                    brightness -= 5.0

                    if brightness <= 0:
                        color_1_switch = not color_1_switch



                # STERN 2
                if star2 == 1:
                    star_two_running = True
                if star_two_running == True:
                    if brightness2 <= 0.0:
                        if roundStar2 == 2:
                            roundStar2 = 0

                        roundStar2 += 1

                        switch_brightness2 = 1


                    if brightness2 == 100.0:
                        roundStar2 += 1
                        switch_brightness2 = 0

                    if switch_brightness2 == 1:
                        brightness2 += 5.0
                    else:
                        brightness2 -= 5.0

                        if brightness2 <= 0:
                            star2 = 0
                            star_two_running = False
                            color_2_switch = not color_2_switch


                #______________________________________TOP START_______________________________________________
                self.np_top_array(0, self.GREEN[0])
                self.np_top_array(1, self.GREEN[0])
                self.np_top_array(2, self.GREEN[0])
                self.np_top_array(3, self.GREEN[0])
                self.np_top_array(4, self.GREEN[0])
                self.np_top_array(5, self.GREEN[0])
                self.np_top_array(6, self.GREEN[0])
                self.np_top_array(7, self.GREEN[0])
                self.np_top_array(8, self.GREEN[0])
                self.np_top_array(9, self.GREEN[0])
                #_____________________________________TOP ENDE________________________________________________

                if change_timing == True:
                    time.sleep(0.01)

                #_____________________________________MID START_______________________________________________
                self.np_mid_array(0, self.GREEN[0])
                self.np_mid_array(1, self.GREEN[0])
                self.np_mid_array(2, self.GREEN[0])
                self.np_mid_array(3, self.GREEN[0])
                self.np_mid_array(4, self.GREEN[0])
                self.np_mid_array(5, self.GREEN[0])
                self.np_mid_array(6, self.GREEN[0])
                self.np_mid_array(7, self.GREEN[0])
                self.np_mid_array(8, self.GREEN[0])
                self.np_mid_array(9, self.GREEN[0])
                self.np_mid_array(10, self.GREEN[0])
                self.np_mid_array(11, self.GREEN[0])
                self.np_mid_array(12, self.GREEN[0])
                self.np_mid_array(13, self.GREEN[0])
                self.np_mid_array(14, self.GREEN[0])
                self.np_mid_array(15, self.GREEN[0])
                self.np_mid_array(16, self.GREEN[0])
                self.np_mid_array(17, self.GREEN[0])
                self.np_mid_array(18, self.GREEN[0])
                self.np_mid_array(19, self.GREEN[0])
                self.np_mid_array(20, self.GREEN[0])
                self.np_mid_array(21, self.GREEN[0])
                self.np_mid_array(22, self.GREEN[0])
                self.np_mid_array(23, self.GREEN[0])
                self.np_mid_array(24, self.GREEN[0])
                self.np_mid_array(25, self.GREEN[0])
                self.np_mid_array(26, self.GREEN[0])
                self.np_mid_array(27, self.GREEN[0])
                self.np_mid_array(28, self.GREEN[0])
                self.np_mid_array(29, self.GREEN[0])
                self.np_mid_array(30, self.GREEN[0])
                self.np_mid_array(31, self.GREEN[0])
                self.np_mid_array(32, self.GREEN[0])
                self.np_mid_array(33, self.GREEN[0])
                self.np_mid_array(34, self.GREEN[0])
                self.np_mid_array(35, self.GREEN[0])
                self.np_mid_array(36, self.GREEN[0])
                self.np_mid_array(37, self.GREEN[0])
                self.np_mid_array(38, self.GREEN[0])
                self.np_mid_array(39, self.GREEN[0])
                self.np_mid_array(40, self.GREEN[0])
                self.np_mid_array(41, self.GREEN[0])
                self.np_mid_array(42, self.GREEN[0])
                self.np_mid_array(43, self.GREEN[0])
                self.np_mid_array(44, self.GREEN[0])
                self.np_mid_array(45, self.GREEN[0])
                self.np_mid_array(46, self.GREEN[0])
                self.np_mid_array(47, self.GREEN[0])
                self.np_mid_array(48, self.GREEN[0])
                self.np_mid_array(49, self.GREEN[0])
                self.np_mid_array(50, self.GREEN[0])
                self.np_mid_array(51, self.GREEN[0])
                self.np_mid_array(52, self.GREEN[0])
                self.np_mid_array(53, self.GREEN[0])
                self.np_mid_array(54, self.GREEN[0])
                self.np_mid_array(55, self.GREEN[0])
                self.np_mid_array(56, self.GREEN[0])
                self.np_mid_array(57, self.GREEN[0])
                self.np_mid_array(58, self.GREEN[0])
                self.np_mid_array(59, self.GREEN[0])
                self.np_mid_array(60, self.GREEN[0])
                self.np_mid_array(61, self.GREEN[0])
                self.np_mid_array(62, self.GREEN[0])
                self.np_mid_array(63, self.GREEN[0])
                self.np_mid_array(64, self.GREEN[0])
                self.np_mid_array(65, self.GREEN[0])
                self.np_mid_array(66, self.GREEN[0])
                self.np_mid_array(67, self.GREEN[0])
                self.np_mid_array(68, self.GREEN[0])
                self.np_mid_array(69, self.GREEN[0])
                self.np_mid_array(70, self.GREEN[0])
                self.np_mid_array(71, self.GREEN[0])
                self.np_mid_array(72, self.GREEN[0])
                self.np_mid_array(73, self.GREEN[0])
                self.np_mid_array(74, self.GREEN[0])
                self.np_mid_array(75, self.GREEN[0])
                self.np_mid_array(76, self.GREEN[0])
                self.np_mid_array(77, self.GREEN[0])
                self.np_mid_array(78, self.GREEN[0])
                self.np_mid_array(79, self.GREEN[0])
                self.np_mid_array(80, self.GREEN[0])
                self.np_mid_array(81, self.GREEN[0])
                self.np_mid_array(82, self.GREEN[0])
                self.np_mid_array(83, self.GREEN[0])
                self.np_mid_array(84, self.GREEN[0])
                self.np_mid_array(85, self.GREEN[0])
                self.np_mid_array(86, self.GREEN[0])
                self.np_mid_array(87, self.GREEN[0])
                self.np_mid_array(88, self.GREEN[0])
                self.np_mid_array(89, self.GREEN[0])
                self.np_mid_array(90, self.GREEN[0])
                self.np_mid_array(91, self.GREEN[0])
                self.np_mid_array(92, self.GREEN[0])
                self.np_mid_array(93, self.GREEN[0])
                self.np_mid_array(94, self.GREEN[0])
                self.np_mid_array(95, self.GREEN[0])
                self.np_mid_array(96, self.GREEN[0])
                self.np_mid_array(97, self.GREEN[0])

                if change_timing == True:
                    time.sleep(0.01)

                if color_1_switch == False:
                    color1 = self.ORANGE[0]
                else:
                    color1 = self.RED[0]

                if color_2_switch == False:
                    color2 = self.RED[0]
                else:
                    color2 = self.ORANGE[0]



                # Mid - LEDS:
                self.mid_leds_on(0, brightness, color1, stop_event)
                self.mid_leds_on(1, brightness2, color2,stop_event)
                self.mid_leds_on(2, brightness, color1,stop_event)
                self.mid_leds_on(3, brightness2, color2,stop_event)
                self.mid_leds_on(4, brightness, color1,stop_event)
                self.mid_leds_on(5, brightness2, color2,stop_event)
                self.mid_leds_on(6, brightness, color1,stop_event)
                self.mid_leds_on(7, brightness2, color2,stop_event)
                self.mid_leds_on(8, brightness, color1,stop_event)
                self.mid_leds_on(9, brightness2, color2,stop_event)
                #_____________________________________MID ENDE_______________________________________________


                #_____________________________________BOTTOM START_______________________________________________

                #_______________________________________________________________________
                if is_brightness_bottom1 == True:
                    brightness_bottom1 += 2.0
                    if brightness_bottom1 >= 100.0:
                        is_brightness_bottom1 = False
                else:
                    brightness_bottom1 -= 2.0
                    if brightness_bottom1 <= 0.0:
                        is_brightness_bottom1 = True


                self.bottom1_array(0, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(1, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(2, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(3, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(4, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(5, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(6, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(7, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(8, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(9, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(10, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                self.bottom1_array(11, self.scale_color(self.GREEN[0], brightness_bottom1, stop_event))
                #___________________________________________________________________________________

                if is_brightness_bottom2 == True:
                    brightness_bottom2 += 2.0
                    if brightness_bottom2 >= 100.0:
                        is_brightness_bottom2 = False
                else:
                    brightness_bottom2 -= 2.0
                    if brightness_bottom2 <= 0.0:
                        is_brightness_bottom2 = True


                self.bottom2_array(0, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(1, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(2, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(3, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(4, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(5, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(6, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(7, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(8, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(9, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(10, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                self.bottom2_array(11, self.scale_color(self.GREEN[0], brightness_bottom2, stop_event))
                #___________________________________________________________________________________

                if is_brightness_bottom3 == True:
                    brightness_bottom3 += 2.0
                    if brightness_bottom3 >= 100.0:
                        is_brightness_bottom3 = False
                else:
                    brightness_bottom3 -= 2.0
                    if brightness_bottom3 <= 0.0:
                        is_brightness_bottom3 = True


                self.bottom3_array(0, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(1, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(2, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(3, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(4, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(5, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(6, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(7, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(8, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(9, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(10, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))
                self.bottom3_array(11, self.scale_color(self.GREEN[0], brightness_bottom3, stop_event))



                r4 = 0

            if stop_event.is_set():
                self.stop()
                return


            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()

            #print("XMAS Leuchtprigramm hat funltionier :)")


    # Die Methode gibt dir einene gegebene Farbwert zurück, welche durch die "brightness" eingestellt wurde
    #@micropython.native
    def scale_color(self, color_tupel, brightness, stop_event):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)

        return (r, g, b, w)

    #@micropython.native
    def bottom_off_first(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom1_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom1_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom1_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom1_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom1_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom1_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom1_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom1_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom1_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom1_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom1_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom1_array(10, self.NONE_COLOR[0])


    #@micropython.native
    def bottom_off_second(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom2_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom2_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom2_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom2_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom2_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom2_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom2_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom2_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom2_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom2_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom2_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom2_array(10, self.NONE_COLOR[0])


    #@micropython.native
    def bottom_off_third(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom3_array(11, self.NONE_COLOR[0])

        elif count_number == 1:
            self.bottom3_array(0, self.NONE_COLOR[0])

        elif count_number == 2:
            self.bottom3_array(1, self.NONE_COLOR[0])

        elif count_number == 3:
            self.bottom3_array(2, self.NONE_COLOR[0])

        elif count_number == 4:
            self.bottom3_array(3, self.NONE_COLOR[0])

        elif count_number == 5:
            self.bottom3_array(4, self.NONE_COLOR[0])

        elif count_number == 6:
            self.bottom3_array(5, self.NONE_COLOR[0])

        elif count_number == 7:
            self.bottom3_array(6, self.NONE_COLOR[0])

        elif count_number == 8:
            self.bottom3_array(7, self.NONE_COLOR[0])

        elif count_number == 9:
            self.bottom3_array(8, self.NONE_COLOR[0])

        elif count_number == 10:
            self.bottom3_array(9, self.NONE_COLOR[0])

        elif count_number == 11:
            self.bottom3_array(10, self.NONE_COLOR[0])





    def generateNewStart(self, brightness, switch_brightness, roundStar, number, array):
        if brightness <= 0.0:
            if roundStar == 2:
                number1 = self.remove_and_replace_number(number, array)
                roundStar = 0
            roundStar += 1
            switch_brightness = 1

        if brightness == 100.0:
            roundStar += 1
            switch_brightness = 0

        if switch_brightness == 1:
            brightness += 2.0
        else:
            brightness -= 2.0


    #@micropython.native
    def remove_and_replace_number(self, number, array):
        # Prüfe, ob die Zahl im Array vorhanden ist
        if number in array:
            # Falls ja, entferne die Zahl aus dem Array
            array.remove(number)

        # Wähle eine neue Zahl zwischen 0 und 8, die nicht im Array vorhanden ist
        new_number = random.choice([i for i in range(9) if i not in array])
        array.append(new_number)

        # Gib die neue Zahl zurück
        return new_number

    #@micropython.native
    def mid_leds_on(self, number1, brightness, color, stop_event):
        if(number1 == 0):
#            self.np_mid[(96)] = self.scale_color(color, brightness)
            self.np_mid_array(97, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(0, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(1, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(2)] = self.scale_color(color, brightness)

        if(number1 == 1):
#            self.np_mid[(7)] = self.scale_color(color, brightness)
            self.np_mid_array(8, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(9, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(10, self.scale_color(color, brightness, stop_event))
#             self.np_mid[(11)] = self.scale_color(color, brightness)

        if(number1 == 2):
#            self.np_mid[(17)] = self.scale_color(color, brightness)
            self.np_mid_array(18, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(19, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(20, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(21)] = self.scale_color(color, brightness)

        if(number1 == 3):
#            self.np_mid[(26)] = self.scale_color(color, brightness)
            self.np_mid_array(27, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(28, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(29, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(30)] = self.scale_color(color, brightness)

        if(number1 == 4):
#            self.np_mid[(37)] = self.scale_color(color, brightness)
            self.np_mid_array(38, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(39, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(40, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(41)] = self.scale_color(color, brightness)

        if(number1 == 5):
#            self.np_mid[(47)] = self.scale_color(color, brightness)
            self.np_mid_array(48, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(49, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(50, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(51)] = self.scale_color(color, brightness)

        if(number1 == 6):
#            self.np_mid[(57)] = self.scale_color(color, brightness)
            self.np_mid_array(58, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(59, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(60, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(61)] = self.scale_color(color, brightness)

        if(number1 == 7):
#            self.np_mid[(67)] = self.scale_color(color, brightness)
            self.np_mid_array(68, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(69, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(70, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(71)] = self.scale_color(color, brightness)

        if(number1 == 8):
#            self.np_mid[(78)] = self.scale_color(color, brightness)
            self.np_mid_array(79, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(80, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(81, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(82)] = self.scale_color(color, brightness)

        if(number1 == 9):
#            self.np_mid[(88)] = self.scale_color(color, brightness)
            self.np_mid_array(89, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(90, self.scale_color(color, brightness, stop_event))
            self.np_mid_array(91, self.scale_color(color, brightness, stop_event))
#            self.np_mid[(92)] = self.scale_color(color, brightness)


    def start(self, stop_event, diming):
        print("start XMAS innerhalb Xmas Klasse getrigget!")
        self.xmas_on = True
        self.xmas_loop(stop_event, diming)


    def stop(self):
        self.xmas_on = False
        self.xmas_off()
        self.np.deinit()


    def xmas_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.xmas_on


#xmas = Xmas(False)
#stop_event = multiprocessing.Event()
#diming = True
#xmas.start(stop_event, diming)