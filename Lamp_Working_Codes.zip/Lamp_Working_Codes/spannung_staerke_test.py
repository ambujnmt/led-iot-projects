import time

import smbus
from ladestrom_tests import BQ25731
# import adc_convertion


class ControlBattery:
    # Initialize the class with the I2C address for the bq25731
    def __init__(self, i2c_bus=1, chip_address=0x6B):
        self.bus = smbus.SMBus(i2c_bus)
        self.chip_address = chip_address
        self.bq_device = BQ25731()
        # Register addresses
        self.ADCVBUS_REGISTER = 0x27
        self.ADCPSYS_REGISTER = 0x26
        self.ADCDAC_REGISTER = 0x29
        self.ADCDACDIS_REGISTER = 0x28
        self.SENSE_RESISTOR = 0.01
        self.ADCDAC_LSB = 64
        self.ADCIN_REGISTER = 0x2B
        self.CHARGE_CURRENT_MSB_REGISTER = 0x03
        self.CHARGE_CURRENT_LSB_REGISTER = 0x02
        self.WATCHDOG_REGISTER = 0x01

    def disable_watchdog(self):
        current_value = self.bus.read_byte_data(self.chip_address, self.WATCHDOG_REGISTER)

        # Clear bits 6-5 to disable the watchdog timer
        # This is done by ANDing with 1001_1111 (0x9F)
        new_value = current_value & 0x1F

        # Write the new value back to the ChargeOption Register
        self.bus.write_byte_data(self.chip_address, self.WATCHDOG_REGISTER, new_value)

    def print_register_bits(self, register_address):
        # Read a byte from the specified register
        register_value = self.bus.read_byte_data(self.chip_address, register_address)

        # Print out each bit in the byte
        for bit in range(7, -1, -1):  # Start from the most significant bit
            print(f"Bit {bit}: {1 if (register_value & (1 << bit)) else 0}")

    def set_maximum_charge_current(self):
        # Get user input for the charge current
        one_seven_five_amp = 2
        three_amp = 3
        four_amp = 4
        # user_input = int(input("1-3 oder 0 eingeben: \n"))
        # Set the charge current on the device
        self.bq_device.set_charge_current(3)

    def read_voltage(self):
        # Read the input voltage (VBUS)
        voltage_raw = self.bus.read_byte_data(self.chip_address, self.ADCVBUS_REGISTER)
        print(voltage_raw, " voltage raw")
        voltage_mV = voltage_raw * 96  # Convert raw reading to mV
        return voltage_mV

    def read_psys(self):
        # Read the System_Power
        psys_raw = self.bus.read_byte_data(self.chip_address, self.ADCPSYS_REGISTER)
        print(psys_raw, " psys raw")
        psys_mv = psys_raw * 12
        return psys_mv

    def read_input_current(self):
        # Read the input current (IIN)
        input_current_raw = self.bus.read_byte_data(self.chip_address, self.ADCIN_REGISTER)
        input_current_mA = input_current_raw * 50  # Convert raw reading to mA, assuming a 20 mOhm sense resistor
        return input_current_mA

    def read_charge_current(self):
        # Read the charge current setting
        msb = self.bus.read_byte_data(self.chip_address, self.CHARGE_CURRENT_MSB_REGISTER)
        lsb = self.bus.read_byte_data(self.chip_address, self.CHARGE_CURRENT_LSB_REGISTER)

        # Shift MSB left by 2 and add the two LSB bits to form the full value
        charge_current_raw = ((msb & 0x7F) << 2) | ((lsb >> 6) & 0x03)

        # Each bit represents 128 mA, so multiply by 128 to get the charge current in mA
        charge_current_mA = charge_current_raw * 128
        return charge_current_mA

    def get_battery_charge_data(self):
        voltage = self.read_voltage()
        psys = self.read_psys()
        input_current = self.read_input_current()
        charge_current = self.read_charge_current()

        return voltage, psys, input_current, charge_current

    def read_current(self, reg):
        try:
            # Read byte data
            adc_value = self.bus.read_byte_data(self.chip_address, reg)
            # Mask to get the 7-bit value
            adc_value &= 0x7F
            return adc_value
        except Exception as e:
            print(f"Error reading from I2C: {e}")
            return None

    def calculate_current(self, adc_value, lsb):
        """Calculate the current based on ADC value and LSB value."""
        if adc_value is not None:
            # Calculate current in Amps
            current_mA = adc_value * lsb
            current_A = current_mA / 1000.0
            return current_mA
        else:
            return None

    def update_registers(self):
        # Update register 0x3A
        reg3B_current = self.bus.read_byte_data(self.chip_address, 0x3B)
        # Set bits 7 and 6 to 1, clear bit 5
        # Mask for setting bits 7 and 6: 1100_0000 (0xC0)
        # Mask for clearing bit 5: 1101_1111 (0xDF)
        reg3B_new = 0x80
        self.bus.write_byte_data(self.chip_address, 0x3B, reg3B_new)

        # Update register 0x3B
        # Set all bits to 1
        reg3A_new = 0xFF
        self.bus.write_byte_data(self.chip_address, 0x3A, reg3A_new)


# Usage
def main(on):
    if on:
        battery_controller = ControlBattery(i2c_bus=1, chip_address=0x6B)
        # converter = adc_convertion
        battery_controller.disable_watchdog()
        battery_controller.update_registers()
        battery_controller.set_maximum_charge_current()
        # converter.enable()
        # converter.print_regs()
        while True:
            voltage, psys, input_current, charge_current = battery_controller.get_battery_charge_data()
            # battery_controller.disable_watchdog()
            ADCDAC_REGISTER = 0x29
            ADCIIN_REGISTER = 0x2B

            ADCDACDIS_REGISTER = 0x28
            adc_dac_value = battery_controller.read_current(ADCDAC_REGISTER)
            adc_iin_value = battery_controller.read_current(ADCIIN_REGISTER)
            charge_current = battery_controller.calculate_current(adc_dac_value, lsb=128.0)
            power_current = battery_controller.calculate_current(adc_iin_value, lsb=100.0)

            if charge_current is not None:
                print(f"Charge Current: {charge_current} mA")
            else:
                print("Failed to read charge current")

            if power_current is not None:
                print(f"Power Current: {power_current} mA")
            else:
                print("Failed to read charge current")

            print(f"Power System: {power_current - charge_current} mA")



            # Read the ADC value for discharge current
            adc_dacdis_value = battery_controller.read_current(ADCDACDIS_REGISTER)

            # Calculate the discharge current in Amps
            discharge_current = battery_controller.calculate_current(adc_dacdis_value, lsb=512.0)

            # Print the results
            if discharge_current is not None:
                print(f"Discharge Current: {discharge_current} mA")
            else:
                print("Failed to read discharge current")

            # Print the data
            print(f"Voltage: {voltage} mV")
            # print(f"Psys: {psys} mV")
            # print(f"Input Current: {input_current} mA")
            # print(f"Charge Current: {charge_current} mA")
            time.sleep(5)
    else:
        return
# addr = int(input("Register Adress: "),16)
# battery_controller.print_register_bits(addr)

main(0)