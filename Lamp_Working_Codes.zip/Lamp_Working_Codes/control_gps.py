import RPi.GPIO as GPIO
import serial
import pynmea2
import time


def setup_gpio():
    GPIO.setmode(GPIO.BCM)  # Use BCM GPIO numbering
    GPIO.setup(1, GPIO.OUT)  # GPIO 1 as output (I2C SCL)
    GPIO.setup(21, GPIO.OUT)  # GPIO 21 as output (force_on for GPS)


def activate_gps():
    GPIO.output(1, GPIO.LOW)  # Set GPIO 1 to LOW
    GPIO.output(21, GPIO.HIGH)  # Set GPIO 21 to HIGH to turn on GPS module
    time.sleep(1)  # Wait a bit for the GPS module to initialize


def deactivate_gps():
    GPIO.output(21, GPIO.LOW)
    GPIO.output(1, GPIO.HIGH)


def read_gps_data(serial_port):
    start_time = time.time()  # Record the start time
    while True:
        if time.time() - start_time > 10:  # Check if 10 seconds have passed
            print("Timeout: Could not find valid GPS data in 10 seconds.")
            break
        try:
            line = serial_port.readline()
            if not line:
                print("No data received. Checking again...")
                continue
            print(line)  # Print raw NMEA sentence for debugging
            msg = pynmea2.parse(line.decode('utf-8'))
            if isinstance(msg, pynmea2.types.talker.GGA) and msg.latitude != 0 and msg.longitude != 0:
                return msg.latitude, msg.longitude
        except serial.SerialException as e:
            print(f"Serial error: {e}")
            break  # or continue, depending on how you want to handle the error
        except (UnicodeDecodeError, pynmea2.ParseError):
            pass  # Ignore parsing errors or wrong data format


def get_lat_long():
    setup_gpio()
    activate_gps()
    with serial.Serial('/dev/serial0', baudrate=9600, timeout=1) as ser:
        try:
            latitude, longitude = read_gps_data(ser)
            if latitude and longitude:
                print(f"Latitude: {latitude}, Longitude: {longitude}")
            deactivate_gps()
            return latitude, longitude
        except Exception as e:
            print(f"Error reading GPS data: {e}")
            deactivate_gps()


latitude = None
longitude = None


def get_lat_long_cached():
    global latitude, longitude
    try:
        if latitude is None or longitude is None:
            latitude, longitude = get_lat_long()
            return latitude, longitude
    except:
        print("couldn't find GPS")
        latitude = 50*-1   #default 50 for germany
        longitude = 10+180  #default 10 for germany
        return (latitude, longitude)
# This modified script includes a timeout mechanism in the read_gps_data function.
# Make sure to adjust '/dev/serial0' to your GPS module's UART port.
