import sys

import board
import digitalio
import time
import json
from shared_ressources import shared_resources


class Tilt_MotorControl:
    def __init__(self, step_pin, direction_pin, enable_pin):
        self.tilt_motor = self.setup_motor(step_pin, direction_pin)
        self.json_filename = 'current_motor_status.json'
        self.data = None
        self.steps_per_revolution = 200  # Change this to match your stepper motor
        self.desired_rpm = 60  # Desired rotations per minute
        self.degrees_per_step = 7/2007  # ~0,00401785
        self.custom_speed = 0.000025  # default is 0.000025
        self.enable_pin = digitalio.DigitalInOut(enable_pin)
        self.enable_pin.direction = digitalio.Direction.OUTPUT



    def setup_motor(self, step_pin, direction_pin):
        motor = digitalio.DigitalInOut(step_pin)
        motor.direction = digitalio.Direction.OUTPUT
        self.direction_pin = digitalio.DigitalInOut(direction_pin)
        self.direction_pin.direction = digitalio.Direction.OUTPUT
        return motor

    def load_motor_data(self):
        time.sleep(1)
        try:
            with open(self.json_filename, 'r') as file:
                data = json.load(file)
                if 'current_tilt' not in data:
                    data['current_tilt'] = 0.0  # Initialize if the key is missing
                return data
        except (FileNotFoundError, json.JSONDecodeError):
            # data = {'current_tilt': 0}  # Initialize if the key is missing
            # self.save_motor_data(data)
            return data

    def save_motor_data(self, data):
        with open(self.json_filename, 'w') as file:
            json.dump(data, file)

    def move_motor(self, num_steps, custom_speed):
        speed = custom_speed
        shared_resources.stop_event_tilt.clear()
        for _ in range(abs(num_steps)):
            self.tilt_motor.value = True
            time.sleep(speed)
            self.tilt_motor.value = False
            time.sleep(speed)
            if shared_resources.stop_event_tilt.is_set():
                break

    def set_tilt_angle(self, desired_angle, custom_speed):
        self.data = self.load_motor_data()
        current_tilt = int(self.data["current_tilt"])
        print(current_tilt, "current tilt in tilt motor controler")
        num_steps = int(round((desired_angle - current_tilt) / self.degrees_per_step))
        self.direction_pin.value = num_steps > 0
        self.move_motor(abs(num_steps), custom_speed)
        self.data['current_tilt'] = int(desired_angle)
        # self.save_motor_data(self.data)

        print("Anzahl der Tilt_Steps:", num_steps)

    def reset_tilt(self):
        current_angle = int(self.data['current_tilt'])
        if current_angle != 0:
            print(f"Resetting tilt to 0 degrees from {current_angle} degrees.")
            self.set_tilt_angle(0, self.custom_speed)
        else:
            print("The tilt angle is already at 0 degrees.")

    def run(self, angle, custom_speed):
        # self.enable_motor()
        # Set the initial direction for the tilt motor
        self.direction_pin.value = True  # Change this as needed

        speed_value = 0.005
        speed = speed_value / custom_speed
        # print(time.time(), "tilt time")
        try:
            self.set_tilt_angle(angle, speed)
        except ValueError:
            print("Invalid input. Please enter a valid angle in degrees.")

        except KeyboardInterrupt:
            print("Exiting the program.")

