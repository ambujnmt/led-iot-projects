import multiprocessing
import threading
import pydbus
import subprocess
import time
import struct
from WIFI_Manager import Wifi_Connection
from bluezero import adapter, peripheral, device
from led_programm_bluetooth_active import bt_led


def run_command(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True, check=True)
    return result.stdout


def get_wlan_and_bt_status():
    output = run_command("rfkill list")
    entries = output.split("1")
    wlan_info, bt_info = None, None
    for entry in entries:
        if "Wireless LAN" in entry:
            wlan_info = entry
        if "Bluetooth" in entry:
            bt_info = entry
    return wlan_info, bt_info


def enable_bluetooth():
    run_command("sudo rfkill unblock bluetooth")
    while True:
        wlan_output, bluetooth_output = get_wlan_and_bt_status()
        if not ("Soft blocked: yes" in bluetooth_output or "Hard blocked: yes" in bluetooth_output):
            time.sleep(1)
            return


def disable_bluetooth():
    print("disable_bluetooth rfkill")
    run_command("sudo rfkill block bluetooth")
    while True:
        wlan_output, bluetooth_output = get_wlan_and_bt_status()
        if "Soft blocked: yes" in bluetooth_output or "Hard blocked: yes" in bluetooth_output:
            time.sleep(1)
            return


def set_bluetooth_name(name="Sol_Lamp"):
    try:
        with open("/etc/bluetooth/main.conf", "r") as file:
            contents = file.readlines()

        name_line_index = -1
        for i, line in enumerate(contents):
            if line.startswith("Name ="):
                name_line_index = i
                break

        if name_line_index != -1:
            contents[name_line_index] = f"Name = {name}\n"
        else:
            contents.append(f"\nName = {name}\n")

        with open("/etc/bluetooth/main.conf", "w") as file:
            file.writelines(contents)

        subprocess.run(["sudo", "systemctl", "restart", "bluetooth"], check=True)
        print(f"Bluetooth name set to {name}. Restarted Bluetooth service.")

    except Exception as e:
        print(f"Error setting Bluetooth name: {e}")


def set_bluetooth_name2(new_name):
    cmd = f'sudo hciconfig hci0 name {new_name}'
    subprocess.run(cmd, shell=True)


def get_bluetooth_name():
    cmd = "bluetoothctl show | grep 'Name'"
    result = subprocess.run(cmd, stdout=subprocess.PIPE, shell=True, text=True)
    name_line = result.stdout.strip()
    return name_line.split(": ")[1]


enable_bluetooth()
set_bluetooth_name2("Sol_Lamp")
print(get_bluetooth_name())

wlan_output, bluetooth_output = get_wlan_and_bt_status()

if "Soft blocked: yes" in bluetooth_output or "Hard blocked: yes" in bluetooth_output:
    print("Bluetooth deaktiviert, aktiviere nun...")
    enable_bluetooth()
    wlan_output, bluetooth_output = get_wlan_and_bt_status()
    print("wlan Output: ", wlan_output)
    print("Bt Output: ", bluetooth_output)
else:
    wlan_output, bluetooth_output = get_wlan_and_bt_status()
    print("wlan Output: ", wlan_output)
    print("Bt Output: ", bluetooth_output)


def bluetoothctl_commands(commands):
    cmd = "echo -e '{}' | sudo bluetoothctl".format('\n'.join(commands))
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout


class UARTDevice:
    blinking = False
    bt_led = bt_led()
    bt_led_stop_event = threading.Event()
    bt_blink_thread = threading.Thread(target=bt_led.advertisingblinking, args=(bt_led_stop_event,))
    ssid_recived = False
    pw_recived = False
    ssid = None
    pw = None
    ip_sent = False  # Flag to track if IP has been sent
    tx_obj = None
    rx_obj = None

    @classmethod
    def send_message(cls, message):
        if cls.tx_obj:
            cls.tx_obj.set_value(message.encode('utf-8'))
        else:
            print("No device connected.")

    @classmethod
    def on_connect(cls, ble_device: device.Device):
        print("Connected to " + str(ble_device.address))
        if UARTDevice.blinking:
            UARTDevice.bt_led_stop_event.set()
            # UARTDevice.bt_blink_thread = threading.Thread(target=cls.bt_led.connected)
            # UARTDevice.bt_blink_thread.start()

    @classmethod
    def on_disconnect(cls, adapter_address, device_address):
        def wait_for_ip_then_disconnect():
            timeout = 10  # seconds
            start_time = time.time()
            print("on_disconnect ip sent: ", cls.ip_sent)
            while not cls.ip_sent:
                if time.time() - start_time > timeout:
                    print("Timeout waiting for IP to be sent. Proceeding with disconnect.")
                    break
                time.sleep(0.5)

            print("Proceeding with disconnection from " + device_address)
            if cls.ssid_recived and cls.pw_recived and cls.ssid and cls.pw:
                print("Bedingung on disconnect für server erreicht")
                time.sleep(5)
                if Wifi_Connection.wifi_is_connected():
                    print("prüfung ob Wlan vorhanden ist erfüllt")
                    print("importiere Webserver")
                    disable_bluetooth()
                    import webserver_microdot
                    print("versuche webserver zu starten...")
                    webserver_microdot.start_server()


            else:
                print("BT Kopplung meint er ist noch nicht verbunden")
                if UARTDevice.blinking:
                    print("disconnected ohne Kopplung led blinking wieder aktivieren")
                cls.ssid_recived = False
                cls.pw_recived = False
                cls.ssid = None
                cls.pw = None

        print("on disconnect thread started: ")
        disconnect_thread = threading.Thread(target=wait_for_ip_then_disconnect)
        disconnect_thread.start()

    @classmethod
    def uart_notify(cls, notifying, characteristic):
        if notifying:
            cls.tx_obj = characteristic
        else:
            cls.tx_obj = None

    @classmethod
    def update_tx(cls, value):
        if cls.tx_obj:
            print("Sending")
            cls.tx_obj.set_value(value)

    @classmethod
    def uart_write(cls, value, options):
        print('raw bytes:', value)
        print('With options:', options)
        txtvalue = bytes(value).decode('utf-8')
        print('Text value: ', txtvalue)
        cls.store_network_data(txtvalue)

    # @classmethod
    # def uart_read(cls):
    #     try:
    #         print("Read Request getriggert")
    #         answer = Wifi_Connection.get_ip()
    #         print("Value für get Ip: ", answer)
    #         encoded_antwort = answer.encode('utf-8')
    #
    #         if cls.tx_obj:
    #             print("TX Characteristic ist verfügbar. Sende Antwort.")
    #             try:
    #                 cls.update_tx(encoded_antwort)
    #                 print("Antwort gesendet.")
    #             except Exception as send_error:
    #                 print("Fehler beim Senden der Antwort: ", send_error)
    #         else:
    #             print("TX Characteristic ist nicht verfügbar.")
    #
    #         if answer != "false":
    #             cls.ip_sent = True  # Set the flag that IP was sent
    #             print("ip_sent: ", cls.ip_sent)
    #
    #         return encoded_antwort
    #     except Exception as e:
    #         print("Fehler aufgetreten bei Read: ", e)
    #
    @classmethod
    def uart_read(cls):
        try:
            print("Read Request getriggert")
            answer = Wifi_Connection.get_ip()
            print("Value für get Ip: ", answer)
            encoded_antwort = answer.encode('utf-8')
            cls.update_tx(encoded_antwort)
            if answer != "false":
                cls.ip_sent = True  # Set the flag that IP was sent
                print("ip_sent: ", cls.ip_sent)

            print("Sollte nun antwort senden")
            return encoded_antwort
        except Exception as e:
            print("Fehler aufgetreten bei Read: ", e)

    @classmethod
    def store_network_data(cls, data):
        print("Store Network Data aufgerufen")
        if data.startswith("ssid:"):
            print("Store Network data hat ssid erhalten")
            cls.ssid = data[5:]
            print("SSID1 gespeichert")
            cls.ssid_recived = True

        if data.startswith("wlanpw"):
            print("Debugging Store Network data hat wlanpw erhalten")
            cls.pw = data[7:]
            cls.pw_recived = True

        print("Aktueller Status cls.ssid: ", cls.ssid, " ", cls.ssid_recived, ", pw: ", cls.pw, " ", cls.pw_recived)
        if cls.ssid_recived and cls.pw_recived:
            print("SSID und Passwort erhalten")
            Wifi_Connection.enable_wifi()
            try:
                Wifi_Connection.connect_to_wifi(cls.ssid, cls.pw)
                if Wifi_Connection.wifi_is_connected():
                    print("Verbindung zum Wlan konnte erfolgreich hergestellt werden, aus Store network Data")
            except Exception as e:
                print("Wifi Vebindung konnte nicht aufgebaut werden: ", e)
                cls.ssid_recived = False
                cls.pw_recived = False


def restart_bluetooth():
    command = "sudo systemctl restart bluetooth"
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    process.communicate()
    time.sleep(1)


def start_ble_gatts(advertismentname="Sol_Lamp", blinking=False):
    advertismentname = advertismentname + "_" + Wifi_Connection.get_mac_address()
    print("Solarlampenservice sollte mit dem Namen: ", advertismentname, " beworben werden")

    restart_bluetooth()

    UART_SERVICE = '6E400003-B5A3-F393-E0A9-E50E24DCCA9A'
    RX_CHARACTERISTIC = '6E400003-B5A3-F393-E0A9-E50E24DCCA90'
    TX_CHARACTERISTIC = '6E400003-B5A3-F393-E0A9-E50E24DCCA9B'

    ble_uart = peripheral.Peripheral(list(adapter.Adapter.available())[0].address, local_name=advertismentname)
    ble_uart.add_service(srv_id=1, uuid=UART_SERVICE, primary=True)
    ble_uart.add_characteristic(srv_id=1, chr_id=1, uuid=RX_CHARACTERISTIC,
                                value=[], notifying=False,
                                flags=['write', 'write-without-response'],
                                write_callback=UARTDevice.uart_write,
                                read_callback=UARTDevice.uart_read,
                                notify_callback=None)
    ble_uart.add_characteristic(srv_id=1, chr_id=2, uuid=TX_CHARACTERISTIC,
                                value=[], notifying=True,
                                flags=['notify', 'read', 'write'],
                                notify_callback=UARTDevice.uart_notify,
                                read_callback=UARTDevice.uart_read,
                                write_callback=None)


    ble_uart.on_connect = UARTDevice.on_connect
    ble_uart.on_disconnect = UARTDevice.on_disconnect

    UARTDevice.blinking = blinking

    if blinking:
        UARTDevice.bt_blink_thread.start()
    ble_uart.publish()


# Start the BLE GATT server
# start_ble_gatts()
