import json
import time

import board
import digitalio


# Pin18 geht auf high wenn ladestecker steckt, und low wenn nicht


class CheckLoading:
    def __init__(self):

        self.pin = digitalio.DigitalInOut(board.D18)
        self.pin.direction = digitalio.Direction.INPUT
        self.pin.pull = digitalio.Pull.DOWN
        self.isattached = None

    def check_if_is_loading(self):

        if self.pin.value == 1:
            # print("Ladestecker ist angesteckt")
            self.isattached = True
            # da der boolean in lampmodel isSolarpored heisst => false
            return "false"

        else:
            # print("Ladestecker ist nicht angesteckt")
            self.isattached = False
            # da der boolean in lampmodel isSolarpored heisst => true
            return "true"

    # wenn der dc Stecker nicht steckt wird der boolean von isSolarpored auf true gesetzt ansonsten auf False weil storm über DV bezogen
    def write_is_solarpowered(self):

        with open("current_lampmodel.json", "r+") as file:
            # Laden Sie die Daten aus der JSON-Datei
            data = json.load(file)
            # Aktualisieren Sie das 'isSolarPowered' Attribut
            data['isSolarPowered'] = self.check_if_is_loading()
            # Setzen Sie den Cursor an den Anfang der Datei, bevor Sie sie überschreiben
            file.seek(0)
            # Schreiben Sie das aktualisierte Datenobjekt zurück in die JSON-Datei
            json.dump(data, file)
            # Kürzen Sie die Datei, falls die neue Datenmenge kleiner ist als die alte
            file.truncate()


checkloading = CheckLoading()
