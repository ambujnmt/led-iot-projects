import json
import multiprocessing
import subprocess
import os
import hashlib
import time
import stat
import requests
import schedule

#Anderer Testtoken:
#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

#Clone Command mit Token :https://${GITHUB_TOKEN}:@github.com/${GITHUB_REPOSITORY}

BASE_PATH = "/home/Solarlampe/Solarlamp_on_raspi"   #Basispfad für das Softwareprojekt
REPO_URL = "https://github.com/achitin/Solarlampe_Test.git" #URL für das Repositiory
DOWNLOAD_PATH = BASE_PATH + "/update_files"
BACKUP_PATH = BASE_PATH + "/backup" #Pfad für die Sicherng der aktuellen Projektdateien um Rollback zu ermöglichen
PRODUCTION_PATH = BASE_PATH + "/production" #pfad der aktuell eingesetzten Softwareversion
GITHUB_TOKEN = "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"#os.environ.get('GITHUB_TOKEN')
GITHUB_OWNER_NAME = "achitin"
GITHUB_REPO_NAME = "Solarlampe_Test"
DOWNLOAD_URL = REPO_URL.replace("https://", f"https://{GITHUB_TOKEN}:@")
#GITHUB_TOKEN2 = os.environ['GITHUB_TOKEN']

#Debugging prüfung der Pfade
print("Base Path ist aktuell: ", BASE_PATH)
print("Path für Production: ", PRODUCTION_PATH)
print("Pfad für Backupdateien: ", BACKUP_PATH)
print("GITHUB_TOKEN: ", GITHUB_TOKEN)
print("FULL DL PATH: ", DOWNLOAD_URL)


class UpdateManager:

    def __init__(self):
        # non blocking process function
        self.updatecheckbackgroundprocess = None
        #Prüfungsintervall in Minuten für Updateabfrage
        self.checkintervall = 1
        #Scheduler Job um alle checkintervall Minuten auf Update zu prüfen
        self.schedulerjob = None
        #Stopevent um multiprocessing-loop zu beenden
        self.stopevent = multiprocessing.Event()
        #Multiprocessing lock um sicherzustellen das nur 1 prozess auf Klassenvariablen zugriff haben
        self.lock = multiprocessing.Lock()
        #zum tracken ob ein Update vorhanden ist muss ein multiproccessing value sein um den wert aus einem multiprocess heraus ändern zu können.
        self.updateavailable = multiprocessing.Value('b', False)
        self.performingupdate = False


    def reboot_system(self):
        import subprocess
        subprocess.run(["sudo", "reboot"])

    def get_isperformingupdate(self):
        return self.performingupdate

    def incerment_update_attempts(self):
        os.chdir(PRODUCTION_PATH)
        with open("Update_Info.json", "r+") as file:
            data = json.load(file)

            currentupdateattempts = int(data["updateattempts"])
            newupdateattempts = currentupdateattempts + 1
            # Aktualisiere den Wert des Schlüssels "latest_firmware_version"
            data["updateattempts"] = f"{newupdateattempts}"
            # Setze den Dateizeiger auf den Anfang der Datei
            file.seek(0)
            # Schreibe das aktualisierte Datenobjekt zurück in die JSON-Datei
            json.dump(data, file)
            file.truncate()

    def reset_update_attempts(self):
        print("Updateattempts werden zurückgesetzt")
        with open("Update_Info.json", "r+") as file:
            data = json.load(file)
            newupdateattempts = "0"
            # Aktualisiere den Wert des Schlüssels "latest_firmware_version"
            data["updateattempts"] = f"{newupdateattempts}"
            # Setze den Dateizeiger auf den Anfang der Datei
            file.seek(0)
            # Schreibe das aktualisierte Datenobjekt zurück in die JSON-Datei
            json.dump(data, file)
            file.truncate()

    #loop um in einem bestimmten intervall zu prüfen ob ein update vorhanden ist
    def upateversioncheckloop(self, stopevent):
        if self.schedulerjob == None:
            self.schedulerjob = schedule.every(self.checkintervall).minutes.do(self.is_update_available)
        while True:
            if stopevent.is_set():
                print("Stopevent wurde getriggert, update scheint vorhanden zu sein!!!")
                print("neues Update steht zur Verfügung, beende scheduling prozess und initiere reboot des Systems um "
                      "Update durchzuführen")
                schedule.cancel_job(self.schedulerjob)
                print("scheduler job wurde gecanceled")
                print("Beende nun die funktion, Prozess sollte dann keine Prints mehr ausgeben")
                #print("Initiere Reboot in 10 Sekunden um Updatevorgang zu initialisieren")
                print("Initiere Updatevorgang in 10 Sekunden")
                time.sleep(10)
                self.update_system()
                return
            schedule.run_pending()
            time.sleep(1)

    def startupdatebackgroundcheck(self):
        self.updatecheckbackgroundprocess = multiprocessing.Process(target=self.upateversioncheckloop, args=(self.stopevent,))
        self.updatecheckbackgroundprocess.start()

    # gibt True zurück wenn ein Update durchgeführt werden kann, gibt False zurück wenn Software bereits auf dem aktuellsten Stand
    def is_update_available(self):
        with self.lock:
            # Holen des Firmware Softwarestands
            current_version = self.get_current_version_number()
            latest_version = self.get_latest_version()

            if current_version is None or latest_version is None:
                #print("Konnte Version nicht vergleichen, versuche Update durchzuführen...")
                # Ein Fehler ist aufgetreten, daher kann der Update-Status nicht bestimmt werden,
                # daher versuchen die neuste version zu installieren
                self.updateavailable.value = True
                self.stopevent.set()
                return True

            # Entferne das Präfix "v." aus den Versionsnummern
            current_version_parts = current_version.replace("v.", "").split(".")
            latest_version_parts = latest_version.replace("v.", "").split(".")
            #print("Gebe die gesplitteten Parts aus..")
            #print(current_version_parts)
            #print(latest_version_parts)
            #print("Debugging is_update_available: ", self.updateavailable.value)

            # Vergleiche die einzelnen Teile der Versionsnummern (Major, Minor, Patch)
            for i in range(len(current_version_parts)):
                current_part = int(current_version_parts[i])
                latest_part = int(latest_version_parts[i])

                if latest_part > current_part:
                    self.updateavailable.value = True
                    self.stopevent.set()
                    print("Debugging is_update_available, check ok hat erkannt das ein Update zur Verfügung steht")
                    return True  # Eine neuere Version ist verfügbar

            # Wenn alle Teile der Versionsnummern übereinstimmen, gibt es keine Aktualisierung
            self.updateavailable.value = False
            return False

    # Funktioniert
    def get_current_version_number(self):
        # Funktion zum Abrufen der derzeit installierten Version
        with open ("Update_Info.json", "r") as f:
            data = json.load(f)
            if "current_firmware_version" in data:
                return data["current_firmware_version"]
            else:
                return None


    def update_current_version_number(self):
        os.chdir(PRODUCTION_PATH)
        with open("Update_Info.json", "r+") as file:
            data = json.load(file)

            # Aktualisiere den Wert des Schlüssels "latest_firmware_version"
            data["current_firmware_version"] = data["latest_firmware_version"]
            # Setze den Dateizeiger auf den Anfang der Datei
            file.seek(0)

            print("die neue Softwareversion ist: ", data["current_firmware_version"])
            # Schreibe das aktualisierte Datenobjekt zurück in die JSON-Datei
            json.dump(data, file)
            file.truncate()




    # Funktioniert mit Token!
    #Gibt zurück ob eine neuere Version vorhanden ist, aktuallisert latest_firmware_version in der Update_Info.json
    def get_latest_version(self, repo_owner = GITHUB_OWNER_NAME, repo_name = GITHUB_REPO_NAME, github_token = GITHUB_TOKEN):
        url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/releases/latest"
        # Führe die Curl-Anfrage aus und leite die Ausgabe an jq weiter
        curl_command = [
            "curl",
            "-s",
            "-H", f"Authorization: token {github_token}",
            url
        ]

        jq_command = [
            "jq",
            "-r",
            ".tag_name"
        ]

        try:
            curl_process = subprocess.Popen(curl_command, stdout=subprocess.PIPE)
            jq_process = subprocess.Popen(jq_command, stdin=curl_process.stdout, stdout=subprocess.PIPE, text=True)
            output, _ = jq_process.communicate()
            #schreibe den erhaltenen Werti in Update_Info Json um Abgleiche mit der App zu gewährleisten
            import json

            # Öffne die JSON-Datei zum Lesen und Schreiben
            os.chdir(PRODUCTION_PATH)

            print("erhaltene version von Git: ", output.strip())

            with open("Update_Info.json", "r+") as file:
                data = json.load(file)

                # Aktualisiere den Wert des Schlüssels "latest_firmware_version"
                data["latest_firmware_version"] = output.strip()
                # Setze den Dateizeiger auf den Anfang der Datei
                file.seek(0)

                print("die aktuellste Softwareversion ist: ", data["latest_firmware_version"])
                # Schreibe das aktualisierte Datenobjekt zurück in die JSON-Datei
                json.dump(data, file)
                file.truncate()

            print("Die JSON-Datei wurde aktualisiert.")

            return output.strip()  # Entfernt führende und abschließende Leerzeichen und Zeilenumbrüche
        except Exception as e:
            print("Fehler in der Versionsabfrage via Github aufgetreten: ", e)

    #erstellt ein Backup vom aktuellen production ordner und speichert dieses im Verzeichniss Backup
    def backup_current_version(self):
        #os.chdir(BASE_PATH)
        # Funktion zum Erstellen eines Backups der aktuellen Version
        if not os.path.exists(BACKUP_PATH):
            os.makedirs(BACKUP_PATH)
        subprocess.call(["cp", "-r", PRODUCTION_PATH, BACKUP_PATH])

    #Funktioniert
    def restore_backup(self):
        os.chdir(BASE_PATH)
        # Funktion zum Wiederherstellen des Backups
        subprocess.call(["rm", "-r", PRODUCTION_PATH])
        subprocess.call(["cp", "-r", BACKUP_PATH+"/production", PRODUCTION_PATH])
    def install_requirements_from_github_repo(self):
        print("Versuche requirements zu installieren...")
        #Holen der aktuellen version
        updateversion = self.get_latest_version()
        # Wechseln in das geklonte Repository-Verzeichnis
        os.chdir(f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{updateversion}")

        # Installieren der Anforderungen aus der requirements.txt-Datei
        subprocess.call(["pip3", "install", "-r", "requirements.txt"])
        subprocess.call(["sudo", "pip3", "install", "-r", "requirements.txt"])

        #noch nicht sicher ob zurück auf BASE oder production path
        os.chdir(BASE_PATH)

    def unpack_update_tar_file(self):
        tar_file = f"{DOWNLOAD_PATH}/update"  #  Dateinamen des Archivs
        zielverzeichnis = DOWNLOAD_PATH  # Ersetze mit dem Pfad zum Verzeichnis, in das entpackt wird
        # Führe den tar-Befehl aus, um das Archiv zu entpacken
        subprocess.run(["tar", "xzvf", tar_file, "-C", zielverzeichnis])
        self.remove_update_tar_file()
    def remove_update_tar_file(self):
        try:
            tar_file = f"{DOWNLOAD_PATH}/update"  # Dateinamen des Archivs
            subprocess.call(["sudo", "rm", tar_file])
        except:
            print("Keine updatedatei zum entfernen gefunden!")
            pass

    def apply_permissions_on_new_update_files(self):
        #äquivalent zu chmod +x

        version = self.get_latest_version()
        path = f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{version}"
        print("Apply Permission wird ausgeführt")
        for root, dirs, files in os.walk(path):
            for file in files:
                print("File gefunden:", file)
                filepath = os.path.join(root, file)
                # Überprüfe, ob die Datei eine Skript- oder Python-Datei ist
                if file.endswith((".sh", ".py")):
                    print("Versuche ", file, "mit Ausführungsbrechtigungen zu versorgen")
                    # Hole die aktuelle Berechtigung
                    current_permission = os.stat(file).st_mode
                    # Setze den Ausführungsmodus für den Dateibesitzer, die Gruppe und andere
                    new_permission = current_permission | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
                    # Setze die neuen Berechtigungen für die Datei
                    os.chmod(file, new_permission)
                    print("Ausführungsrechte wurde gesetzt")

    def download_update_files(self, owner = GITHUB_OWNER_NAME, repo = GITHUB_REPO_NAME, token = GITHUB_TOKEN):

        os.chdir(DOWNLOAD_PATH)
        version = self.get_latest_version()
        url = f"https://github.com/{owner}/{repo}/archive/refs/tags/{version}.tar.gz"


        print("Aufrufurl für download:",url)
        print(url)

        headers = {"Authorization": f"token {token}"}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            with open(f"{DOWNLOAD_PATH}/update", 'wb+') as file:
                file.write(response.content)
            print(f"Source Tar-File wurde heruntergeladen und gespeichert unter: {DOWNLOAD_PATH}")

            #entpacke heruntergeladenes archiv
            print("Entpacke Update tar file")
            self.unpack_update_tar_file()
            print("Setze berechtigungen für neue Skripte")
            #Setze Ausführungsbrechetigungen auf neu heruntergeladene Files
            self.apply_permissions_on_new_update_files()
        else:
            print(f"Fehler beim Herunterladen des Source Tar-Files: {response.status_code}")

    # Funktion zum Überprüfen der Datei-Checksummen
    def verify_checksums(self):
        checksums = self.read_checksums_from_SHASUMS()
        version = self.get_latest_version()
        updatefolderpath = f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{version}"
        # Iteriere durch das Verzeichnis
        for root, dirs, files in os.walk(updatefolderpath):
            for file in files:
                #ausnahme hinzufügen wenn es sich um SHASUMS handelt da diese nicht die aktuelle SHA von sich selbst enthalten kann
                if file == 'SHASUMS.txt':  # Überspringe die SHASUMS.txt-Datei
                    continue
                file_path = os.path.join(root, file)
                relative_file_path = os.path.relpath(file_path, updatefolderpath)
                # Berechne die Checksumme der Datei
                file_checksum = self.calculate_sha256(file_path)
                # Hole die erwartete Checksumme
                expected_checksum = checksums.get('./' + relative_file_path)
                # Vergleiche sie
                if expected_checksum != file_checksum:
                    print("expected checksum: ", expected_checksum, " file checksum: ", file_checksum)
                    print(f"Checksumme stimmt nicht überein für: {file}")
                    return False
                else:
                    print(f"Checksumme ist gültig für: {file}")
                    continue
        return True


    def read_checksums_from_SHASUMS(self):
        version = self.get_latest_version()
        shasums_filepath = f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{version}/SHASUMS.txt"
        checksums = {}
        with open(shasums_filepath, 'r') as file:
            for line in file:
                parts = line.strip().split('  ')
                if len(parts) == 2:
                    # Speichern Sie den Pfad so, wie er in der SHASUMS.txt-Datei steht
                    checksums[parts[1].strip()] = parts[0].strip()
        return checksums

    # Funktion zum Berechnen der SHA256-Checksumme einer Datei
    def calculate_sha256(self, file_path):
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def update_expected_app_versions(self):


        print("Versuche expected app version heraufzustufen...")
        #wechsel in das Wurzelverzeichnis
        os.chdir(BASE_PATH)
        version = self.get_latest_version()
        #variable um aus dem heruntergeladenen package die minimum Appversion herauszulesen
        neededappverandroid = None
        neededappverios = None
        updatefolderpath = f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{version}"
        with open(f"{updatefolderpath}/minimum_app_ver.json", "r") as minimumappverfile:
            versiondata = json.load(minimumappverfile)
            neededappverandroid = versiondata["expected_app_version_android"]
            neededappverios = versiondata["expected_app_version_ios"]
            print("erhaltene app version werte aus repo Android: ", neededappverandroid, " / Ios: ", neededappverios)

        os.chdir(PRODUCTION_PATH)
        print("aktuallisere expected app version Values in Update_Info.json im production verzeichniss")
        with open("Update_Info.json", "r+") as file:
            data = json.load(file)

            # Aktualisiere den Wert der Schlüssel expected_app_version_ios und expected_app_version_android
            data["expected_app_version_ios"] = neededappverios
            data["expected_app_version_android"] = neededappverandroid
            # Setze den Dateizeiger auf den Anfang der Datei
            file.seek(0)

            # Schreibe das aktualisierte Datenobjekt zurück in die JSON-Datei
            json.dump(data, file)
            file.truncate()

        print("Die JSON-Datei wurde aktualisiert.")



    def move_update_files_to_production(self):
        try:
            os.chdir(BASE_PATH)
            #pfad der aktuellen update folders ermitteln
            version = self.get_latest_version()
            update_path = f"{DOWNLOAD_PATH}/{GITHUB_REPO_NAME}-{version}/."
            command = f"cp -r {update_path}/* {PRODUCTION_PATH}"
            subprocess.call(command, shell=True)
            print("Updatedateien wurde erfolgreich ins production Verzeichniss kopiert")
            return True
        except Exception as e:
            print("Konnte Updatedateien nicht ins productivsystem übernehmen: ",e)
            return False

    def update_system(self, manual = False):
        try:
            print("Prüfe ob update vorhanden ist----")
            if self.is_update_available() == True:
                self.performingupdate =True
                self.incerment_update_attempts()
                print("Update steht zur Verfügung beginne installation...")
                print("Sicherung des aktuellen Softwareversion...")
                # Backup der aktuellen Version
                self.backup_current_version()
                #Download der Update Files und signierung
                print("Lade Update herunter....")
                self.download_update_files()
                self.update_expected_app_versions()

            else:
                print("Kein Update verfügbar, breche ab...")
                return

            print("Verifiziere download...")
            if self.verify_checksums() == False:
                raise Exception


            # installationen der Python requirements
            self.install_requirements_from_github_repo()
            if self.move_update_files_to_production() == False:
                raise Exception
            else:
                print("Update erfolgreich durchgeführt, aktuallisere Firmware version im Json File")
                self.update_current_version_number()
                print("Versuche attempts zurückzusetzen")
                self.reset_update_attempts()
                print("Versionsnummer wurde in der Json aktuallisiert, starte System neu...")
                if manual == False:
                    self.reboot_system()
                else:
                    return True
                #delay um informationsaustausch mit der App zu ermöglichen
                time.sleep(5)
                self.reboot_system()

        except Exception as e:

            print(f"Update failed: {str(e)}")
            print("Initiating rollback...")
            self.restore_backup()
            print("Rollback completed")
            self.performingupdate = False


updatemanager = UpdateManager()

if __name__ == "__main__":




    #print("main ausgeführt update manager")
    #print("Welche version ist auf dem Repo vorhanden")
    #print(updatemanager.get_latest_version())
    #print("Weche version ist auf dem System laut Json installiert?")
    #print(updatemanager.get_current_version_number())

    #updatemanager.startupdatebackgroundcheck()

    #backup_current_version()
    updatemanager.read_checksums_from_SHASUMS()
    time.sleep(1)
    print("Checksummenprüfung erfolgreich?: ", updatemanager.verify_checksums())

    #restore_backup()


    #print("Versuche nun Testdateien zu downloaden....")

    #download_update_files()

    #print("Versuche nun via pip dependencies zu installieren...")
    #install_requirements_from_github_repo()

    #print("Kein Fehler anscheinend")

    #print("Test entferne update archiv")
    #remove_update_tar_file()


    #backup_current_version()
    #restore_backup()


    #update_system()







