
#installieren von git für den download für beispielsweise MicrodotWebserver:
sudo apt install git python3-pip
git clone https://github.com/miguelgrinberg/microdot.git

#ich weiß noch nicht wo die PYthon Files installiert werden aber hier die restlichen schritte

cd microdot


sudo pip3 install .


#installieren des Microdot Webservers:



# Installing Bluetooth Dependencies:
sudo apt-get install bluetooth libbluetooth-dev
sudo pip3 install pybluez


# installing WIFI Dependencies

sudo pip3 install wifi

# installieren der Neopixel Bibliothek + Blinka welche diese mit dem Raspberry Kompatibel macht:
sudo pip3 install rpi_ws281x adafruit-circuitpython-neopixel
sudo python3 -m pip install --force-reinstall adafruit-blinka