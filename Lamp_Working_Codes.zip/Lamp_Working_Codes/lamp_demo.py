import threading

from tilt_motor_control import Tilt_MotorControl
from rotation_motor_control import *
import board


class Motormovement_Demo:

    def __init__(self):

        self.isrunning = False
        # Create a MotorControl instance
        self.motor_control_tilt = Tilt_MotorControl(board.D25, board.D24)  # assign correct pins here
        self.motor_control_rotation = Rotation_MotorControl(board.D25, board.D24)  # assign correct pins here

    def stop_demo(self):
        self.isrunning = False
        self.motor_control_rotation.reset_rotation()
        return


    def start_demo(self, stop_event):
        self.isrunning = True
        default_speed = 30
        while not stop_event.is_set():
            # 180° gegen den Uhrzeigersinn dann 180° zurück
            print("reseting to start position")
            self.motor_control_rotation.reset_rotation()
            print("rotating 180° Counterclockwise")
            self.motor_control_rotation.run(-5, default_speed)
            time.sleep(3)
            print("rotating back to 0° with different speed")
            self.motor_control_rotation.run(0, default_speed)
            time.sleep(3)
            print("END Demo Step 1")
            # tilt 20° nach vorne, dann auf -20° zurück
            self.motor_control_tilt.run(20, default_speed)
            self.motor_control_tilt.run(-20, default_speed)
            print("END Demo Step 2")
            # 180° nach links währenddessen 20° neigen, zurück auf 0° und währenddessen auf -20° neigen

            print("END Demo Step 3")
            # neigung auf 0° reseten
            print("END Demo Step 4")
            # Pause 33 Sekunden
            print("END Demo Step 5")
            # Starte wieder bei Step 1
            if stop_event.is_set():
                self.stop_demo()
                print("Stop_event erhalten für motor")
                return
