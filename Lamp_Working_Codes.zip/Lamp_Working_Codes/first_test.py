# # import RPi.GPIO as GPIO
# import board
# import digitalio
# import time
#
# Dir_pin = digitalio.DigitalInOut(board.D24)
# Dir_pin.direction = digitalio.Direction.OUTPUT
# Step_pin = digitalio.DigitalInOut(board.D25)
# Step_pin.direction = digitalio.Direction.OUTPUT
#
#
#
# # # Set the GPIO mode to BCM
# # GPIO.setmode(GPIO.BCM)
# #
# # Dir_pin = GPIO.setup(24, GPIO.OUT)
# # Step_pin = GPIO.setup(25, GPIO.OUT)
#
# # # Define the GPIO pins
# # pins = [24, 25]
# #
# # # Set the pins as outputs
# # for pin in pins:
# #     GPIO.setup(pin, GPIO.OUT)
#
#
#
# Dir_pin.value = True #Direction pin setting
#
# # Define the number of steps per revolution and desired RPM
# steps_per_revolution = 200  # Change this to match your stepper motor
# desired_rpm = 60  # Desired rotations per minute
#
# # Calculate the delay between steps based on RPM
# delay = 60.0 / (desired_rpm * steps_per_revolution)
#
# # Calculate the number of steps for a 10-degree rotation
# degrees_per_step = 360 / (steps_per_revolution * 256)  # Degrees per step for 1/256 microstepping || 360° / (steps per revolution * microstep value)
# desired_angle = 1  # Desired rotation angle in degrees
# num_steps = int(round(desired_angle*3.5 / degrees_per_step)) # =498 = around 1 degree
# print(num_steps)
#
# # Step the motor for the specified number of steps
# for _ in range(num_steps):
#     Step_pin.value = True
#     time.sleep(0.0000025)
#     Step_pin.value = False
#     time.sleep(0.0000025)
#
#
#
# # while True:
# #         # GPIO.output(Dir_pin, GPIO.HIGH)
# #         # GPIO.output(Step_pin, GPIO.HIGH)
# #     print("hier passiert was")
# #
# #     Step_pin.value = True
# #     time.sleep(0.001)
# #
# #     Step_pin.value = False
#
#         # for i in range(10):
#         #     GPIO.output(Step_pin, GPIO.HIGH)
#         #     print("hier for schleife")
#         #
#         # print("hier passiert was, vll")
#         # time.sleep(0.2)
#         # GPIO.output(Dir_pin,GPIO.LOW)
# #     GPIO.output(Step_pin,GPIO.HIGH)
#
#


import board
import digitalio
import time

# Create DigitalInOut objects for the direction and step pins
Dir_pin = digitalio.DigitalInOut(board.D24)
Dir_pin.direction = digitalio.Direction.OUTPUT
Step_pin = digitalio.DigitalInOut(board.D10)
Step_pin.direction = digitalio.Direction.OUTPUT
En_pin = digitalio.DigitalInOut(board.D11)
En_pin.direction = digitalio.Direction.OUTPUT
# Set the initial direction and angle
Dir_pin.value = True  # Change this as needed
current_angle = 0  # Initialize the current angle to 0 degrees

# Define the number of steps per revolution and desired RPM
steps_per_revolution = 200  # Change this to match your stepper motor
desired_rpm = 60  # Desired rotations per minute

# Calculate the delay between steps based on RPM
delay = 60.0 / (desired_rpm * steps_per_revolution)

# Calculate the number of steps for a 10-degree rotation
degrees_per_step = 1.7/1138  # Degrees per step for 1/256 microstepping

# Initialize a flag to track direction change
direction_changed = False
print("test")

def motor_movement(num_steps):
    for _ in range(abs(num_steps)):
        Step_pin.value = True
        time.sleep(0.005/200)
        Step_pin.value = False
        time.sleep(0.005/200)


while True:
    try:
        # Get the desired angle from the user
        user_input = float(input("Enter desired angle in degrees (0 to exit): "))

        if user_input == '0':
            # If the desired angle is 0, return to 0 degrees
            num_steps = int(round(current_angle / degrees_per_step))
            Dir_pin.value = not Dir_pin.value  # Reverse direction if needed
        else:
            # Calculate the number of steps to reach the desired angle
            desired_angle = float(user_input)

            num_steps = int(round((desired_angle - current_angle) / degrees_per_step))
            Dir_pin.value = desired_angle > current_angle  # Set direction based on the desired angle


        print(f"Desired Angle: {desired_angle} degrees")
        print(f"Steps to move: {num_steps}")

        # Step the motor for the specified number of steps
        motor_movement(num_steps)

        # Update the current angle
        current_angle = desired_angle

    except ValueError:
        print("Invalid input. Please enter a valid angle in degrees.")

    except KeyboardInterrupt:
        print("Exiting the program.")
        break




# def move_8_degrees_left_and_right():
#     # Move 8 degrees left
#     num_steps = int(round(8 / degrees_per_step))
#     Dir_pin.value = False  # Set direction to move left
#     for _ in range(num_steps):
#         Step_pin.value = True
#         time.sleep(0.0000025)
#         Step_pin.value = False
#         time.sleep(0.0000025)
#
#     # Move 8 degrees right
#     num_steps = int(round(8 / degrees_per_step))
#     Dir_pin.value = True  # Set direction to move right
#     for _ in range(num_steps):
#         Step_pin.value = True
#         time.sleep(0.0000025)
#         Step_pin.value = False
#         time.sleep(0.0000025)
