import threading


class SharedResources:
    def __init__(self):
        self.stop_event = threading.Event()
        self.stop_event_rotate = threading.Event()
        self.stop_event_tilt = threading.Event()
        self.tilt_running = False


shared_resources = SharedResources()
