import multiprocessing

import board
import neopixel

from led_programmliste import manager
import time

import random
import gc


class bt_led:
    def __init__(self):

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3 * self.NUM_LEDS_BOTTOM)

        self.PIN = board.D12  # 18

        # neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4, brightness=0.3)

        self.isconnected = False
        self.noblinking = False

        print("BluetoothLED wurde initialisiert")

    def np_top_array(self, position, value):

        self.np[position] = value

    def np_mid_array(self, position, value):

        # print("Position mid array: ", position)

        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID - 1] = value

    def bottom2_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM - 1] = value

    def bottom3_array(self, position, value):

        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (self.NUM_LEDS_BOTTOM * 2) - 1] = value

    def connected(self):
        print("connected getriggert")
        time.sleep(1)
        self.np.fill((0, 0, 255, 0))
        self.np.show()
        self.np.fill((0, 0, 255, 0))
        self.np.show()

    def advertisingblinking(self, stop_event):

        gc.enable()

        while True:

            if stop_event.is_set():
                return
            if self.isconnected == True:
                return

            if stop_event.is_set():
                self.stop()
                return

            if self.connected == True:
                if self.noblinking == False:
                    self.np.fill((0, 0, 255, 0))
                    self.np.show()
                    self.noblinking = True
            elif self.connected == False and self.noblinking == True:
                self.noblinking = False

            self.np.fill((0, 0, 255, 0))
            self.np.show()
            time.sleep(0.10)
            self.np.fill((0, 0, 0, 0))
            self.np.show()
            time.sleep(0.10)
            self.np.fill((0, 0, 255, 0))
            self.np.show()
            time.sleep(0.10)
            self.np.fill((0, 0, 0, 0))
            self.np.show()
            time.sleep(1)

            if stop_event.is_set():
                self.stop()
                return

    def bt_stop(self):
        self.np.fill((0, 0, 0, 0))

        self.np.write()

    def stop(self):
        self.rainbow_on = False
        self.bt_stop()
        self.np.deinit()
