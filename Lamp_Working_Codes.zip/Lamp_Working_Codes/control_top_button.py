import board
import busio
import digitalio
import time
import neopixel
from i2c_devices_new.at42qt.odt_at42qt1050 import AT42QT1070
import json
import threading
import os
from urllib.parse import urlencode
import requests


class TouchHandler:
    def __init__(self, manager=None):
        self.stopevent = threading.Event()
        self.manager = manager

        # Initialize I2C and touch sensor
        i2c = busio.I2C(board.SCL, board.SDA)
        self.qtouch = AT42QT1070(i2c, address=0x41)
        self.qtouch.set_key_neg_threshold(0, 255)
        self.qtouch.setpulseandscale(4)
        self.qtouch.set_di(8)

        self.last_press_time = 0
        self.press_start_time = 0
        self.last_touch_state = False
        self.is_long_press_active = False
        self.debounce_time = 0.05  # 50 milliseconds debounce period
        self.double_tap_window = 1  # Time window for detecting double taps
        self.long_press_threshold = 3  # Time threshold in seconds for a long press
        self.repeat_interval = 3  # Interval for repeating gesture_4 call
        self.press_lengths = []  # Track lengths of button presses
        self.pause_on = False
        script_dir = os.path.dirname(os.path.realpath(__file__))
        self.json_filename_lamp = os.path.join(script_dir, 'current_lampmodel.json')

        # Configuration for the top LEDs
        NUM_LEDS_TOP = 10
        PIN = board.D12
        self.np_top = neopixel.NeoPixel(PIN, NUM_LEDS_TOP, bpp=4)

    def checkloop(self, stopevent):
        while not stopevent.is_set():
            self.update_touch()

    def startbackgrounddetection(self):
        self.background_thread = threading.Thread(target=self.checkloop, args=(self.stopevent,))
        self.background_thread.start()

    def update_touch(self):
        current_time = time.time()
        current_touch_state = self.qtouch.this_key_touched(0)

        if current_touch_state != self.last_touch_state:
            if (current_time - self.last_press_time) > self.debounce_time:
                self.last_press_time = current_time
                self.last_touch_state = current_touch_state
                if current_touch_state:
                    self.press_start_time = current_time
                else:
                    if self.is_long_press_active:
                        self.is_long_press_active = False
                    else:
                        press_length = current_time - self.press_start_time
                        self.press_lengths.append(press_length)
                        self.handle_releases()
        elif current_touch_state and (current_time - self.press_start_time) > self.long_press_threshold:
            if not self.is_long_press_active:
                self.is_long_press_active = True
                self.gesture_4_start(current_time)

        time.sleep(0.001)

    def handle_releases(self):
        if len(self.press_lengths) == 1:
            start_wait_time = time.time()
            while time.time() - start_wait_time < self.double_tap_window:
                self.update_touch()  # Check for a second press
                if len(self.press_lengths) == 2:
                    break
            self.evaluate_presses()

    def evaluate_presses(self):
        num_presses = len(self.press_lengths)
        if num_presses == 1:
            press_length = self.press_lengths[0]
            if press_length <= 1:
                self.gesture_2()
            elif 1 < press_length <= 3:
                self.gesture_1()
        elif num_presses == 2:
            if all(x <= 1 for x in self.press_lengths):
                self.gesture_3()
        self.press_lengths.clear()

    def gesture_1(self):
        print("Gesture 1 detected: One long tap (1-3 seconds)")
        if self.pause_on:
            self.pause_on = False
            self.unpause()
        else:
            self.pause_on = True
            self.pause()

    def gesture_2(self):
        print("Gesture 2 detected: One short tap")
        self.nextprogramm()

    def gesture_3(self):
        print("Gesture 3 detected: Two short taps")
        self.previousprogramm()

    def gesture_4_start(self, start_time):
        print("Gesture 4 started: Long hold (longer than 3 seconds)")
        last_called_time = start_time
        while self.qtouch.this_key_touched(0):  # While the touch is still active
            current_time = time.time()
            if current_time - last_called_time >= self.repeat_interval:
                self.gesture_4()
                last_called_time = current_time
            time.sleep(0.1)  # Check touch state at regular intervals during long press

    def gesture_4(self):
        print("Gesture 4 detected: Long hold (continuously while pressed)")
        self.dimming()

    def nextprogramm(self):
        print("Next program triggered")
        if self.manager is None:
            return
        self.manager.next_program()

    def previousprogramm(self):
        print("Previous program triggered")
        if self.manager is None:
            return
        self.manager.previous_program()

    def pause(self):
        print("Pause triggered")
        if self.manager is None:
            return
        self.manager.stop_led_Process()
        print("Pause triggered")

    def unpause(self):
        print("Resume triggered")
        if self.manager is None:
            return
        current_program = self.manager.getcurrentprogramm()
        data = self.get_data()
        self.manager.start_named_program(current_program, data)

    def get_data(self):
        with open(self.json_filename_lamp, "r") as file:
            current_data = json.load(file)
            return current_data

    def dimming(self):
        if self.manager is None:
            print("Manager is None")
            return

        current = self.manager.getcurrentprogramm()
        if current != "Benutzerdefiniert":
            print("Benutzerdefiniert nicht aktiv")
            return

        print("Start dimming... (Release button to stop)")
        time.sleep(0.5)

        if self.qtouch.this_key_touched(0):
            print("Dimming in progress...")
            try:
                with open(self.json_filename_lamp, 'r') as file:
                    data = json.load(file)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"Error reading the JSON file: {e}")
                data = {}

            dim1 = float(data.get('dimmValue1', "0")) - 10
            dim2 = float(data.get('dimmValue2', "0")) - 10
            dim3 = float(data.get('dimmValue3', "0")) - 10

            if dim1 < 0:
                dim1 += 100
            if dim2 < 0:
                dim2 += 100
            if dim3 < 0:
                dim3 += 100

            data['dimmValue1'] = str(dim1)
            data['dimmValue2'] = str(dim2)
            data['dimmValue3'] = str(dim3)

            url = 'http://0.0.0.0:80/updatelamp'
            url_encoded_data = urlencode(data, encoding='utf-8')
            response = requests.post(url, data=url_encoded_data)

            print(response.text)

            try:
                with open(self.json_filename_lamp, 'w') as file:
                    json.dump(data, file, indent=4)
            except IOError as e:
                print(f"Error writing to the JSON file: {e}")
        else:
            print("Button was quickly released. No dimming.")

# Example usage of the class
# if __name__ == "__main__":
#     touch_handler = TouchHandler()
#     try:
#         while True:
#             touch_handler.update_touch()
#             time.sleep(0.01)  # Reduce CPU usage with a small delay
#     except KeyboardInterrupt:
#         print("Program stopped manually")
