import multiprocessing
import time
import board
import neopixel
from led_programmliste import manager


class LEDController:
    def __init__(self, touch_enabled):
        self.num_leds_top = 10
        self.num_leds_mid = 98
        self.num_leds_bottom = 12
        self.total_led_count = self.num_leds_top + self.num_leds_mid + 3 * self.num_leds_bottom
        self.pin = board.D12

        self.touch_enabled = touch_enabled
        manager.add_program(self)
        self.paused = False
        self.led_strip = neopixel.NeoPixel(self.pin, self.total_led_count, auto_write=False, bpp=4)
        self.is_running = False

        self.indigo_web_color = (75, 0, 130, 0)
        self.indigo_spectral_color = (111, 0, 255, 0)
        self.transition_colors = [
            (8, 0, 15, 0), (8, 0, 17, 0), (9, 0, 19, 0), (9, 0, 20, 0),
            (10, 0, 22, 0), (10, 0, 23, 0), (11, 0, 25, 0), (11, 0, 26, 0)
        ]

    def set_led_color(self, position, color):
        self.led_strip[position] = color

    def dim_and_switch_colors(self, stop_event, change_timing=True):
        dim_steps = 100
        min_brightness = 0.1
        brightness_range = 0.9

        while not stop_event.is_set():
            if self.paused:
                time.sleep(0.01)
                continue

            for phase in ['up', 'down']:
                for step in range(dim_steps) if phase == 'up' else range(dim_steps, 0, -1):
                    if stop_event.is_set():
                        return

                    brightness_factor = min_brightness + (step / dim_steps) * brightness_range
                    self.apply_brightness(self.indigo_web_color, brightness_factor)
                    time.sleep(0.01)

                self.wait_with_stop_check(stop_event, 4.32)

                for color in self.transition_colors if phase == 'up' else reversed(self.transition_colors):
                    if stop_event.is_set():
                        return
                    self.led_strip.fill(color)
                    self.led_strip.show()
                    time.sleep(0.01)

    def apply_brightness(self, color, brightness):
        scaled_color = tuple(int(channel * brightness) for channel in color)
        self.led_strip.fill(scaled_color)
        self.led_strip.show()

    def start(self, stop_event):
        self.is_running = True
        print("LED Program Started!")
        self.dim_and_switch_colors(stop_event)

    def stop(self):
        self.is_running = False
        self.turn_off_leds()

    def turn_off_leds(self):
        self.led_strip.fill((0, 0, 0, 0))
        self.led_strip.show()

    def get_status(self):
        return self.is_running

    def wait_with_stop_check(self, stop_event, timeout):
        start_time = time.time()
        while time.time() - start_time < timeout:
            if stop_event.is_set():
                return
            time.sleep(0.05)


# Usage example:
stop_event = multiprocessing.Event()
controller = LEDController(False)
controller.start(stop_event)
