# import machine
import time
import json
import multiprocessing

from shared_ressources import shared_resources
from lamp_demo_threads import Motormovement_Demo
from control_ladechip import MAX17261
import threading


class LEDProgramManager:
    def __init__(self):
        self.led_demo_process = None
        self.motor_demo_process = None
        self.led_programs = []
        self.current_program = None
        self.led_process = None
        self.stop_event = multiprocessing.Event()
        self.demo_stop_event = multiprocessing.Event()
        self.motor_ini = Motormovement_Demo()
        self.dimming = False
        self.akku = MAX17261()
        self.check_akku_loop = threading.Thread(target=self.check_akku, )
        self.check_akku_loop.start()

    def check_akku(self):
        from check_ist_am_laden import checkloading
        failsave = 0
        while True:
            cable_check = checkloading.check_if_is_loading()
            ladestand = self.akku.run_ladechip()
            # ladestand = 20
            new_dimming = ladestand < 90  # für test zwecke auf 90% gestellt

            if cable_check == "false" and failsave == 0:
                self.dimming = False
                self.stop_led_Process()
                if self.led_process is not None:
                    self.start_program(self.current_program, self.read_lampmodeldata())
                failsave = 1

            if new_dimming != self.dimming and cable_check == "true":
                failsave = 0
                self.dimming = new_dimming
                print(f"Dimming state changed to {self.dimming} due to battery level: {ladestand}%")
                # Restart the current program with the new dimming state
                if self.current_program:
                    with open('current_lampmodel.json', 'r') as file:
                        data = json.load(file)
                    on = data.get("isGlowShowing", "false")
                    print(on, "on------------------")
                    if on == "true":
                        self.stop_led_Process()
                        self.start_program(self.current_program, self.read_lampmodeldata())
                    else:
                        print("kein aktives Led Program")
            time.sleep(30)

    # fügt ein programm in der led Liste hinzu,
    # in jedem led Programm sollte im Init manager.add_programm(self) hinzugefügt werden.
    def add_programm(self, program):
        self.led_programs.append(program)
        print("LED Programm erhalten und der programmliste hinzugefügt: ", program)

    def run_motor_demo(self, stop_event):
        print("run_motor_demo")
        self.motor_ini.start_demo(stop_event)

    def run_led_demo(self, stop_event):
        # Switch LED programs every 10 seconds

        while not stop_event.is_set():
            self.next_program()
            time.sleep(10)
        if stop_event.is_set():
            self.stop_led_Process()

    def start_demo(self):

        if self.demo_stop_event.is_set():
            self.demo_stop_event.clear()

        try:
            with open('current_motor_status.json', 'r') as file:
                json_data_motor = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            print('Could not open Json')
        is_auto = json_data_motor.get('is_auto', False)

        if is_auto == False:
            # Create a new process to run the demo program
            if self.led_demo_process is None:
                self.led_demo_process = multiprocessing.Process(target=self.run_led_demo, args=(self.demo_stop_event,))

            if self.motor_demo_process is None:
                self.motor_demo_process = multiprocessing.Process(target=self.run_motor_demo,
                                                                  args=(self.demo_stop_event,))

            try:
                shared_resources.stop_event_rotate.set()
                shared_resources.stop_event_tilt.set()
                self.led_demo_process.start()
                self.motor_demo_process.start()

            except Exception as e:
                print("Error starting demo program:", e)
        else:
            print("Bitte Auto-Mode beenden")

    def stop_demo(self):
        if (self.motor_demo_process and self.motor_demo_process.is_alive() and self.led_demo_process
                and self.led_demo_process.is_alive()):
            try:
                # Terminate the demo process
                self.demo_stop_event.set()
                self.led_demo_process.join()
                self.motor_demo_process.join()
                self.led_demo_process.terminate()
                self.motor_demo_process.terminate()
                time.sleep(5)
                print("Motor und Demo gestoppt")
            except Exception as e:
                print("Error stopping demo program:", e)
            finally:
                self.led_demo_process = None
                self.motor_demo_process = None

        else:
            print("No running demo process to stop")

    def get_benutzerdefiniert(self):
        for program in self.led_programs:
            if type(program).__name__ == "Benutzerdefiniert":
                return program
        return None

    def get_benutzerdefiniert_parameter_values(self, data):
        if data is None:
            return None
        if data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
            # alle Ebenen anschalten
            return data["color1"], data["color2"], data["color3"], data['dimmValue1'], data['dimmValue2'], data[
                'dimmValue3']

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
            # mid und bottom aktivieren
            return 'Color(0xff000000)', data["color2"], data["color3"], 0.0, data['dimmValue2'], data['dimmValue3']

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
            # top und mid aktivieren
            return data["color1"], data["color2"], 'Color(0xff000000)', data['dimmValue1'], data['dimmValue2'], 0.0

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
            # top und bottom aktivieren
            return data["color1"], 'Color(0xff000000)', data["color3"], data['dimmValue1'], 0.0, data['dimmValue3']

        elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'false':
            # top aktivieren
            return data["color1"], 'Color(0xff000000)', 'Color(0xff000000)', data['dimmValue1'], 0.0, 0.0

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
            # mid aktivieren
            return 'Color(0xff000000)', data["color2"], 'Color(0xff000000)', 0.0, data['dimmValue2'], 0.0

        elif data['isGlow1'] == 'false' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
            # bottom aktivieren
            return 'Color(0xff000000)', 'Color(0xff000000)', data["color3"], 0.0, 0.0, data['dimmValue3']

        else:
            return None

    def update_benutzerdefiniert(self, data):
        benutzerdefiniertprogramm = self.get_benutzerdefiniert()
        if benutzerdefiniertprogramm != None:
            # Abschnitt Logikabfrage:
            if data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':

                # alle Ebenen anschalten

                benutzerdefiniertprogramm.update_Color(data["color1"], data["color2"], data["color3"],
                                                       data['dimmValue1'], data['dimmValue2'], data['dimmValue3'])


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'true':
                # mid und bottom aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', data["color2"], data["color3"], 0.0,
                                                       data['dimmValue2'], data['dimmValue3'])

            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
                # top und mid aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], data["color2"], 'Color(0xff000000)',
                                                       data['dimmValue1'], data['dimmValue2'], 0.0)


            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
                # top und bottom aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], 'Color(0xff000000)', data["color3"],
                                                       data['dimmValue1'], 0.0, data['dimmValue3'])


            elif data['isGlow1'] == 'true' and data['isGlow2'] == 'false' and data['isGlow3'] == 'false':
                # top aktivieren

                benutzerdefiniertprogramm.update_Color(data["color1"], 'Color(0xff000000)', 'Color(0xff000000)',
                                                       data['dimmValue1'], 0.0, 0.0)


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'true' and data['isGlow3'] == 'false':
                # mid aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', data["color2"], 'Color(0xff000000)', 0.0,
                                                       data['dimmValue2'], 0.0)


            elif data['isGlow1'] == 'false' and data['isGlow2'] == 'false' and data['isGlow3'] == 'true':
                # bottom aktivieren

                benutzerdefiniertprogramm.update_Color('Color(0xff000000)', 'Color(0xff000000)', data["color3"], 0.0,
                                                       0.0, data['dimmValue3'])
        else:
            print("Programm Manager: Kein Benutzerdefiniert LED Programm in der Programmliste gefunden")
            return

    def start_named_program(self, program_name, data):
        programmclassname = self.get_programClassName(program_name)

        print("manager start named Programm getriggert!")
        print("manager versuche ", programmclassname, " zu starten..")

        if programmclassname == "Demo":
            self.start_demo()
            print("--------------")
            print("DEMO GESTARTET")
            print("--------------")
            return

        for ledprog in self.led_programs:
            if type(ledprog).__name__ == programmclassname:
                print("LED Manager.start_named_program: passendes Programm zum starten gefunden: ", ledprog)
                print(type(ledprog).__name__)
                self.start_program(ledprog, data)
        return

    def start_program(self, program, data):

        if type(program).__name__ == "Benutzerdefiniert":
            print("Benutzerdefiniert Programm soll im manager gestartet werden ")
            print("prüfe ob Benutzedefiniert bereits läuft und nur update oder start ausgeführt werden muss...")
            self.stop_led_Process()

            params = self.get_benutzerdefiniert_parameter_values(data)
            if params:
                self.benutzerdefiniert_running = True
                print("Jetzte wird der Multiprocess im LED Programm manager funktion start_programm getriggered")
                self.led_process = multiprocessing.Process(target=program.start, args=(self.stop_event, *params))
                self.led_process.start()
                # self.led_process.join()

            else:
                print("Keine gültigen Farbvalues für Benutzerdefiniert aus den Daten erhalten")

        elif self.current_program == program and self.led_process.is_alive():

            print("manager: zu startendes Programm läuft bereits, nichts zu tun")
            self.current_program = program
            return

        else:
            self.stop_led_Process()
            print("manager start programm versuche nun den neuen led_process via multiprocessing zu starten....",
                  program)
            self.led_process = multiprocessing.Process(target=program.start, args=(self.stop_event, self.dimming))
            self.led_process.start()

            print("Sollte nun gestartet sein: ", program)

            # self.led_process.join()

        self.current_program = program

        return

    def stop_led_Process(self):
        print("stop led process triggered")
        try:
            print(self.led_process)
            if self.led_process:
                print(getattr(self.led_process, 'is_alive'))
                if hasattr(self.led_process, 'is_alive') and self.led_process.is_alive():
                    print("stop led process: Found a running process!")
                    # Assuming self.stop_event is defined appropriately
                    self.stop_event.set()
                    self.led_process.join()  # Wait for the process to properly terminate
                else:
                    print("No running process to stop")
            else:
                print("No process to stop")
        except Exception as e:
            print(f"Error while stopping the process: {e}")
        finally:
            if hasattr(self, 'stop_event'):
                self.stop_event.clear()  # Reset the event for future use

    # def stop_led_Process(self):
    #     print("stop led process getriggert")
    #     if self.led_process and self.led_process.is_alive():
    #         print("stop led process: lebenden prozess gefunden!")
    #         try:
    #             # Hier wird ein multiprocessing.Event verwendet, um die stop Methode im laufenden Prozess zu triggern
    #             self.stop_event.set()
    #             self.led_process.join()  # Warte auf den Prozess, um ordnungsgemäß zu beenden
    #         except Exception as e:
    #             print(f"Fehler beim Stoppen des Modus: {e}")
    #         finally:
    #             # self.led_process = None
    #             self.stop_event.clear()  # Setze das Event zurück für den nächsten Gebrauch
    #     else:
    #         try:
    #             self.stop_event.clear()
    #         except:
    #             pass
    #         print("Kein laufender Modus zum Stoppen")
    #     return

    def getcurrentprogramm(self):
        with open("current_lampmodel.json", 'r') as file:
            data = json.load(file)
            program = data.get("modus", "")
            return program

    def read_lampmodeldata(self):
        with open("current_lampmodel.json", 'r') as file:
            data = json.load(file)
            return data

    def next_program(self):

        if self.current_program is not None:
            current_program_index = self.led_programs.index(self.current_program)
            next_program_index = (current_program_index + 1) % len(self.led_programs)
        else:
            next_program_index = 0

        # next_program_classname = type(self.led_programs[next_program_index]).__name__

        # Prüfen, ob das nächste Programm "Benutzerdefiniert" ist und überspringen
        # if next_program_classname == "Benutzerdefiniert":
        #     next_program_index = (next_program_index + 1) % len(self.led_programs)

        next_programm_classname = type(self.led_programs[next_program_index]).__name__
        print("nächstes Programm Klassenname: ", next_programm_classname)

        jsonclassname = self.get_programmStringname(next_programm_classname)
        print("Name für json Datei: ", jsonclassname)

        try:
            print("Versuche lampmodel mit neuen Modus zu aktualisieren")
            self.writeprogramm_into_lampmodel(jsonclassname)
        except Exception as e:
            time.sleep_ms(100)
            self.writeprogramm_into_lampmodel(jsonclassname)
            print("Manager exception: ", e)

        data = self.read_lampmodeldata()
        self.start_program(self.led_programs[next_program_index], data)

    def previous_program(self):

        if self.current_program != None:

            current_program_index = self.led_programs.index(self.current_program)
            previous_program_index = (current_program_index - 1) % len(self.led_programs)
        else:
            previous_program_index = 0

        previous_programm_classname = type(self.led_programs[previous_program_index]).__name__

        print("vorheriges programm klassenname: ", previous_programm_classname)
        jsonclassname = self.get_programmStringname(previous_programm_classname)

        try:
            print("Versuche lampmodel mit neuen Modus zu aktualisieren")
            self.writeprogramm_into_lampmodel(jsonclassname)

        except Exception as e:
            print("manager exception: ", e)
            time.sleep_ms(100)
            self.writeprogramm_into_lampmodel(jsonclassname)

        print("name für json Datei: ", jsonclassname)

        data = self.read_lampmodeldata()
        self.start_program(self.led_programs[previous_program_index], data)

    def get_programClassName(self, programmStringname):

        # 1
        if programmStringname == "Benutzerdefiniert":
            return "Benutzerdefiniert"
        # 2
        if programmStringname == "Rainbow":
            return "RainbowLED"
        # 3
        if programmStringname == "Pulsar":
            return "Pulsar"
        # 4
        if programmStringname == "Crazy Alien":
            return "Crazy_alien"
        # 5
        if programmStringname == "Sleeping Motion":
            return "SleepingMotion"
        # 6
        if programmStringname == "Rainy Days":
            return "RainyDays"
        # 7
        if programmStringname == "Indigo Cure":
            return "Indigo_Cure"
        # 8
        if programmStringname == "Earth":
            return "Earth"
        # 9
        if programmStringname == "Relax":
            return "Relax"
        # 10
        if programmStringname == "Galaxy":
            return "Galaxy"
        # 11
        if programmStringname == "X-Mas":
            return "Xmas"
        # 12
        if programmStringname == "Demo":
            return "Demo"

    def get_programmStringname(self, classname):

        # 1
        if classname == "Benutzerdefiniert":
            return "Benutzerdefiniert"
        # 2
        if classname == "RainbowLED":
            return "Rainbow"
        # 3
        if classname == "Pulsar":
            return "Pulsar"
        # 4
        if classname == "Crazy_alien":
            return "Crazy Alien"
        # 5
        if classname == "SleepingMotion":
            return "Sleeping Motion"
        # 6
        if classname == "RainyDays":
            return "Rainy Days"
        # 7
        if classname == "Indigo_Cure":
            return "Indigo Cure"
        # 8
        if classname == "Earth":
            return "Earth"
        # 9
        if classname == "Relax":
            return "Relax"
        # 10
        if classname == "Galaxy":
            return "Galaxy"
        # 11
        if classname == "Xmas":
            return "X-Mas"

    def writeprogramm_into_lampmodel(self, programmstringname):

        with open("current_lampmodel.json", 'r') as f:
            data = json.load(f)

            # Schritt 2: Inhalt als Dictionary parsen
            # (dies geschieht bereits durch json.load)

            # Schritt 3: Gewünschten Wert ändern
            data["modus"] = programmstringname
            data["isGlowShowing"] = "true"
            data["isGlow1"] = "true"
            data["isGlow2"] = "true"
            data["isGlow3"] = "true"
            data["isGlowShowing"] = "true"

            # Schritt 4: Dictionary als JSON speichern
            updated_json = json.dumps(data)

            # Schritt 5: Datei mit aktualisiertem Inhalt überschreiben
            with open("current_lampmodel.json", 'w') as f:
                f.write(updated_json)


# Initialisiere den Manager mit den LED-Programmen

manager = LEDProgramManager()
