import RPi.GPIO as GPIO
import time

# Die Nummerierung der Pins festlegen. Alternativen sind GPIO.BCM (für Broadcom SOC channel) oder GPIO.BOARD (für Board pin number).
GPIO.setmode(GPIO.BOARD)

# Ein GPIO-Pin als Eingang und ein weiterer als Ausgang definieren
INPUT_PIN = 10   # Beispiel: Pin 10
OUTPUT_PIN = 12  # Beispiel: Pin 12

GPIO.setup(INPUT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Setze den Pin als Eingang mit Pull-down-Widerstand
GPIO.setup(OUTPUT_PIN, GPIO.OUT)  # Setze den Pin als Ausgang

try:
    while True:
        # Den Eingangszustand des INPUT_PIN lesen
        input_state = GPIO.input(INPUT_PIN)

        if input_state == GPIO.HIGH:
            print("Input pin is HIGH")
            GPIO.output(OUTPUT_PIN, GPIO.HIGH)  # Setze den Ausgangspin auf HIGH
        else:
            print("Input pin is LOW")
            GPIO.output(OUTPUT_PIN, GPIO.LOW)  # Setze den Ausgangspin auf LOW

        time.sleep(1)  # 1 Sekunde warten

except KeyboardInterrupt:
    # Dieser Block wird ausgeführt, wenn das Skript durch Strg+C beendet wird
    print("Programm durch Benutzer beendet.")

finally:
    GPIO.cleanup()  # Setzt alle Pins zurück, die mit GPIO.setup() konfiguriert wurden.
