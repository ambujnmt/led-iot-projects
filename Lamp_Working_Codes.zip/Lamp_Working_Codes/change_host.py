import os

import set_hostname


set_hostname.setHostname("solarlampe")
os.system("sudo systemctl restart systemd-hostnamed")