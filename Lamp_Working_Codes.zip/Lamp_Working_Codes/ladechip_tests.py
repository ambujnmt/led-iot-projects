import smbus
import time
from datetime import datetime


class MAX17261:
    def __init__(self, bus_number=1):
        self.bus = smbus.SMBus(bus_number)
        self.address = 0x36  # Default I2C address of MAX17261

    def write_reg(self, reg_addr, reg_data):
        high_byte = (reg_data >> 8) & 0xFF
        low_byte = reg_data & 0xFF
        self.bus.write_i2c_block_data(self.address, reg_addr, [low_byte, high_byte])

    def read_reg(self, reg_addr):
        read = self.bus.read_i2c_block_data(self.address, reg_addr, 2)
        return read[1] << 8 | read[0]

    def initialize_ez_config(self, designcap, ichgterm, modelcfg, vempty):
        self.write_reg(0x18, designcap)  # DESIGNCAP register
        self.write_reg(0x1E, ichgterm)  # ICHGTERM register
        self.write_reg(0xDB, modelcfg)  # MODELCFG register
        self.write_reg(0x3A, vempty)  # VEMPTY register
        # Add additional initialization as per your requirement

    def get_soc(self):
        soc_reg_value = self.read_reg(0x06)  # REPSOC register
        soc = soc_reg_value / 256.0
        return soc

def log_current_time_and_value(file_path, value):
    with open(file_path, 'a') as file:
        current_time = datetime.now()
        file.write(f"{current_time} - Value: {value}\n")

# Example usage
gauge = MAX17261()
counter = 0
file_path = "log_akku.txt"


while True:
    gauge.initialize_ez_config(0x2EE0, 0x04B0, 0x8400, 0xA561)  # Example values
    soc = gauge.get_soc()
    red = gauge.bus.read_i2c_block_data(0x36,0x8080, 2)
    print(f"State of Charge: {soc:.2f}%")
    print(red)
    time.sleep(10)
    counter = counter + 1
    if counter == 60:
        current_datetime = datetime.now()
        print("Aktuelle Uhrzeit: ", current_datetime)
        print(f"State of Charge: {soc:.2f}%")
        soc_value = f"State of Charge: {soc:.2f}%"
        log_current_time_and_value(file_path, soc_value)
        counter = 0
