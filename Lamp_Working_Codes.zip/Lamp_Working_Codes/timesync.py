import subprocess
from datetime import datetime

def sync_time():
    # Führt den Befehl zum Synchronisieren der Systemzeit aus
    subprocess.run(["sudo", "timedatectl", "set-ntp", "true"])
    print("Zeit synchronisiert.")
    uhrzeit = datetime.now()
    uhrzeitstring = uhrzeit.strftime("%d-%m-%Y %H:%M:%S")
    print (uhrzeit)
    print (uhrzeitstring)
    logstring = "Uhrzeit wurde Synconisiert: " + uhrzeitstring
    with open ("/home/Solarlampe/timesync", "w") as file:
        file.write(logstring)
    
sync_time()
