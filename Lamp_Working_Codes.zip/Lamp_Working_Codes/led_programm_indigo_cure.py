#import machine
import neopixel
#import utime
# import uasyncio
#import _thread
import random
import gc
import time
import multiprocessing
import board
#from micropython import const
#from machine import TouchPad
from led_programmliste import manager





#Dieses Indigo_Cure Programm entspricht nun was vom Kunden gewünscht ist (weicher Übergang bei Farbwechsel von WEb auf Spektral)


class Indigo_Cure:
    def __init__(self, touchenabled):

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12
        
        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3*self.NUM_LEDS_BOTTOM)
        
        self.PIN = board.D12
        
        
        #'Belegung ESP32 mehr Ram'
        
        #self.PIN = 18
        #self.PIN_MID = 19  # Change the pin number to match your hardware setup
        #self.PIN_BOTTOM_FIRST = 21
       # self.PIN_BOTTOM_SECOND = 22
        #self.PIN_BOTTOM_THIRD = 23
        
        
        #Belegung ESP32 Platine
        '''
        self.PIN = 15
        self.PIN_MID = 4  # Change the pin number to match your hardware setup
        self.PIN_BOTTOM_FIRST = 19
        self.PIN_BOTTOM_SECOND = 5
        self.PIN_BOTTOM_THIRD = 18
        '''
        
        self.touchenabled = touchenabled
        
                #manager mit led programm füttern, muss gemacht werden um zirkuläre importe zu vermeiden
        
            
        manager.add_programm(self)
            
     
        
        self.paused = False

        # Erstelle das Neopixel-Objekt
        # self.np_top = const(neopixel.NeoPixel(machine.Pin(self.PIN), self.NUM_LEDS_TOP, bpp=4))
        # self.np_mid = const(neopixel.NeoPixel(machine.Pin(self.PIN_MID), self.NUM_LEDS_MID,bpp=4))  # Use bpp=4 to indicate RGBW LEDs
        # self.np_bottom_first = const(neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_FIRST), self.NUM_LEDS_BOTTOM, bpp=4))
        # self.np_bottom_second = const(neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_SECOND), self.NUM_LEDS_BOTTOM, bpp=4))
        # self.np_bottom_third = const(neopixel.NeoPixel(machine.Pin(self.PIN_BOTTOM_THIRD), self.NUM_LEDS_BOTTOM, bpp=4))
        
        #streifen für Rasberry
        
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount,  auto_write=False, bpp=4)

        # Define the colors
#         self.RED = (255, 0, 0, 0)
#         self.ORANGE_RED = (255, 128, 0, 0)
#         self.YELLOW1 = (255, 255, 0, 0)
#         self.LIGHTGREEN = (128, 255, 0, 0)
#         self.GREEN = (0, 255, 0, 0)
#         self.ORANGE = (255, 63, 0, 0)
#         self.YELLOW = (255, 255, 0, 0)
#         self.BLUE = (0, 0, 255, 0)
#         self.PURPLE = (148, 0, 211, 0)
#         self.PINK = (255, 20, 147, 0)
#         self.DARKPURPLE = (148, 0, 211, 0)
#         self.TUERKIS = (64, 224, 208, 0)
#         self.WHITE = (0, 0, 0, 0)
#         self.DARK_BLUE = (0, 0, 132, 81)
#         self.LIGHT_BLUE = (0, 0, 0, 0)

        self.INDIGO_WEB = (75, 0, 130, 0)
        self.INDIGO_SPEKTRAL = (111, 0, 255, 0)

        self.DARK = (0, 0, 0, 0)
        self.indigo_cure_running = False
        self.thread_running = None
        self.TRANSITION_COLORS2= [( 8,  0, 15,  0),
       ( 8,  0, 17,  0),
       ( 9,  0, 19,  0),
       ( 9,  0, 20,  0),
       (10,  0, 22,  0),
       (10,  0, 23,  0),
       (11,  0, 25,  0),
       (11,  0, 26,  0),
       #(12,  0, 27,  0),
       #(12,  0, 27,  0)
                                 ]
        

        
        
        
    def np_top_array(self, position, value):
        
         self.np[position] = value
    
    def np_mid_array(self, position, value):
        
        #print("Position mid array: ", position)
   
        
        self.np[position + self.NUM_LEDS_TOP] = value
    
    def bottom1_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID-1] = value
    
    def bottom2_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ self.NUM_LEDS_BOTTOM-1] = value
        
    def bottom3_array(self, position, value):
        
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID+ (self.NUM_LEDS_BOTTOM*2)-1] = value
        
        
    
    def dim_and_switch_colors(self, stop_event, diming, change_timing = True):

        if diming:
            #self.INDIGO_WEB = (38, 0, 65, 0) 50% gedimmt
            #self.INDIGO_SPEKTRAL = (56, 0, 128, 0)
            #self.DARK  = (0, 0, 0, 0)
        
                # auf 25% gedimmt

                self.INDIGO_WEB = (19, 0, 33, 0)
                self.INDIGO_SPEKTRAL = (28, 0, 64, 0)
                self.DARK = (0, 0, 0, 0)

        #self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount,  auto_write=False, bpp=4)
        
        #print("Dimm and Switch Colors ausgeführt")
        # Füge eine Variable hinzu, um die Anzahl der Dimmstufen zu erhöhen
        dim_steps = 100

        # Berechne die Zeit pro Schritt
        step_time = (4.32 /2) / dim_steps

        # Setze den minimalen Helligkeitsfaktor auf 10%
        min_brightness_factor = 0.1
        brightness_range = 1 - min_brightness_factor
        
        
        
      
        
        while True:
            
            #gibt es einen touchinput?
            #if self.touchenabled:
                #self.checktouchinput()
            
            
            # ist pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue
    
            
            if stop_event.is_set():
                self.stop()
                return
                
            if change_timing == True:
                time.sleep(0.01)
            
            for i in range(dim_steps):
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                self.set_color_with_brightness(self.INDIGO_WEB, brightness_factor,stop_event)
                if self.indigo_cure_running == False: return
                #time.sleep(step_time)
            
            self.sleep_with_conditioncheck(stop_event) #schläft 4.32 sekunden

            #self.sleep_with_touchcheck()
            if stop_event.is_set():
                self.stop()
                return

            for i in range(dim_steps, 0, -1):
                if stop_event.is_set():
                    self.stop()
                    return


                if self.paused == True:
                    time.sleep(0.010)
                    continue
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                #print(brightness_factor)
                #if brightness_factor == 0.109: print("IndigoWEB minimum wert")
                self.set_color_with_brightness(self.INDIGO_WEB, brightness_factor, stop_event)
                #time.sleep(step_time)
            if stop_event.is_set():
                self.stop()
                return
            
            
            #print("warte auf transition")
            #time.sleep(1)
            

            if change_timing == True:
                time.sleep(0.01)
                
            for i in self.TRANSITION_COLORS2:


                    #self.checktouchinput()
                if self.paused == True:
                    time.sleep(0.010)
                    continue
                #print("Farbwert wird geschrieben: ", i)
                colorvalue = i
                self.np.fill(colorvalue)
                self.np.show()
                if stop_event.is_set():
                    self.stop()
                    return
                # self.np_top.fill(colorvalue)
                # self.np_mid.fill(colorvalue)
                # self.np_bottom_first.fill(colorvalue)
                # self.np_bottom_second.fill(colorvalue)
                # self.np_bottom_third.fill(colorvalue)
                # self.writeall()
                #time.sleep_ms(1)
                #print("Colorvalue geschrieben: ", colorvalue)
                

            if change_timing == True:
                time.sleep(0.01)

            for i in range(dim_steps):


                if self.paused == True:
                    time.sleep(0.010)
                    continue
                if stop_event.is_set():
                    self.stop()
                    return
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                #if brightness_factor == 0.109: print("IndigoSpektral minimum wert")
                self.set_color_with_brightness(self.INDIGO_SPEKTRAL, brightness_factor, stop_event)
                #time.sleep(step_time)
            if stop_event.is_set():
                self.stop()
                return
                
            self.sleep_with_conditioncheck(stop_event) #schläft 4.32 sekunden
            
            if stop_event.is_set():
                self.stop()
                return
            #self.sleep_with_touchcheck()
            
            for i in range(dim_steps, 0, -1):

                    #self.checktouchinput()
                if self.paused == True:
                    time.sleep(0.010)
                    continue
                if stop_event.is_set():
                    self.stop()
                    return
                brightness_factor = min_brightness_factor + (i / dim_steps) * brightness_range
                self.set_color_with_brightness(self.INDIGO_SPEKTRAL, brightness_factor, stop_event)
             
            for i in reversed (self.TRANSITION_COLORS2):
                
                if self.paused == True:
                    time.sleep(0.010)
                    continue
                    
                if change_timing == True:
                    time.sleep(0.01)
                
                colorvalue = i
                self.np.fill(colorvalue)
                self.np.show()
                # self.np_top.fill(colorvalue)
                # self.np_mid.fill(colorvalue)
                # self.np_bottom_first.fill(colorvalue)
                # self.np_bottom_second.fill(colorvalue)
                # self.np_bottom_third.fill(colorvalue)
                # self.writeall()
               
            if stop_event.is_set():
                self.stop()
                return
            
            
            
    #@micropython.native       
    def writeall(self):
        self.np.show()
        # self.np_top.write()
        # self.np_mid.write()
        # self.np_bottom_first.write()
        # self.np_bottom_second.write()
        # self.np_bottom_third.write()
                
    #@micropython.native
    def set_color_with_brightness(self, color, brightness_factor, stop_event):
     
        if stop_event.is_set():
                self.stop()
                return
        r, g, b, w = color
        new_color = (int(r * brightness_factor), int(g * brightness_factor), int(b * brightness_factor), int(w * brightness_factor))
        
        if stop_event.is_set():
                self.stop()
                return
        self.np.fill(new_color)
        # self.np_top.fill(new_color)
        # self.np_mid.fill(new_color)
        # self.np_bottom_first.fill(new_color)
        # self.np_bottom_second.fill(new_color)
        # self.np_bottom_third.fill(new_color)
        if stop_event.is_set():
                self.stop()
                return
                
        self.np.show()
        # self.np_top.write()
        # self.np_mid.write()
        # self.np_bottom_first.write()
        # self.np_bottom_second.write()
        # self.np_bottom_third.write()

    
    #def indigo_cure_on(self):
        
        #if self.touchenabled:
            #self.touch_threshold = self.touch_pin.read()
        #while self.indigo_cure_running == True:
            
            
            #self.dim_and_switch_colors()
            
            #if self.indigo_cure_running == False: return
        
    def start(self, stop_event, diming):
        # time.sleep()
        self.indigo_cure_running = True
        print("Inigo Cure, LED Programm wurde in LED Klasse getriggert!")
        self.dim_and_switch_colors(stop_event, diming)
        # self.thread_running = None

        # try:
            # print("Indigo Cure on")
            # self.thread_running = _thread.start_new_thread(self.indigo_cure_on, ())
            # print("indigo cure solle nun laufen")
            

        # except:

            # utime.sleep_ms(70)
            # self.start()

        #return True

    def stop(self):

        self.indigo_cure_running = False
        
        self.indigo_cure_off()

        # self.thread_mid.exit()

        #if (self.thread_running is not None):
            # self.thread_bottom.exit()
            # time.sleep(1)
            #self.thread_running.exit()
        
        #time.sleep(1)
        

        #self.indigo_cure_off()
        #self.indigo_cure_off()
        # try:
            # _thread.exit()
        # except:
            # pass

    def indigo_cure_off(self):
        
        self.np.fill((0,0,0,0))
        self.np.show()
     

        #self.np_mid.fill((0, 0, 0, 0))
        #self.np_top.fill((0, 0, 0, 0))

        #self.np_mid.write()
        #self.np_bottom_first.fill((0, 0, 0, 0))
        #self.np_bottom_second.fill((0, 0, 0, 0))
        #self.np_bottom_third.fill((0, 0, 0, 0))

        # self.np_top.write()
        # self.np_bottom_first.write()
        # self.np_bottom_second.write()
        # self.np_bottom_third.write()

    def get_Status(self):
        return self.indigo_cure_running
        
    def sleep_with_conditioncheck(self, stop_event, timeout = 4.32):
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            if stop_event.is_set():
                self.stop()
                return
            time.sleep(0.05)
        
        return
    
    



#indigo_cure = Indigo_Cure(False)
#diming = True
#stop_event = multiprocessing.Event()
#indigo_cure.start(stop_event, diming)






