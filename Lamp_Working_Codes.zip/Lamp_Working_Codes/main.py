# import sys
import gc
import json

import time

import board
import digitalio

# import set_hostname
# from new_hostname import change_hostname
from set_hostname import checkIfDefaultHostNameAndChange
from SW_Button import SWButton
from control_motor_interpreter import MotorInterpreter


# # Datei, in die alle Print-Ausgaben umgeleitet werden
# logfile = open('/home/Solarlampe/Desktop/mein_logfile.log', 'w')

# # Ursprüngliche stdout speichern, damit sie später wiederhergestellt werden kann
# original_stdout = sys.stdout

# # stdout auf die Logdatei umleiten
# sys.stdout = logfile


def aktivated_deactivate_led_series():
    import board
    series_pin = 23
    series_enable = digitalio.DigitalInOut(board.D23)
    series_enable.direction = digitalio.Direction.OUTPUT
    series_enable.value = 0
    print("aktueller value des series pin : ", series_enable.value)


def bootglow():
    import board
    import neopixel

    np = neopixel.NeoPixel(board.D12, 100, auto_write=False, bpp=4)
    np.fill((255, 255, 255, 0))
    np.show()


def bootglow_off():
    import board
    import neopixel
    np = neopixel.NeoPixel(board.D12, 100, auto_write=False, bpp=4)
    np.fill((0, 0, 0, 0))
    np.show()


def setcurrentglowoff():
    try:
        with open("current_lampmodel.json", 'r') as file:
            data = json.load(file)
    except:
        print("couldnt load json")
    # Alle "glow" Werte auf "false" setzen
    try:
        keys_to_update = ['isGlowShowing', 'isGlowAll', 'isGlow1', 'isGlow2', 'isGlow3', 'istrackingactive']
        for key in keys_to_update:
            if key in data:
                data[key] = "false"
    except:
        print("couldt load json")
    # Die aktualisierten Daten zurück in die JSON-Datei schreiben
    try:
        with open("current_lampmodel.json", 'w') as file:
            json.dump(data, file, indent=4)
    except:
        print("couldnt load json")
    print("Die Glow-Werte wurden auf 'false' gesetzt.")


def setwrokingdirectiory():
    import os
    # Setzt das Arbeitsverzeichnis auf das Verzeichnis des Skripts
    script_directory = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_directory)


def set_shared_json():
    # copies curren_lampmodel to current_lampmodel_shared, which is used for sharing feature
    try:
        # Load the content of the source file
        with open('current_lampmodel.json', 'r') as f:
            source_content = json.load(f)

        # Write the content into the target file
        with open('current_lampmodel_shared.json', 'w') as f:
            json.dump(source_content, f, indent=4)

        print(f"Successfully copied content from current_lampmodel to shared_lampmodel")
    except Exception as e:
        print(f"An error occurred: {e}")


import json


def update_missing_keys_from_check(current_json_path, check_json_path):
    # Load the check JSON with default values
    with open(check_json_path, 'r') as file:
        check_json = json.load(file)

    # Load the current motor status, handling empty files
    try:
        with open(current_json_path, 'r') as file:
            if file.read(1):  # Check if the first character exists (file is not empty)
                file.seek(0)  # Reset file read position
                current_motor_status = json.load(file)
            else:
                current_motor_status = {}  # Use an empty dict if file is empty
    except json.JSONDecodeError as e:
        print(f"Error reading {current_json_path}: {e}")
        current_motor_status = {}  # Use an empty dict if JSON is invalid

    # Flag to track if updates are made
    update_needed = False

    # Check each key in check_json to see if it's missing in current_motor_status
    for key, value in check_json.items():
        if key not in current_motor_status:
            current_motor_status[key] = value  # Add missing key with default value
            update_needed = True

    # If any updates were made, write back to the current JSON file
    if update_needed:
        with open(current_json_path, 'w') as file:
            json.dump(current_motor_status, file, indent=4)


def copy_shared_to_current():
    """
    Copies the content of source_file into target_file.

    :param source_file: Path to the source JSON file.
    :param target_file: Path to the target JSON file.
    """
    try:
        # Load the content of the source file
        with open('current_lampmodel_shared.json', 'r') as f:
            source_content = json.load(f)

        # Write the content into the target file
        with open('current_lampmodel.json', 'w') as f:
            json.dump(source_content, f, indent=4)

        print(f"Successfully copied content from current_lampmodel to shared_lampmodel")
    except Exception as e:
        print(f"An error occurred: {e}")


def is_valid_json(file_path):
    """
    Checks if a JSON file is valid and not empty.

    :param file_path: Path to the JSON file.
    :return: True if the file is valid JSON and not empty, False otherwise.
    """
    try:
        with open(file_path, 'r') as file:
            if file.read(1):  # Check if the first character exists (file is not empty)
                file.seek(0)  # Reset file read position
                json.load(file)
                return True
            else:
                return False
    except (json.JSONDecodeError, FileNotFoundError):
        return False


def main(btkopplung=False, touchenabled=False, i2cdetectiontest=False, doupdate=False, ):
    current_json_path_motor = '/home/Solarlampe/Solarlamp_on_raspi/production/current_motor_status.json'
    check_json_path_motor = '/home/Solarlampe/Solarlamp_on_raspi/production/check_motor_status.json'
    current_json_path_lampmodel = '/home/Solarlampe/Solarlamp_on_raspi/production/current_lampmodel.json'
    check_json_path_lampmodel = '/home/Solarlampe/Solarlamp_on_raspi/production/check_lampmodel.json'
    shared_json_path_lampmodel = '/home/Solarlampe/Solarlamp_on_raspi/production/current_lampmodel_shared.json'

    update_missing_keys_from_check(current_json_path_motor, check_json_path_motor)

    if not is_valid_json(current_json_path_lampmodel):
        print("Current lampmodel JSON is invalid, updating from check JSON")
        if is_valid_json(shared_json_path_lampmodel):
            copy_shared_to_current()
        else:
            with open(current_json_path_lampmodel, 'w') as file:
                with open(check_json_path_lampmodel, 'r') as check_file:
                    check_json = json.load(check_file)
                    json.dump(check_json, file, indent=4)
    else:
        print("Current lampmodel JSON is valid, no update needed")

    # copy_shared_to_current()

    from spannung_staerke_test import ControlBattery
    battery_controller = ControlBattery()
    # Arbeitsverzeichniss setzen damit main auch über crontab ausgeführt werden kann
    setwrokingdirectiory()

    # set new hostname
    # change_hostname()
    battery_controller.disable_watchdog()

    battery_controller.update_registers()
    battery_controller.set_maximum_charge_current()
    setcurrentglowoff()
    aktivated_deactivate_led_series()
    checkIfDefaultHostNameAndChange()

    motorcontroller = MotorInterpreter()

    motorcontroller.reset_on_start()

    # Lampe leuchtet beim start weiß auf
    bootglow()
    time.sleep(3)

    # checke ob button gedrückt wird beim boot, wenn ja dann bt Kopplung initialisieren
    bt_button = SWButton()
    bt_button.check_bluetooth_enable()
    btkopplung = bt_button.get_bt_button_was_pressed()
    # btkopplung = True
    del bt_button

    bootglow_off()
    gc.collect()

    time.sleep(2)
    # backup_lampmodel()
    set_shared_json()

    # touchinput = SWButton()
    # touchinput.startbackgrounddetection()

    # -------------------------------------------------------
    # ----------Abschnitt i2c detection test für matthias#------------
    if i2cdetectiontest == True:
        print("Enable Power 4 I2C Devices")
        # laut Schaltplan ist Power enable auf GPIO8
        enable_power_pin = board.D8
        print("Enable Power for I2C Devices")
        # laut Schaltplan ist Power enable auf GPIO8
        enable_power_pin = digitalio.DigitalInOut(board.D8)
        # Set pin as output
        enable_power_pin.direction = digitalio.Direction.OUTPUT
        # Enable pin
        enable_power_pin.value = True
        print("Enable-power für I2C geräte wurde gesetzt")
        time.sleep(0.5)

        def run_i2cdetect(bus_number):
            import subprocess
            try:
                # Führen Sie den i2cdetect Befehl aus und erhalten Sie die Ausgabe
                output = subprocess.check_output(["i2cdetect", "-y", str(bus_number)])
                print(output.decode())  # Decodiert die Byte-Ausgabe in einen String und gibt ihn aus
            except subprocess.CalledProcessError as e:
                print(e.output.decode())  # Falls ein Fehler auftritt, geben Sie die Fehlermeldung aus
                print("Ein Fehler ist aufgetreten während des Ausführens von i2cdetect")
            except Exception as e:
                print("Ein unerwarteter Fehler ist aufgetreten:", str(e))

        print("Erkannte i2c Geräte:")
        # Führen Sie die Funktion mit dem gewünschten I2C-Bus aus
        run_i2cdetect(1)

        exit(1)

    # I2C Test Ende------------------------------------------------------------------

    # hier aktuell mit Parameter in der Main gestartet, sollte durch einen Buttonpress beim boot abgelöst werden
    # btkopplung = getButtonpressonboot() oder so
    elif btkopplung == True:
        print("Bluetoothkopplung wird gestartet")

        import Bluetooth_LE

        # blinking ist für die LED Infromation für den Kopplungsvorgang da
        Bluetooth_LE.start_ble_gatts(advertismentname="Sol_Lamp", blinking=True)


    else:

        # import touch_monitoring
        # touch_monitoring.main(on=False)  # Test für Top-Touch

        print("Webserver wird gestartet")

        print("checke ob Wlan verbindung besteht")

        from WIFI_Manager import Wifi_Connection
        from update_manager import updatemanager

        internetaccess = Wifi_Connection.wifi_is_connected()
        updatemangerisperformingupdate = False

        # abschnitt Updatefuntkion Projektarbeit
        if internetaccess == True and doupdate == True:

            try:
                updatemanager.update_system()
            except Exception as e:
                print("fehler aufgetreten")
                print("fehler beim Updatevorgang aufgetreten, führe Rollback durch")

        if internetaccess == True and doupdate == True:
            while updatemanager.get_isperformingupdate() == True:
                print("Updatemanager ,  führt update durch warte...")
                time.sleep(0.2)
                continue
            # updatemanager.startupdatebackgroundcheck() #for permanent background check
        elif internetaccess == True:
            # Syncronisiere Zeit wenn eine Internetverbindung besteht
            from timesync import sync_time
            sync_time()

        import webserver_microdot

        if touchenabled == True:

            webserver_microdot.start_server(True)

        else:

            webserver_microdot.start_server(False)


main()
