import sys

import board
import digitalio
import time
import json
from shared_ressources import shared_resources


class Rotation_MotorControl:
    def __init__(self, step_pin, direction_pin, enable_pin):
        self.rotation_motor = self.setup_motor(step_pin, direction_pin)
        self.step_mode1 = digitalio.DigitalInOut(board.D9)
        self.step_mode1.direction = digitalio.Direction.OUTPUT
        self.step_mode1.value = True
        self.step_mode2 = digitalio.DigitalInOut(board.D25)
        self.step_mode2.direction = digitalio.Direction.OUTPUT
        self.step_mode2.value = False
        self.json_filename = 'current_motor_status.json'
        self.data = self.load_motor_data()
        self.steps_per_revolution = 200  # Change this to match your stepper motor
        self.desired_rpm = 60  # Desired rotations per minute
        # self.degrees_per_step = 1.7 / 1138
        self.degrees_per_step = 1 / 91  # 1/171 for 1:51 getriebe
        self.custom_speed = 0.000025  # default is 0.0000025
        self.enable_pin = digitalio.DigitalInOut(enable_pin)
        self.enable_pin.direction = digitalio.Direction.OUTPUT
        # self.enable_pin.value = True
        # True = motor -> disabled
        # False = motor -> enabled

    def setup_motor(self, step_pin, direction_pin):
        motor = digitalio.DigitalInOut(step_pin)
        motor.direction = digitalio.Direction.OUTPUT
        self.direction_pin = digitalio.DigitalInOut(direction_pin)
        self.direction_pin.direction = digitalio.Direction.OUTPUT
        return motor

    def load_motor_data(self):
        try:
            with open(self.json_filename, 'r') as file:
                data = json.load(file)
                if 'current_rotation' not in data:
                    data['current_rotation'] = 0  # Initialize if the key is missing
                self.data = data
                return data
        except (FileNotFoundError, json.JSONDecodeError):
            data = {'current_rotation': 0}  # Initialize if the key is missing
            self.save_motor_data()
            self.data = data
            return data

    def save_motor_data(self):
        with open(self.json_filename, 'w') as file:
            json.dump(self.data, file)

    def move_motor(self, num_steps, custom_speed):
        speed = custom_speed
        shared_resources.stop_event_rotate.clear()
        for _ in range(abs(num_steps)):
            self.rotation_motor.value = True
            time.sleep(speed)
            self.rotation_motor.value = False
            time.sleep(speed)
            if shared_resources.stop_event_rotate.is_set():
                self.rotation_motor.value = True
                break

    def set_rotation_angle(self, desired_angle, custom_speed, continuous_rotation=0):
        self.enable_pin.value = False
        if continuous_rotation == 0:
            current_rotation = int(self.data["current_rotation"])
        elif continuous_rotation == 2:
            current_rotation = 360
        else:
            current_rotation = 0

        num_steps = int(round((int(desired_angle) - current_rotation) / self.degrees_per_step))
        self.direction_pin.value = num_steps > 0
        self.move_motor(abs(num_steps), custom_speed)
        self.data['current_rotation'] = int(desired_angle)
        if continuous_rotation == 1:
            self.data['current_rotation'] = 0
        self.enable_pin.value = True
        # self.save_motor_data()
        print("Anzahl der Rotation_Steps:", num_steps)

    def stop_rotation(self):
        self.enable_pin.value = True  # Disable the motor
        self.rotation_motor.value = False
        time.sleep(0.5)

    def reset_rotation(self):
        current_angle = int(self.data['current_rotation'])
        if current_angle != 0:
            print(f"Resetting rotation to 0 degrees from {current_angle} degrees.")
            self.set_rotation_angle(0, self.custom_speed)
        else:
            print("The rotation angle is already at 0 degrees.")

    def run(self, angle, custom_speed, continuous_rotation=0):
        # Set the initial direction for the rotation motor
        # self.direction_pin.value = True  # Change this as needed

        speed_value = 0.02
        speed = speed_value / custom_speed
        print(angle, "angle rotation")

        try:
            self.set_rotation_angle(angle, speed, continuous_rotation)
        except ValueError:
            print("Invalid input. Please enter a valid angle in degrees.")

        except KeyboardInterrupt:
            print("Exiting the program.")
