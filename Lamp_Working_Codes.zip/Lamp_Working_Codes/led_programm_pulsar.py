# import machine
# import _thread
import board
import neopixel
import time
import multiprocessing
# import network
# from machine import TouchPad
from led_programmliste import manager
import time

import random
import gc


class Pulsar:
    def __init__(self, touchenabled):
        manager.add_programm(self)

        self.NUM_LEDS_TOP = 10
        self.NUM_LEDS_MID = 98
        self.NUM_LEDS_BOTTOM = 12

        self.TotalLedCount = self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (3 * self.NUM_LEDS_BOTTOM)
        self.PIN = board.D12  # 18

        # neopixel Raspberry:
        self.np = neopixel.NeoPixel(board.D12, self.TotalLedCount, auto_write=False, bpp=4)

        # Define the colors
        self.WHITE = [(200, 200, 200, 0)]
        self.OFF = [(0, 0, 0, 0)]

        self.pulsar_running = False
        self.thread_running = None
        self.paused = False

        # Global variable to track whether the relax LED is on or off
        self.pulsar_on = False

        print("Pulsar wurde initialisiert")

        self.thread_mid = None

        self.init = True

        time.sleep(0.1)

    def np_top_array(self, position, value):
        self.np[position] = value

    def np_mid_array(self, position, value):
        self.np[position + self.NUM_LEDS_TOP] = value

    def bottom1_array(self, position, value):
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID - 1] = value

    def bottom2_array(self, position, value):
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + self.NUM_LEDS_BOTTOM - 1] = value

    def bottom3_array(self, position, value):
        self.np[position + self.NUM_LEDS_TOP + self.NUM_LEDS_MID + (self.NUM_LEDS_BOTTOM * 2) - 1] = value

    # STARTE LED_LEUCHTPROGRAMM
    def pulsar_loop(self, stop_event, diming):

        if diming:
            #self.WHITE = [( 100, 100, 100, 0)] 50% gedimmt
            #self.OFF = [(0, 0, 0, 0)]

    #  auf 25% gedimmt

            self.WHITE = [(50, 50, 50, 0)]
            self.OFF = [(0, 0, 0, 0)]


        gc.enable()
        r4 = 0
        current_Color = self.WHITE[0]
        led_off_color = self.OFF[0]
        '''
        if self.touchenabled:
            self.touch_threshold = self.touch_pin.read()
        '''
        top_round = 0
        top_round_time = 80
        top_round_one = 0
        top_round_two = 5
        brightness_top = 100

        mid_round = 0
        mid_round_time = 8
        mid_round_one = 0
        mid_round_two = 49
        brightness_mid = 100

        bottom_round = 0
        round_speed_bottom = 0
        bottom_round_time = 100
        brightness = 98
        aufblitzen_switch = False
        bottom_aufblitzen_finished = 0

        r_bottom = 20
        count_number = 0

        while self.pulsar_on:

            '''
            if self.pulsar_running == False:
                return
            '''
            '''
            #gibt es einen touchinput?
            if self.touchenabled:
                self.checktouchinput()
            '''

            # ist  pausiert?
            if self.paused == True:
                time.sleep_ms(10)
                continue

            r4 = r4 + 1

            if mid_round_time == 3:
                round_speed_bottom = round_speed_bottom + 1
            if (r4 == 1):
                # ______________________________TOP - LEDS__________________________________________
                top_round += 1
                if (top_round == top_round_time):
                    top_round = 0
                    if (top_round_one < 5):
                        self.np_top_array(top_round_one, self.scale_color(current_Color, brightness_top))
                        self.np_top_array(top_round_two, self.scale_color(current_Color, brightness_top))
                        if (top_round_one > 0):
                            number = top_round_one - 1
                            number2 = top_round_two - 1
                            self.np_top_array(number, led_off_color)
                            self.np_top_array(number2, led_off_color)
                            #print("ON: ", top_round_one, " OFF: ", number)
                        if (top_round_one == 0):
                            self.np_top_array(4, led_off_color)
                            self.np_top_array(9, led_off_color)

                        top_round_one = top_round_one + 1
                        top_round_two = top_round_two + 1

                        if top_round_one == 5:
                            top_round_one = 0
                            top_round_two = 5
                            if (top_round_time != 30):
                                top_round_time -= 10

                # ______________________________MID - LEDS__________________________________________
                if(top_round_time == 30):
                    mid_round += 1
                    if (mid_round == mid_round_time):
                        mid_round = 0
                        if (mid_round_one < 49):
                            self.np_mid_array(mid_round_one, self.scale_color(current_Color, brightness_mid))
                            self.np_mid_array(mid_round_two, self.scale_color(current_Color, brightness_mid))
                            if (mid_round_one > 0):
                                number = mid_round_one - 1
                                number2 = mid_round_two - 1
                                self.np_mid_array(number, led_off_color)
                                self.np_mid_array(number2, led_off_color)
                            mid_round_one = mid_round_one + 1
                            mid_round_two = mid_round_two + 1

                        elif (mid_round_one == 49):
                            number = mid_round_one - 1
                            number2 = mid_round_two - 1
                            self.np_mid_array(number, led_off_color)
                            self.np_mid_array(number2, led_off_color)
                            mid_round_one = 0
                            mid_round_two = 49
                            if (mid_round_time != 3):
                                mid_round_time -= 1
                                brightness_top -= 15
                                #print("TOP BRIGHTNESS: ", brightness_top, " MID_ROUNND: ", mid_round_time)

                # ______________________________BOTTOM - LEDS__________________________________________
                # Wenn mittlerer Streifen fertig ist, soll untere Ebene starten
                if mid_round_time == 3:
                    if bottom_round_time == 60:
                        if round_speed_bottom == 2:
                            if aufblitzen_switch == False:
                                brightness += 2
                                if brightness == 100:
                                    aufblitzen_switch = True
                                    bottom_aufblitzen_finished += 1
                                    #print(" Runde: ", bottom_aufblitzen_finished)
                            elif aufblitzen_switch == True:
                                brightness -= 2
                                if brightness == 20:
                                    aufblitzen_switch = False
                                    bottom_aufblitzen_finished += 1
                                    #print(" Runde: ", bottom_aufblitzen_finished)
                            self.start_bottom(0, brightness)
                            self.start_bottom(1, brightness)
                            self.start_bottom(2, brightness)
                            if bottom_aufblitzen_finished == 12:
                                self.stop_bottom(1)
                                self.stop_bottom(2)
                                self.stop_bottom(3)
                                bottom_round_time = 100
                                #print("Bende Aufblitzen", bottom_aufblitzen_finished)
                                bottom_aufblitzen_finished = 0
                                r_bottom = 20
                            round_speed_bottom = 0

                    else:
                        if r_bottom == round_speed_bottom:
                            # Activate
                            self.bottom1_array(count_number, self.WHITE[0])
                            self.bottom2_array(count_number, self.WHITE[0])
                            self.bottom3_array(count_number, self.WHITE[0])

                            # Deactivate
                            self.bottom_off_first(count_number)
                            self.bottom_off_second(count_number)
                            self.bottom_off_third(count_number)

                            count_number = count_number + 1
                            round_speed_bottom = 0

                        if count_number == 12:
                            self.bottom_off_first(11)
                            self.bottom_off_second(11)
                            self.bottom_off_third(11)
                            count_number = 0
                            if bottom_round_time != 60:
                                bottom_round_time -= 10
                                r_bottom -= 2

                r4 = 0

            # soll pulsar beendet werden?
            if stop_event.is_set():
                self.stop()
                return

            # schreibe in jeden durchlauf obere & mittleren und untere led streifen
            self.np.show()


    # @micropython.native
    def bottom_off_first(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom1_array(11, self.OFF[0])

        elif count_number == 1:
            self.bottom1_array(0, self.OFF[0])

        elif count_number == 2:
            self.bottom1_array(1, self.OFF[0])

        elif count_number == 3:
            self.bottom1_array(2, self.OFF[0])

        elif count_number == 4:
            self.bottom1_array(3, self.OFF[0])

        elif count_number == 5:
            self.bottom1_array(4, self.OFF[0])

        elif count_number == 6:
            self.bottom1_array(5, self.OFF[0])

        elif count_number == 7:
            self.bottom1_array(6, self.OFF[0])

        elif count_number == 8:
            self.bottom1_array(7, self.OFF[0])

        elif count_number == 9:
            self.bottom1_array(8, self.OFF[0])

        elif count_number == 10:
            self.bottom1_array(9, self.OFF[0])

        elif count_number == 11:
            self.bottom1_array(10, self.OFF[0])

    # @micropython.native
    def bottom_off_second(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom2_array(11, self.OFF[0])

        elif count_number == 1:
            self.bottom2_array(0, self.OFF[0])

        elif count_number == 2:
            self.bottom2_array(1, self.OFF[0])

        elif count_number == 3:
            self.bottom2_array(2, self.OFF[0])

        elif count_number == 4:
            self.bottom2_array(3, self.OFF[0])

        elif count_number == 5:
            self.bottom2_array(4, self.OFF[0])

        elif count_number == 6:
            self.bottom2_array(5, self.OFF[0])

        elif count_number == 7:
            self.bottom2_array(6, self.OFF[0])

        elif count_number == 8:
            self.bottom2_array(7, self.OFF[0])

        elif count_number == 9:
            self.bottom2_array(8, self.OFF[0])

        elif count_number == 10:
            self.bottom2_array(9, self.OFF[0])

        elif count_number == 11:
            self.bottom2_array(10, self.OFF[0])

    # @micropython.native
    def bottom_off_third(self, count_number):
        # Deactivate
        if count_number == 0:
            self.bottom3_array(11, self.OFF[0])

        elif count_number == 1:
            self.bottom3_array(0, self.OFF[0])

        elif count_number == 2:
            self.bottom3_array(1, self.OFF[0])

        elif count_number == 3:
            self.bottom3_array(2, self.OFF[0])

        elif count_number == 4:
            self.bottom3_array(3, self.OFF[0])

        elif count_number == 5:
            self.bottom3_array(4, self.OFF[0])

        elif count_number == 6:
            self.bottom3_array(5, self.OFF[0])

        elif count_number == 7:
            self.bottom3_array(6, self.OFF[0])

        elif count_number == 8:
            self.bottom3_array(7, self.OFF[0])

        elif count_number == 9:
            self.bottom3_array(8, self.OFF[0])

        elif count_number == 10:
            self.bottom3_array(9, self.OFF[0])

        elif count_number == 11:
            self.bottom3_array(10, self.OFF[0])


    def start_bottom(self, bottom_number, brightness):

        color = self.WHITE[0]

        # BOTTOM - LEDS
        if bottom_number == 0:
            self.bottom1_array(0, self.scale_color(color, brightness))
            self.bottom1_array(1, self.scale_color(color, brightness))
            self.bottom1_array(2, self.scale_color(color, brightness))
            self.bottom1_array(3, self.scale_color(color, brightness))
            self.bottom1_array(4, self.scale_color(color, brightness))
            self.bottom1_array(5, self.scale_color(color, brightness))
            self.bottom1_array(6, self.scale_color(color, brightness))
            self.bottom1_array(7, self.scale_color(color, brightness))
            self.bottom1_array(8, self.scale_color(color, brightness))
            self.bottom1_array(9, self.scale_color(color, brightness))
            self.bottom1_array(10, self.scale_color(color, brightness))
            self.bottom1_array(11, self.scale_color(color, brightness))

        if bottom_number == 1:
            self.bottom2_array(0, self.scale_color(color, brightness))
            self.bottom2_array(1, self.scale_color(color, brightness))
            self.bottom2_array(2, self.scale_color(color, brightness))
            self.bottom2_array(3, self.scale_color(color, brightness))
            self.bottom2_array(4, self.scale_color(color, brightness))
            self.bottom2_array(5, self.scale_color(color, brightness))
            self.bottom2_array(6, self.scale_color(color, brightness))
            self.bottom2_array(7, self.scale_color(color, brightness))
            self.bottom2_array(8, self.scale_color(color, brightness))
            self.bottom2_array(9, self.scale_color(color, brightness))
            self.bottom2_array(10, self.scale_color(color, brightness))
            self.bottom2_array(11, self.scale_color(color, brightness))

        if bottom_number == 2:
            self.bottom3_array(0, self.scale_color(color, brightness))
            self.bottom3_array(1, self.scale_color(color, brightness))
            self.bottom3_array(2, self.scale_color(color, brightness))
            self.bottom3_array(3, self.scale_color(color, brightness))
            self.bottom3_array(4, self.scale_color(color, brightness))
            self.bottom3_array(5, self.scale_color(color, brightness))
            self.bottom3_array(6, self.scale_color(color, brightness))
            self.bottom3_array(7, self.scale_color(color, brightness))
            self.bottom3_array(8, self.scale_color(color, brightness))
            self.bottom3_array(9, self.scale_color(color, brightness))
            self.bottom3_array(10, self.scale_color(color, brightness))
            self.bottom3_array(11, self.scale_color(color, brightness))

    def stop_bottom(self, bottom_number):

        color = self.OFF[0]

        # BOTTOM - LEDS
        if bottom_number == 0:
            self.bottom1_array(0, color)
            self.bottom1_array(1, color)
            self.bottom1_array(2, color)
            self.bottom1_array(3, color)
            self.bottom1_array(4, color)
            self.bottom1_array(5, color)
            self.bottom1_array(6, color)
            self.bottom1_array(7, color)
            self.bottom1_array(8, color)
            self.bottom1_array(9, color)
            self.bottom1_array(10, color)
            self.bottom1_array(11, color)

        if bottom_number == 1:
            self.bottom2_array(0, color)
            self.bottom2_array(1, color)
            self.bottom2_array(2, color)
            self.bottom2_array(3, color)
            self.bottom2_array(4, color)
            self.bottom2_array(5, color)
            self.bottom2_array(6, color)
            self.bottom2_array(7, color)
            self.bottom2_array(8, color)
            self.bottom2_array(9, color)
            self.bottom2_array(10, color)
            self.bottom2_array(11, color)

        if bottom_number == 2:
            self.bottom3_array(0, color)
            self.bottom3_array(1, color)
            self.bottom3_array(2, color)
            self.bottom3_array(3, color)
            self.bottom3_array(4, color)
            self.bottom3_array(5, color)
            self.bottom3_array(6, color)
            self.bottom3_array(7, color)
            self.bottom3_array(8, color)
            self.bottom3_array(9, color)
            self.bottom3_array(10, color)
            self.bottom3_array(11, color)

    # Die Methode gibt dir einene gegebene Farbwert zurck, welche durch die "brightness" eingestellt wurde
    def scale_color(self, color_tupel, brightness):

        floatbrightness = float(brightness)

        r, g, b, w = color_tupel

        if (r, g, b, w) == (0, 0, 0, 0):
            return (0, 0, 0, 0)

        floatbrightness = floatbrightness / 100.0

        r = int(r * floatbrightness)
        g = int(g * floatbrightness)
        b = int(b * floatbrightness)
        w = int(w * brightness)

        return (r, g, b, w)

    def start(self, stop_event, diming):
        print("start Pulsar innerhalb Pulsar Klasse getrigget!")
        self.pulsar_on = True
        self.pulsar_loop(stop_event, diming)

    def stop(self):
        self.pulsar_on = False
        self.pulsar_off()
        self.np.deinit()

    def pulsar_off(self):
        self.np.fill((0, 0, 0, 0))
        self.np.write()

    def get_Status(self):
        return self.pulsar_on


#pulsar = Pulsar(False)
#stop_event = multiprocessing.Event()
#diming = True
#pulsar.start(stop_event, diming)
